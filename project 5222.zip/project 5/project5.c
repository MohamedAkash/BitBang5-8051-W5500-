//sdcc --model-small -o project5.hex project5.c
//stcgal -p COM6 -b 9600 project5.hex
#include <8051.h>
#include <stdint.h>

#define MOSI P1_0 // pin 10
#define MISO P1_1 // pin 11
#define SCK  P1_2 // pin 12
#define SS   P1_3 // pin 13
#define RXD P3_0 // pin 30
#define TXD P3_1 // pin 31

#define WIZNET_WRITE_OPCODE 0xF0
#define WIZNET_READ_OPCODE  0x0F

#define CR 0x00 //common register

#define S0_R 0b00001000 //select socket 0 register
#define S0_TX 0b00010000 //select socket 0 tx buffer
#define S0_RX 0b00011000 //select socket 0 rx buffer

#define S1_R 0b00101000 //select socket 1 register 
#define S1_TX 0b00110000 //select socket 2 tx buffer
#define S1_RX 0b00111000 //select socket 2 rx buffer

#define Sn_PC 0b00000000 //socket n protocol closed
#define Sn_PTCP 0b00000001 //socket n protocol TCP
#define Sn_PUDP 0b00000010 //socket n protocol UDP

#define SHAR 0x0009 //source hardware address
#define SIPR 0x000F //source IP Address

void UART_Init(void);  // Function to initialize UART
void UART_TxChar(char c);  // Function to transmit a character
char UART_RxChar(void);  // Function to receive a character
void WIZnet_OpenSocket(void); //Wiznet function set a socket to open
void WIZnet_CloseSocket(void); //Wiznet functiont to set a socket to close
void WIZnet_SetSocketPort(void); //wiznet function to set the socket port 

//for testing
#define DELAY
#define DEBUG

void delay(unsigned int milliseconds);


void WIZnet_Write(unsigned short address, unsigned char modeRegister, unsigned char data) {
    SS = 0;  // Select WIZnet
    SPI_WriteShort(address); //sending the address
    SPI_Write(modeRegister + 0x04); //where you put registers + 0x04 to indicate write operation
    SPI_Write(data); // Send data
    SS = 1;  // Deselect WIZnet
}

void writeBuffer(uint16_t txPointer, const uint8_t* data, uint16_t length) {
    // Start SPI transaction
    SS = 0;  // Pull CS (Chip Select) low to start communication

    // Set the write pointer to the TX buffer
    // Send the high byte of the address
    SPI_Write((txPointer >> 8) & 0xFF);
    // Send the low byte of the address
    SPI_Write(txPointer & 0xFF);
    
    // Send the data to the TX buffer
    for (uint16_t i = 0; i < length; i++) {
        SPI_Write(data[i]);
    }

    // End SPI transaction
    SS = 1;  // Pull CS high to end communication
}

// Read from a WIZnet register
unsigned char WIZnet_Read(unsigned short address, unsigned char modeRegister) {
    unsigned char data;
    SS = 0;  // Select WIZnet
    SPI_WriteShort(address);
    SPI_Write(modeRegister); //where you put registers
    data = SPI_Read();                   // Read data
    SS = 1;  // Deselect WIZnet
    return data;
}

void WIZnet_Init(void) {
    // Reset WIZnet chip (if applicable)
    SS = 0; 
    SPI_WriteShort(0x0000);
    SPI_Write(0b10000000);// MR register: Reset command
    SS = 1;
    delay(10);                   // Wait for reset to complete
}

void WIZnet_SetIP(unsigned char *ip) {
    // Set IP address (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(0x000F + i,CR, ip[i]); // SIPR register starts at 0x000F
    }
}

void WIZnet_SetDestinationIP(unsigned char *ip) {
    // Set IP address (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(0x000C + i,S0_R, ip[i]); // SIPR register starts at 0x000F
    }
}

void WIZnet_SetMAC(unsigned char *mac) {
    // Set MAC address (6 bytes)
    for (unsigned char i = 0; i < 6; i++) {
        WIZnet_Write(0x0009 + i,CR, mac[i]); // SHAR register starts at 0x0009
    }
}

void WIZnet_SetSubnetMask(unsigned char *subnet) {
    // Set Subnet Mask (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(0x0005 + i,CR, subnet[i]); // SUBR register starts at 0x0005
    }
}

void WIZnet_SetGateway(unsigned char *gateway) {
    // Set Gateway Address (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(0x0001 + i,CR, gateway[i]); // GAR register starts at 0x0001
    }
}

void WIZnet_SetSocketMode(unsigned char mode) {
    // Set the mode for the socket (TCP or UDP)
    WIZnet_Write(0x0000,S0_R,mode); // Sn_MR register
}

void WIZnet_SetSocketPort(void) {
    // Set the source port for the socket
    WIZnet_Write(0x0004,S0_R, 0x13); // Set port high byte (5000 = 0x1388)
    WIZnet_Write(0x0005, S0_R, 0x88);  // Set port low byte
}

void WIZnet_OpenSocket(void) {
    // Open the socket
    WIZnet_Write(0x0001,S0_R, 0x01); // Sn_CR register: OPEN command
}

void WIZnet_CloseSocket(void) {
    // Close the socket
    WIZnet_Write(0x0001,S0_R, 0x10); // Sn_CR register: CLOSE command
}

void WIZnet_SetDestinationPort(void) {
    // Set the source port for the socket
    WIZnet_Write(0x0010,S0_R, 0x13); // Set port high byte (5000 = 0x1388)
    WIZnet_Write(0x0011, S0_R, 0x88);  // Set port low byte
}

void WriteUDPPacket(unsigned char destIP[4],unsigned char data)
{

    WIZnet_SetDestinationIP(destIP); // Set the destination IP address for UDP packet
    WIZnet_SetDestinationPort(); // Set the destination port for UDP packet
    WIZnet_Write(0x0000, S0_TX, data); // Write the data

}

void ReadUDPPacket(void)
{
    /*
    This function reads the UDP packet from the socket and processes it. 
    Note: You may need to adjust the logic based on your application needs.
    */
    unsigned char data;
    unsigned short rxPointer = 0x0000; // Start of RX buffer for socket 0

    // Read the RX buffer to check for incoming data
    data = WIZnet_Read(rxPointer, S0_RX); // Read from RX buffer

    if(data != 0) // Check if there is any data in the RX buffer
    {
        UART_TxChar(data); // Send received data over UART for debugging
    }

}

void Wiznet_SendPacket(void)
{
    WIZnet_Write(0x0001, S0_R, 0x20); //give the socket the send command (0x20) to send the data in the TX buffer.
    while(WIZnet_Read(0x0001, S0_R) != 0x00) // wait for the command to complete 
    {
        // This loop will wait until the socket is ready to send data
    }
}

// Main function for serial communication
void main(void) {

    //char receivedData;

    unsigned char ip[4] = {192, 168, 32, 27};   //test ip
    unsigned char mac[6] = {0x00, 0x08, 0xDC, 0x01, 0x02, 0x03}; //test mac address
    unsigned char subnet[4] = {255, 255, 255, 0};               // Example Subnet Mask
    unsigned char gateway[4] = {192, 168, 32, 1};                // Example Gateway
   
    //init spi
    SPI_Init();

    //ini wiznet chip
    WIZnet_Init();

    //init uart
    UART_Init();

    //set mac address
    WIZnet_SetMAC(mac);

    // Set IP address
    WIZnet_SetIP(ip);

    // Set Subnet Mask
    WIZnet_SetSubnetMask(subnet);

    // Set Gateway Address
    WIZnet_SetGateway(gateway);  

       //set wiznet socket mode to selected protocol (TCP/UDP)
    WIZnet_SetSocketMode(Sn_PUDP);

    //set socket port right not hardcoded at port 5000
    WIZnet_SetSocketPort();

    //send open socket command
    WIZnet_OpenSocket();

    WIZnet_Write(0x0000, S0_TX, 0x20); // Write some test data to the TX buffer of socket 0

    //Setting up the socket for TCP
 
    while(1)
    {

    //UART_TxChar('Z');
    //delay(1); // Small delay to ensure UART transmission is smooth
    //UART_RxChar();

    /*
    WIZnet_Read(0x0001, 00000000); // Read the status register of socket 0, this will show if there is any data in the RX buffer

    #ifdef DELAY
    delay(1000);
    #endif
    */
    
    /*
    #ifdef DEBUG
    for(int i = 0; i < 57; i++)
        {

            WIZnet_Read(0x0000+i);
            #ifdef DELAY
            delay(10);
            #endif

        }

    #ifdef DELAY
    delay(1000);
    #endif
    #endif
    */
    }

}

void delay(unsigned int milliseconds)
{
    unsigned int count;
    while (milliseconds > 0) {
        count = 1000; // Adjust this value based on your clock speed
        while (count > 0) {
            count--;
        }
        milliseconds--;
    }
}