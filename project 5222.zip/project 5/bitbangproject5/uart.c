#include <8051.h>
#include "project5Header.h"

// Function to initialize UART
void UART_Init(void) {
    TMOD = 0x20;  // Timer 1 in mode 2 (8-bit auto-reload)
    TH1 = 0xFA;   // Load value for 9600 baud rate 
    SCON = 0x50;  // Serial mode 1, 8-bit data, enable receiver
    TR1 = 1;      // Start Timer 1
    //ES = 1;         // Enable serial interrupt
    //EA = 1;         // Enable global interrupts
}

void UART_TxChar(char c) {
    SBUF = c;          // Load character into serial buffer
    while (TI == 0);   // Wait for transmission to complete
    TI = 0;            // Clear transmit interrupt flag
}
 // Function to receive a character
 char UART_RxChar(void) {
    if(RI)
    {
        RI = 0;    
        return SBUF; 
    }  
    return '\0';
}

void UART_PrintString(char* str){
    while(*str){
        UART_TxChar(*str++);
    }
}

void UART_PrintCharArr(char str[]){
    while(*str){
        UART_TxChar(*str++);
    }
}

// Function to print the IP address over UART
void UART_PrintIP(unsigned char* ip) {
    for (char i = 0; i < 4; i++) {
        UART_PrintNumber(ip[i]); // Print each byte of the IP address

        // Send a dot after each byte except the last one
        if (i < 3) {
            UART_TxChar('.'); // Send dot separator
        }
    }
}

// Function to print the MAC address over UART
void UART_PrintMAC(unsigned char* mac) {
    for (char i = 0; i < 6; i++) {
        UART_PrintHex(mac[i]); // Print each byte of the IP address

        // Send a dot after each byte except the last one
        if (i < 5) {
            UART_TxChar(' '); // Send space separator
        }
    }
}


// Function to convert a number to string and send it over UART
void UART_PrintNumber(unsigned char num) {
    char buffer[3]; // Buffer to hold the string representation (max 3 digits for 255 + null terminator)
    int index = 0;

    // Handle the case where num is 0
    if (num == 0) {
        UART_TxChar('0');
        return;
    }

    // Convert number to string in reverse order
    while (num > 0) {
        buffer[index++] = (num % 10) + '0'; // Get last digit and convert to character
        num /= 10; // Remove last digit
    }

    // Send the digits in the correct order
    for (int i = index - 1; i >= 0; i--) {
        UART_TxChar(buffer[i]); // Send each character
    }
}

// Function to convert a number to hexadecimal and send it over UART
void UART_PrintHex(unsigned char num) {
    char hexChars[] = "0123456789ABCDEF"; // Hexadecimal characters

    // Extract the high nibble (4 most significant bits) and send its hex character
    UART_TxChar(hexChars[(num >> 4) & 0x0F]);

    // Extract the low nibble (4 least significant bits) and send its hex character
    UART_TxChar(hexChars[num & 0x0F]);
}
