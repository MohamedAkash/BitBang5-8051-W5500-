                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module optimized_main
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-medium
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _main_STR_MODE_FORMAT_10000_178
                                     12 	.globl _main_STR_MAC_FORMAT_10000_178
                                     13 	.globl _main_STR_GATE_FORMAT_10000_178
                                     14 	.globl _main_STR_SUB_FORMAT_10000_178
                                     15 	.globl _main_STR_IP_FORMAT_10000_178
                                     16 	.globl _main_STR_RTU_FORMAT_10000_178
                                     17 	.globl _main_STR_CMD_10000_178
                                     18 	.globl _main_STR_TCP_10000_178
                                     19 	.globl _main_STR_UDP_10000_178
                                     20 	.globl _main_STR_MODE_10000_178
                                     21 	.globl _main_STR_MAC_10000_178
                                     22 	.globl _main_STR_GATE_10000_178
                                     23 	.globl _main_STR_SUBNET_10000_178
                                     24 	.globl _main_STR_IP_10000_178
                                     25 	.globl _main_STR_RTU_10000_178
                                     26 	.globl _main_STR_CURRENT_CONFIG_10000_178
                                     27 	.globl _main
                                     28 	.globl _formatResponse
                                     29 	.globl _validateMessage
                                     30 	.globl _getTxWritePointer
                                     31 	.globl _getTxReadPointer
                                     32 	.globl _getRxWritePointer
                                     33 	.globl _getRxReadPointer
                                     34 	.globl _setRxBufferSize
                                     35 	.globl _UART_PrintMAC
                                     36 	.globl _UART_PrintNumber
                                     37 	.globl _UART_PrintIP
                                     38 	.globl _UART_PrintString
                                     39 	.globl _UART_RxChar
                                     40 	.globl _UART_TxChar
                                     41 	.globl _UART_Init
                                     42 	.globl _SPI_Read
                                     43 	.globl _SPI_WriteShort
                                     44 	.globl _SPI_Write
                                     45 	.globl _SPI_Init
                                     46 	.globl _toupper
                                     47 	.globl _isspace
                                     48 	.globl _isalpha
                                     49 	.globl _CY
                                     50 	.globl _AC
                                     51 	.globl _F0
                                     52 	.globl _RS1
                                     53 	.globl _RS0
                                     54 	.globl _OV
                                     55 	.globl _F1
                                     56 	.globl _P
                                     57 	.globl _PS
                                     58 	.globl _PT1
                                     59 	.globl _PX1
                                     60 	.globl _PT0
                                     61 	.globl _PX0
                                     62 	.globl _RD
                                     63 	.globl _WR
                                     64 	.globl _T1
                                     65 	.globl _T0
                                     66 	.globl _INT1
                                     67 	.globl _INT0
                                     68 	.globl _TXD
                                     69 	.globl _RXD
                                     70 	.globl _P3_7
                                     71 	.globl _P3_6
                                     72 	.globl _P3_5
                                     73 	.globl _P3_4
                                     74 	.globl _P3_3
                                     75 	.globl _P3_2
                                     76 	.globl _P3_1
                                     77 	.globl _P3_0
                                     78 	.globl _EA
                                     79 	.globl _ES
                                     80 	.globl _ET1
                                     81 	.globl _EX1
                                     82 	.globl _ET0
                                     83 	.globl _EX0
                                     84 	.globl _P2_7
                                     85 	.globl _P2_6
                                     86 	.globl _P2_5
                                     87 	.globl _P2_4
                                     88 	.globl _P2_3
                                     89 	.globl _P2_2
                                     90 	.globl _P2_1
                                     91 	.globl _P2_0
                                     92 	.globl _SM0
                                     93 	.globl _SM1
                                     94 	.globl _SM2
                                     95 	.globl _REN
                                     96 	.globl _TB8
                                     97 	.globl _RB8
                                     98 	.globl _TI
                                     99 	.globl _RI
                                    100 	.globl _P1_7
                                    101 	.globl _P1_6
                                    102 	.globl _P1_5
                                    103 	.globl _P1_4
                                    104 	.globl _P1_3
                                    105 	.globl _P1_2
                                    106 	.globl _P1_1
                                    107 	.globl _P1_0
                                    108 	.globl _TF1
                                    109 	.globl _TR1
                                    110 	.globl _TF0
                                    111 	.globl _TR0
                                    112 	.globl _IE1
                                    113 	.globl _IT1
                                    114 	.globl _IE0
                                    115 	.globl _IT0
                                    116 	.globl _P0_7
                                    117 	.globl _P0_6
                                    118 	.globl _P0_5
                                    119 	.globl _P0_4
                                    120 	.globl _P0_3
                                    121 	.globl _P0_2
                                    122 	.globl _P0_1
                                    123 	.globl _P0_0
                                    124 	.globl _B
                                    125 	.globl _ACC
                                    126 	.globl _PSW
                                    127 	.globl _IP
                                    128 	.globl _P3
                                    129 	.globl _IE
                                    130 	.globl _P2
                                    131 	.globl _SBUF
                                    132 	.globl _SCON
                                    133 	.globl _P1
                                    134 	.globl _TH1
                                    135 	.globl _TH0
                                    136 	.globl _TL1
                                    137 	.globl _TL0
                                    138 	.globl _TMOD
                                    139 	.globl _TCON
                                    140 	.globl _PCON
                                    141 	.globl _DPH
                                    142 	.globl _DPL
                                    143 	.globl _SP
                                    144 	.globl _P0
                                    145 	.globl _writeToTxBufferTCP_PARM_2
                                    146 	.globl _readFromRXBufferTCP_PARM_2
                                    147 	.globl _tcpConnect_PARM_3
                                    148 	.globl _tcpConnect_PARM_2
                                    149 	.globl _readFromRXBufferUDP_PARM_2
                                    150 	.globl _writeToTXBufferUDP_PARM_2
                                    151 	.globl _formatResponse_PARM_2
                                    152 	.globl _WIZnet_SetDestinationIP_PARM_2
                                    153 	.globl _WIZnet_SetDestinationPort_PARM_2
                                    154 	.globl _WIZnet_SetSocketPort_PARM_2
                                    155 	.globl _WIZnet_SetSocketMode_PARM_2
                                    156 	.globl _WIZnet_Read_PARM_2
                                    157 	.globl _WIZnet_Write_PARM_3
                                    158 	.globl _WIZnet_Write_PARM_2
                                    159 	.globl _combineHexChars_PARM_2
                                    160 	.globl _combineHexChars
                                    161 	.globl _WIZnet_Write
                                    162 	.globl _WIZnet_Read
                                    163 	.globl _WIZnet_Init
                                    164 	.globl _WIZnet_SetIP
                                    165 	.globl _WIZnet_SetMAC
                                    166 	.globl _WIZnet_SetSubnetMask
                                    167 	.globl _WIZnet_SetGateway
                                    168 	.globl _WIZnet_SetSocketMode
                                    169 	.globl _WIZnet_SetSocketPort
                                    170 	.globl _WIZnet_OpenSocket
                                    171 	.globl _WIZnet_CloseSocket
                                    172 	.globl _WIZnet_SetDestinationPort
                                    173 	.globl _WIZnet_SetDestinationIP
                                    174 	.globl _Wiznet_SendPacket
                                    175 	.globl _writeToTXBufferUDP
                                    176 	.globl _readFromRXBufferUDP
                                    177 	.globl _tcpListen
                                    178 	.globl _tcpConnect
                                    179 	.globl _readFromRXBufferTCP
                                    180 	.globl _writeToTxBufferTCP
                                    181 	.globl _delay
                                    182 ;--------------------------------------------------------
                                    183 ; special function registers
                                    184 ;--------------------------------------------------------
                                    185 	.area RSEG    (ABS,DATA)
      000000                        186 	.org 0x0000
                           000080   187 _P0	=	0x0080
                           000081   188 _SP	=	0x0081
                           000082   189 _DPL	=	0x0082
                           000083   190 _DPH	=	0x0083
                           000087   191 _PCON	=	0x0087
                           000088   192 _TCON	=	0x0088
                           000089   193 _TMOD	=	0x0089
                           00008A   194 _TL0	=	0x008a
                           00008B   195 _TL1	=	0x008b
                           00008C   196 _TH0	=	0x008c
                           00008D   197 _TH1	=	0x008d
                           000090   198 _P1	=	0x0090
                           000098   199 _SCON	=	0x0098
                           000099   200 _SBUF	=	0x0099
                           0000A0   201 _P2	=	0x00a0
                           0000A8   202 _IE	=	0x00a8
                           0000B0   203 _P3	=	0x00b0
                           0000B8   204 _IP	=	0x00b8
                           0000D0   205 _PSW	=	0x00d0
                           0000E0   206 _ACC	=	0x00e0
                           0000F0   207 _B	=	0x00f0
                                    208 ;--------------------------------------------------------
                                    209 ; special function bits
                                    210 ;--------------------------------------------------------
                                    211 	.area RSEG    (ABS,DATA)
      000000                        212 	.org 0x0000
                           000080   213 _P0_0	=	0x0080
                           000081   214 _P0_1	=	0x0081
                           000082   215 _P0_2	=	0x0082
                           000083   216 _P0_3	=	0x0083
                           000084   217 _P0_4	=	0x0084
                           000085   218 _P0_5	=	0x0085
                           000086   219 _P0_6	=	0x0086
                           000087   220 _P0_7	=	0x0087
                           000088   221 _IT0	=	0x0088
                           000089   222 _IE0	=	0x0089
                           00008A   223 _IT1	=	0x008a
                           00008B   224 _IE1	=	0x008b
                           00008C   225 _TR0	=	0x008c
                           00008D   226 _TF0	=	0x008d
                           00008E   227 _TR1	=	0x008e
                           00008F   228 _TF1	=	0x008f
                           000090   229 _P1_0	=	0x0090
                           000091   230 _P1_1	=	0x0091
                           000092   231 _P1_2	=	0x0092
                           000093   232 _P1_3	=	0x0093
                           000094   233 _P1_4	=	0x0094
                           000095   234 _P1_5	=	0x0095
                           000096   235 _P1_6	=	0x0096
                           000097   236 _P1_7	=	0x0097
                           000098   237 _RI	=	0x0098
                           000099   238 _TI	=	0x0099
                           00009A   239 _RB8	=	0x009a
                           00009B   240 _TB8	=	0x009b
                           00009C   241 _REN	=	0x009c
                           00009D   242 _SM2	=	0x009d
                           00009E   243 _SM1	=	0x009e
                           00009F   244 _SM0	=	0x009f
                           0000A0   245 _P2_0	=	0x00a0
                           0000A1   246 _P2_1	=	0x00a1
                           0000A2   247 _P2_2	=	0x00a2
                           0000A3   248 _P2_3	=	0x00a3
                           0000A4   249 _P2_4	=	0x00a4
                           0000A5   250 _P2_5	=	0x00a5
                           0000A6   251 _P2_6	=	0x00a6
                           0000A7   252 _P2_7	=	0x00a7
                           0000A8   253 _EX0	=	0x00a8
                           0000A9   254 _ET0	=	0x00a9
                           0000AA   255 _EX1	=	0x00aa
                           0000AB   256 _ET1	=	0x00ab
                           0000AC   257 _ES	=	0x00ac
                           0000AF   258 _EA	=	0x00af
                           0000B0   259 _P3_0	=	0x00b0
                           0000B1   260 _P3_1	=	0x00b1
                           0000B2   261 _P3_2	=	0x00b2
                           0000B3   262 _P3_3	=	0x00b3
                           0000B4   263 _P3_4	=	0x00b4
                           0000B5   264 _P3_5	=	0x00b5
                           0000B6   265 _P3_6	=	0x00b6
                           0000B7   266 _P3_7	=	0x00b7
                           0000B0   267 _RXD	=	0x00b0
                           0000B1   268 _TXD	=	0x00b1
                           0000B2   269 _INT0	=	0x00b2
                           0000B3   270 _INT1	=	0x00b3
                           0000B4   271 _T0	=	0x00b4
                           0000B5   272 _T1	=	0x00b5
                           0000B6   273 _WR	=	0x00b6
                           0000B7   274 _RD	=	0x00b7
                           0000B8   275 _PX0	=	0x00b8
                           0000B9   276 _PT0	=	0x00b9
                           0000BA   277 _PX1	=	0x00ba
                           0000BB   278 _PT1	=	0x00bb
                           0000BC   279 _PS	=	0x00bc
                           0000D0   280 _P	=	0x00d0
                           0000D1   281 _F1	=	0x00d1
                           0000D2   282 _OV	=	0x00d2
                           0000D3   283 _RS0	=	0x00d3
                           0000D4   284 _RS1	=	0x00d4
                           0000D5   285 _F0	=	0x00d5
                           0000D6   286 _AC	=	0x00d6
                           0000D7   287 _CY	=	0x00d7
                                    288 ;--------------------------------------------------------
                                    289 ; overlayable register banks
                                    290 ;--------------------------------------------------------
                                    291 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        292 	.ds 8
                                    293 ;--------------------------------------------------------
                                    294 ; internal ram data
                                    295 ;--------------------------------------------------------
                                    296 	.area DSEG    (DATA)
      000008                        297 _validateMessage_sloc1_1_0:
      000008                        298 	.ds 1
      000009                        299 _formatResponse_sloc0_1_0:
      000009                        300 	.ds 3
                                    301 ;--------------------------------------------------------
                                    302 ; overlayable items in internal ram
                                    303 ;--------------------------------------------------------
                                    304 ;--------------------------------------------------------
                                    305 ; Stack segment in internal ram
                                    306 ;--------------------------------------------------------
                                    307 	.area SSEG
      000021                        308 __start__stack:
      000021                        309 	.ds	1
                                    310 
                                    311 ;--------------------------------------------------------
                                    312 ; indirectly addressable internal ram data
                                    313 ;--------------------------------------------------------
                                    314 	.area ISEG    (DATA)
                                    315 ;--------------------------------------------------------
                                    316 ; absolute internal ram data
                                    317 ;--------------------------------------------------------
                                    318 	.area IABS    (ABS,DATA)
                                    319 	.area IABS    (ABS,DATA)
                                    320 ;--------------------------------------------------------
                                    321 ; bit data
                                    322 ;--------------------------------------------------------
                                    323 	.area BSEG    (BIT)
      000000                        324 _validateMessage_sloc0_1_0:
      000000                        325 	.ds 1
      000001                        326 _main_sloc0_1_0:
      000001                        327 	.ds 1
                                    328 ;--------------------------------------------------------
                                    329 ; paged external ram data
                                    330 ;--------------------------------------------------------
                                    331 	.area PSEG    (PAG,XDATA)
      000001                        332 _returnData:
      000001                        333 	.ds 22
      000017                        334 _rtu:
      000017                        335 	.ds 1
      000018                        336 _combineHexChars_PARM_2:
      000018                        337 	.ds 1
      000019                        338 _WIZnet_Write_PARM_2:
      000019                        339 	.ds 1
      00001A                        340 _WIZnet_Write_PARM_3:
      00001A                        341 	.ds 1
      00001B                        342 _WIZnet_Read_PARM_2:
      00001B                        343 	.ds 1
      00001C                        344 _WIZnet_SetIP_ip_10000_82:
      00001C                        345 	.ds 3
      00001F                        346 _WIZnet_SetMAC_mac_10000_86:
      00001F                        347 	.ds 3
      000022                        348 _WIZnet_SetSubnetMask_subnet_10000_90:
      000022                        349 	.ds 3
      000025                        350 _WIZnet_SetGateway_gateway_10000_94:
      000025                        351 	.ds 3
      000028                        352 _WIZnet_SetSocketMode_PARM_2:
      000028                        353 	.ds 1
      000029                        354 _WIZnet_SetSocketPort_PARM_2:
      000029                        355 	.ds 2
      00002B                        356 _WIZnet_SetDestinationPort_PARM_2:
      00002B                        357 	.ds 2
      00002D                        358 _WIZnet_SetDestinationIP_PARM_2:
      00002D                        359 	.ds 1
      00002E                        360 _validateMessage_i_20000_129:
      00002E                        361 	.ds 2
      000030                        362 _formatResponse_PARM_2:
      000030                        363 	.ds 3
      000033                        364 _formatResponse_input_10000_135:
      000033                        365 	.ds 3
      000036                        366 _formatResponse_i_10000_136:
      000036                        367 	.ds 2
      000038                        368 _formatResponse_j_20000_137:
      000038                        369 	.ds 2
      00003A                        370 _writeToTXBufferUDP_PARM_2:
      00003A                        371 	.ds 1
      00003B                        372 _readFromRXBufferUDP_PARM_2:
      00003B                        373 	.ds 1
      00003C                        374 _readFromRXBufferUDP_readPointer_20002_151:
      00003C                        375 	.ds 2
      00003E                        376 _readFromRXBufferUDP_getSize_20002_151:
      00003E                        377 	.ds 2
      000040                        378 _readFromRXBufferUDP_peer_ip_20002_151:
      000040                        379 	.ds 4
      000044                        380 _readFromRXBufferUDP_tempBuffer_20002_151:
      000044                        381 	.ds 22
      00005A                        382 _tcpConnect_PARM_2:
      00005A                        383 	.ds 3
      00005D                        384 _tcpConnect_PARM_3:
      00005D                        385 	.ds 2
      00005F                        386 _readFromRXBufferTCP_PARM_2:
      00005F                        387 	.ds 1
      000060                        388 _readFromRXBufferTCP_sock_10000_160:
      000060                        389 	.ds 1
      000061                        390 _readFromRXBufferTCP_tempBuffer_20001_163:
      000061                        391 	.ds 22
      000077                        392 _readFromRXBufferTCP_i_30001_164:
      000077                        393 	.ds 2
      000079                        394 _writeToTxBufferTCP_PARM_2:
      000079                        395 	.ds 1
      00007A                        396 _main_buffer_10001_179:
      00007A                        397 	.ds 22
                                    398 ;--------------------------------------------------------
                                    399 ; uninitialized external ram data
                                    400 ;--------------------------------------------------------
                                    401 	.area XSEG    (XDATA)
      000091                        402 _main_ip_10000_178:
      000091                        403 	.ds 4
      000095                        404 _main_mac_10000_178:
      000095                        405 	.ds 6
      00009B                        406 _main_subnet_10000_178:
      00009B                        407 	.ds 4
      00009F                        408 _main_gateway_10000_178:
      00009F                        409 	.ds 4
                                    410 ;--------------------------------------------------------
                                    411 ; absolute external ram data
                                    412 ;--------------------------------------------------------
                                    413 	.area XABS    (ABS,XDATA)
                                    414 ;--------------------------------------------------------
                                    415 ; initialized external ram data
                                    416 ;--------------------------------------------------------
                                    417 	.area XISEG   (XDATA)
                                    418 	.area HOME    (CODE)
                                    419 	.area GSINIT0 (CODE)
                                    420 	.area GSINIT1 (CODE)
                                    421 	.area GSINIT2 (CODE)
                                    422 	.area GSINIT3 (CODE)
                                    423 	.area GSINIT4 (CODE)
                                    424 	.area GSINIT5 (CODE)
                                    425 	.area GSINIT  (CODE)
                                    426 	.area GSFINAL (CODE)
                                    427 	.area CSEG    (CODE)
                                    428 ;--------------------------------------------------------
                                    429 ; interrupt vector
                                    430 ;--------------------------------------------------------
                                    431 	.area HOME    (CODE)
      000000                        432 __interrupt_vect:
      000000 02 00 4C         [24]  433 	ljmp	__sdcc_gsinit_startup
                                    434 ; restartable atomic support routines
      000003                        435 	.ds	5
      000008                        436 sdcc_atomic_exchange_rollback_start::
      000008 00               [12]  437 	nop
      000009 00               [12]  438 	nop
      00000A                        439 sdcc_atomic_exchange_pdata_impl:
      00000A E2               [24]  440 	movx	a, @r0
      00000B FB               [12]  441 	mov	r3, a
      00000C EA               [12]  442 	mov	a, r2
      00000D F2               [24]  443 	movx	@r0, a
      00000E 80 2C            [24]  444 	sjmp	sdcc_atomic_exchange_exit
      000010 00               [12]  445 	nop
      000011 00               [12]  446 	nop
      000012                        447 sdcc_atomic_exchange_xdata_impl:
      000012 E0               [24]  448 	movx	a, @dptr
      000013 FB               [12]  449 	mov	r3, a
      000014 EA               [12]  450 	mov	a, r2
      000015 F0               [24]  451 	movx	@dptr, a
      000016 80 24            [24]  452 	sjmp	sdcc_atomic_exchange_exit
      000018                        453 sdcc_atomic_compare_exchange_idata_impl:
      000018 E6               [12]  454 	mov	a, @r0
      000019 B5 02 02         [24]  455 	cjne	a, ar2, .+#5
      00001C EB               [12]  456 	mov	a, r3
      00001D F6               [12]  457 	mov	@r0, a
      00001E 22               [24]  458 	ret
      00001F 00               [12]  459 	nop
      000020                        460 sdcc_atomic_compare_exchange_pdata_impl:
      000020 E2               [24]  461 	movx	a, @r0
      000021 B5 02 02         [24]  462 	cjne	a, ar2, .+#5
      000024 EB               [12]  463 	mov	a, r3
      000025 F2               [24]  464 	movx	@r0, a
      000026 22               [24]  465 	ret
      000027 00               [12]  466 	nop
      000028                        467 sdcc_atomic_compare_exchange_xdata_impl:
      000028 E0               [24]  468 	movx	a, @dptr
      000029 B5 02 02         [24]  469 	cjne	a, ar2, .+#5
      00002C EB               [12]  470 	mov	a, r3
      00002D F0               [24]  471 	movx	@dptr, a
      00002E 22               [24]  472 	ret
      00002F                        473 sdcc_atomic_exchange_rollback_end::
                                    474 
      00002F                        475 sdcc_atomic_exchange_gptr_impl::
      00002F 30 F6 E0         [24]  476 	jnb	b.6, sdcc_atomic_exchange_xdata_impl
      000032 A8 82            [24]  477 	mov	r0, dpl
      000034 20 F5 D3         [24]  478 	jb	b.5, sdcc_atomic_exchange_pdata_impl
      000037                        479 sdcc_atomic_exchange_idata_impl:
      000037 EA               [12]  480 	mov	a, r2
      000038 C6               [12]  481 	xch	a, @r0
      000039 F5 82            [12]  482 	mov	dpl, a
      00003B 22               [24]  483 	ret
      00003C                        484 sdcc_atomic_exchange_exit:
      00003C 8B 82            [24]  485 	mov	dpl, r3
      00003E 22               [24]  486 	ret
      00003F                        487 sdcc_atomic_compare_exchange_gptr_impl::
      00003F 30 F6 E6         [24]  488 	jnb	b.6, sdcc_atomic_compare_exchange_xdata_impl
      000042 A8 82            [24]  489 	mov	r0, dpl
      000044 20 F5 D9         [24]  490 	jb	b.5, sdcc_atomic_compare_exchange_pdata_impl
      000047 80 CF            [24]  491 	sjmp	sdcc_atomic_compare_exchange_idata_impl
                                    492 ;--------------------------------------------------------
                                    493 ; global & static initialisations
                                    494 ;--------------------------------------------------------
                                    495 	.area HOME    (CODE)
                                    496 	.area GSINIT  (CODE)
                                    497 	.area GSFINAL (CODE)
                                    498 	.area GSINIT  (CODE)
                                    499 	.globl __sdcc_gsinit_startup
                                    500 	.globl __sdcc_program_startup
                                    501 	.globl __start__stack
                                    502 	.globl __mcs51_genXINIT
                                    503 	.globl __mcs51_genXRAMCLEAR
                                    504 	.globl __mcs51_genRAMCLEAR
                                    505 ;	optimized_main.c:13: static unsigned char rtu = 0;
      0000A5 78 17            [12]  506 	mov	r0,#_rtu
      0000A7 E4               [12]  507 	clr	a
      0000A8 F2               [24]  508 	movx	@r0,a
                                    509 	.area GSFINAL (CODE)
      0000A9 02 00 49         [24]  510 	ljmp	__sdcc_program_startup
                                    511 ;--------------------------------------------------------
                                    512 ; Home
                                    513 ;--------------------------------------------------------
                                    514 	.area HOME    (CODE)
                                    515 	.area HOME    (CODE)
      000049                        516 __sdcc_program_startup:
      000049 02 0C CC         [24]  517 	ljmp	_main
                                    518 ;	return from main will return to caller
                                    519 ;--------------------------------------------------------
                                    520 ; code
                                    521 ;--------------------------------------------------------
                                    522 	.area CSEG    (CODE)
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'combineHexChars'
                                    525 ;------------------------------------------------------------
                                    526 ;	optimized_main.c:15: unsigned char combineHexChars(char high, char low) {
                                    527 ;	-----------------------------------------
                                    528 ;	 function combineHexChars
                                    529 ;	-----------------------------------------
      0000AC                        530 _combineHexChars:
                           000007   531 	ar7 = 0x07
                           000006   532 	ar6 = 0x06
                           000005   533 	ar5 = 0x05
                           000004   534 	ar4 = 0x04
                           000003   535 	ar3 = 0x03
                           000002   536 	ar2 = 0x02
                           000001   537 	ar1 = 0x01
                           000000   538 	ar0 = 0x00
      0000AC AF 82            [24]  539 	mov	r7, dpl
                                    540 ;	optimized_main.c:20: if (high >= '0' && high <= '9') {
      0000AE BF 30 00         [24]  541 	cjne	r7,#0x30,00167$
      0000B1                        542 00167$:
      0000B1 40 0D            [24]  543 	jc	00106$
      0000B3 EF               [12]  544 	mov	a,r7
      0000B4 24 C6            [12]  545 	add	a,#0xff - 0x39
      0000B6 40 08            [24]  546 	jc	00106$
                                    547 ;	optimized_main.c:21: highValue = high - '0'; // Convert '0'-'9' to 0-9
      0000B8 8F 06            [24]  548 	mov	ar6,r7
      0000BA EE               [12]  549 	mov	a,r6
      0000BB 24 D0            [12]  550 	add	a,#0xd0
      0000BD FE               [12]  551 	mov	r6,a
      0000BE 80 14            [24]  552 	sjmp	00107$
      0000C0                        553 00106$:
                                    554 ;	optimized_main.c:22: } else if (high >= 'A' && high <= 'F') {
      0000C0 BF 41 00         [24]  555 	cjne	r7,#0x41,00170$
      0000C3                        556 00170$:
      0000C3 40 0B            [24]  557 	jc	00102$
      0000C5 EF               [12]  558 	mov	a,r7
      0000C6 24 B9            [12]  559 	add	a,#0xff - 0x46
      0000C8 40 06            [24]  560 	jc	00102$
                                    561 ;	optimized_main.c:23: highValue = high - 'A' + 10; // Convert 'A'-'F' to 10-15
      0000CA 74 C9            [12]  562 	mov	a,#0xc9
      0000CC 2F               [12]  563 	add	a, r7
      0000CD FE               [12]  564 	mov	r6,a
      0000CE 80 04            [24]  565 	sjmp	00107$
      0000D0                        566 00102$:
                                    567 ;	optimized_main.c:26: return 0; // or some error value
      0000D0 75 82 00         [24]  568 	mov	dpl, #0x00
      0000D3 22               [24]  569 	ret
      0000D4                        570 00107$:
                                    571 ;	optimized_main.c:30: if (low >= '0' && low <= '9') {
      0000D4 78 18            [12]  572 	mov	r0,#_combineHexChars_PARM_2
      0000D6 E2               [24]  573 	movx	a,@r0
      0000D7 B4 30 00         [24]  574 	cjne	a,#0x30,00173$
      0000DA                        575 00173$:
      0000DA 40 14            [24]  576 	jc	00114$
      0000DC 78 18            [12]  577 	mov	r0,#_combineHexChars_PARM_2
      0000DE C3               [12]  578 	clr	c
      0000DF E2               [24]  579 	movx	a,@r0
      0000E0 F5 F0            [12]  580 	mov	b,a
      0000E2 74 39            [12]  581 	mov	a,#0x39
      0000E4 95 F0            [12]  582 	subb	a,b
      0000E6 40 08            [24]  583 	jc	00114$
                                    584 ;	optimized_main.c:31: lowValue = low - '0'; // Convert '0'-'9' to 0-9
      0000E8 78 18            [12]  585 	mov	r0,#_combineHexChars_PARM_2
      0000EA E2               [24]  586 	movx	a,@r0
      0000EB 24 D0            [12]  587 	add	a,#0xd0
      0000ED FF               [12]  588 	mov	r7,a
      0000EE 80 20            [24]  589 	sjmp	00115$
      0000F0                        590 00114$:
                                    591 ;	optimized_main.c:32: } else if (low >= 'A' && low <= 'F') {
      0000F0 78 18            [12]  592 	mov	r0,#_combineHexChars_PARM_2
      0000F2 E2               [24]  593 	movx	a,@r0
      0000F3 B4 41 00         [24]  594 	cjne	a,#0x41,00176$
      0000F6                        595 00176$:
      0000F6 40 14            [24]  596 	jc	00110$
      0000F8 78 18            [12]  597 	mov	r0,#_combineHexChars_PARM_2
      0000FA C3               [12]  598 	clr	c
      0000FB E2               [24]  599 	movx	a,@r0
      0000FC F5 F0            [12]  600 	mov	b,a
      0000FE 74 46            [12]  601 	mov	a,#0x46
      000100 95 F0            [12]  602 	subb	a,b
      000102 40 08            [24]  603 	jc	00110$
                                    604 ;	optimized_main.c:33: lowValue = low - 'A' + 10; // Convert 'A'-'F' to 10-15
      000104 78 18            [12]  605 	mov	r0,#_combineHexChars_PARM_2
      000106 E2               [24]  606 	movx	a,@r0
      000107 24 C9            [12]  607 	add	a,#0xc9
      000109 FF               [12]  608 	mov	r7,a
      00010A 80 04            [24]  609 	sjmp	00115$
      00010C                        610 00110$:
                                    611 ;	optimized_main.c:36: return 0; // or some error value
      00010C 75 82 00         [24]  612 	mov	dpl, #0x00
      00010F 22               [24]  613 	ret
      000110                        614 00115$:
                                    615 ;	optimized_main.c:40: return (highValue << 4) | lowValue; // Shift high value and combine
      000110 EE               [12]  616 	mov	a,r6
      000111 C4               [12]  617 	swap	a
      000112 54 F0            [12]  618 	anl	a,#0xf0
      000114 4F               [12]  619 	orl	a,r7
      000115 F5 82            [12]  620 	mov	dpl,a
                                    621 ;	optimized_main.c:41: }
      000117 22               [24]  622 	ret
                                    623 ;------------------------------------------------------------
                                    624 ;Allocation info for local variables in function 'WIZnet_Write'
                                    625 ;------------------------------------------------------------
                                    626 ;	optimized_main.c:44: void WIZnet_Write(unsigned short address, unsigned char modeRegister, unsigned char data) {
                                    627 ;	-----------------------------------------
                                    628 ;	 function WIZnet_Write
                                    629 ;	-----------------------------------------
      000118                        630 _WIZnet_Write:
                                    631 ;	optimized_main.c:45: SS = 0;  // Select WIZnet
                                    632 ;	assignBit
      000118 C2 93            [12]  633 	clr	_P1_3
                                    634 ;	optimized_main.c:46: SPI_WriteShort(address); //sending the address
      00011A 12 1A 2E         [24]  635 	lcall	_SPI_WriteShort
                                    636 ;	optimized_main.c:47: SPI_Write(modeRegister + 0x04); //where you put registers + 0x04 to indicate write operation
      00011D 78 19            [12]  637 	mov	r0,#_WIZnet_Write_PARM_2
      00011F E2               [24]  638 	movx	a,@r0
      000120 24 04            [12]  639 	add	a,#0x04
      000122 F5 82            [12]  640 	mov	dpl,a
      000124 12 1A 16         [24]  641 	lcall	_SPI_Write
                                    642 ;	optimized_main.c:48: SPI_Write(data); // Send data
      000127 78 1A            [12]  643 	mov	r0,#_WIZnet_Write_PARM_3
      000129 E2               [24]  644 	movx	a,@r0
      00012A F5 82            [12]  645 	mov	dpl, a
      00012C 12 1A 16         [24]  646 	lcall	_SPI_Write
                                    647 ;	optimized_main.c:49: SS = 1;  // Deselect WIZnet
                                    648 ;	assignBit
      00012F D2 93            [12]  649 	setb	_P1_3
                                    650 ;	optimized_main.c:50: }
      000131 22               [24]  651 	ret
                                    652 ;------------------------------------------------------------
                                    653 ;Allocation info for local variables in function 'WIZnet_Read'
                                    654 ;------------------------------------------------------------
                                    655 ;	optimized_main.c:53: unsigned char WIZnet_Read(unsigned short address, unsigned char modeRegister) {
                                    656 ;	-----------------------------------------
                                    657 ;	 function WIZnet_Read
                                    658 ;	-----------------------------------------
      000132                        659 _WIZnet_Read:
                                    660 ;	optimized_main.c:55: SS = 0;  // Select WIZnet
                                    661 ;	assignBit
      000132 C2 93            [12]  662 	clr	_P1_3
                                    663 ;	optimized_main.c:56: SPI_WriteShort(address);
      000134 12 1A 2E         [24]  664 	lcall	_SPI_WriteShort
                                    665 ;	optimized_main.c:57: SPI_Write(modeRegister); //where you put registers
      000137 78 1B            [12]  666 	mov	r0,#_WIZnet_Read_PARM_2
      000139 E2               [24]  667 	movx	a,@r0
      00013A F5 82            [12]  668 	mov	dpl, a
      00013C 12 1A 16         [24]  669 	lcall	_SPI_Write
                                    670 ;	optimized_main.c:58: data = SPI_Read();                   // Read data
      00013F 12 1A 44         [24]  671 	lcall	_SPI_Read
                                    672 ;	optimized_main.c:59: SS = 1;  // Deselect WIZnet
                                    673 ;	assignBit
      000142 D2 93            [12]  674 	setb	_P1_3
                                    675 ;	optimized_main.c:60: return data;
                                    676 ;	optimized_main.c:61: }
      000144 22               [24]  677 	ret
                                    678 ;------------------------------------------------------------
                                    679 ;Allocation info for local variables in function 'WIZnet_Init'
                                    680 ;------------------------------------------------------------
                                    681 ;	optimized_main.c:64: void WIZnet_Init(void) {
                                    682 ;	-----------------------------------------
                                    683 ;	 function WIZnet_Init
                                    684 ;	-----------------------------------------
      000145                        685 _WIZnet_Init:
                                    686 ;	optimized_main.c:66: SS = 0; 
                                    687 ;	assignBit
      000145 C2 93            [12]  688 	clr	_P1_3
                                    689 ;	optimized_main.c:67: SPI_WriteShort(Sn_MR);
      000147 90 00 00         [24]  690 	mov	dptr,#0x0000
      00014A 12 1A 2E         [24]  691 	lcall	_SPI_WriteShort
                                    692 ;	optimized_main.c:68: SPI_Write(0b10000000);// MR register: Reset command
      00014D 75 82 80         [24]  693 	mov	dpl, #0x80
      000150 12 1A 16         [24]  694 	lcall	_SPI_Write
                                    695 ;	optimized_main.c:69: SS = 1;
                                    696 ;	assignBit
      000153 D2 93            [12]  697 	setb	_P1_3
                                    698 ;	optimized_main.c:70: delay(10);                   // Wait for reset to complete
      000155 90 00 0A         [24]  699 	mov	dptr,#0x000a
                                    700 ;	optimized_main.c:71: }
      000158 02 18 67         [24]  701 	ljmp	_delay
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'WIZnet_SetIP'
                                    704 ;------------------------------------------------------------
                                    705 ;	optimized_main.c:74: void WIZnet_SetIP(unsigned char *ip) {
                                    706 ;	-----------------------------------------
                                    707 ;	 function WIZnet_SetIP
                                    708 ;	-----------------------------------------
      00015B                        709 _WIZnet_SetIP:
      00015B AF F0            [24]  710 	mov	r7,b
      00015D AE 83            [24]  711 	mov	r6,dph
      00015F E5 82            [12]  712 	mov	a,dpl
      000161 78 1C            [12]  713 	mov	r0,#_WIZnet_SetIP_ip_10000_82
      000163 F2               [24]  714 	movx	@r0,a
      000164 EE               [12]  715 	mov	a,r6
      000165 08               [12]  716 	inc	r0
      000166 F2               [24]  717 	movx	@r0,a
      000167 EF               [12]  718 	mov	a,r7
      000168 08               [12]  719 	inc	r0
      000169 F2               [24]  720 	movx	@r0,a
                                    721 ;	optimized_main.c:76: for (unsigned char i = 0; i < 4; i++) {
      00016A 7C 00            [12]  722 	mov	r4,#0x00
      00016C                        723 00103$:
      00016C BC 04 00         [24]  724 	cjne	r4,#0x04,00120$
      00016F                        725 00120$:
      00016F 50 33            [24]  726 	jnc	00105$
                                    727 ;	optimized_main.c:77: WIZnet_Write(SIPR + i,CR, ip[i]); // SIPR register starts at 0x000F
      000171 8C 03            [24]  728 	mov	ar3,r4
      000173 74 0F            [12]  729 	mov	a,#0x0f
      000175 2B               [12]  730 	add	a, r3
      000176 FB               [12]  731 	mov	r3,a
      000177 7A 00            [12]  732 	mov	r2,#0x00
      000179 78 1C            [12]  733 	mov	r0,#_WIZnet_SetIP_ip_10000_82
      00017B E2               [24]  734 	movx	a,@r0
      00017C 2C               [12]  735 	add	a, r4
      00017D FD               [12]  736 	mov	r5,a
      00017E 08               [12]  737 	inc	r0
      00017F E2               [24]  738 	movx	a,@r0
      000180 34 00            [12]  739 	addc	a, #0x00
      000182 FE               [12]  740 	mov	r6,a
      000183 08               [12]  741 	inc	r0
      000184 E2               [24]  742 	movx	a,@r0
      000185 FF               [12]  743 	mov	r7,a
      000186 8D 82            [24]  744 	mov	dpl,r5
      000188 8E 83            [24]  745 	mov	dph,r6
      00018A 8F F0            [24]  746 	mov	b,r7
      00018C 78 1A            [12]  747 	mov	r0,#_WIZnet_Write_PARM_3
      00018E 12 1B 12         [24]  748 	lcall	__gptrget
      000191 F2               [24]  749 	movx	@r0,a
      000192 78 19            [12]  750 	mov	r0,#_WIZnet_Write_PARM_2
      000194 E4               [12]  751 	clr	a
      000195 F2               [24]  752 	movx	@r0,a
      000196 8B 82            [24]  753 	mov	dpl, r3
      000198 8A 83            [24]  754 	mov	dph, r2
      00019A C0 04            [24]  755 	push	ar4
      00019C 12 01 18         [24]  756 	lcall	_WIZnet_Write
      00019F D0 04            [24]  757 	pop	ar4
                                    758 ;	optimized_main.c:76: for (unsigned char i = 0; i < 4; i++) {
      0001A1 0C               [12]  759 	inc	r4
      0001A2 80 C8            [24]  760 	sjmp	00103$
      0001A4                        761 00105$:
                                    762 ;	optimized_main.c:79: }
      0001A4 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'WIZnet_SetMAC'
                                    766 ;------------------------------------------------------------
                                    767 ;	optimized_main.c:82: void WIZnet_SetMAC(unsigned char *mac) {
                                    768 ;	-----------------------------------------
                                    769 ;	 function WIZnet_SetMAC
                                    770 ;	-----------------------------------------
      0001A5                        771 _WIZnet_SetMAC:
      0001A5 AF F0            [24]  772 	mov	r7,b
      0001A7 AE 83            [24]  773 	mov	r6,dph
      0001A9 E5 82            [12]  774 	mov	a,dpl
      0001AB 78 1F            [12]  775 	mov	r0,#_WIZnet_SetMAC_mac_10000_86
      0001AD F2               [24]  776 	movx	@r0,a
      0001AE EE               [12]  777 	mov	a,r6
      0001AF 08               [12]  778 	inc	r0
      0001B0 F2               [24]  779 	movx	@r0,a
      0001B1 EF               [12]  780 	mov	a,r7
      0001B2 08               [12]  781 	inc	r0
      0001B3 F2               [24]  782 	movx	@r0,a
                                    783 ;	optimized_main.c:84: for (unsigned char i = 0; i < 6; i++) {
      0001B4 7C 00            [12]  784 	mov	r4,#0x00
      0001B6                        785 00103$:
      0001B6 BC 06 00         [24]  786 	cjne	r4,#0x06,00120$
      0001B9                        787 00120$:
      0001B9 50 33            [24]  788 	jnc	00105$
                                    789 ;	optimized_main.c:85: WIZnet_Write(SHAR + i,CR, mac[i]); // SHAR register starts at 0x0009
      0001BB 8C 03            [24]  790 	mov	ar3,r4
      0001BD 74 09            [12]  791 	mov	a,#0x09
      0001BF 2B               [12]  792 	add	a, r3
      0001C0 FB               [12]  793 	mov	r3,a
      0001C1 7A 00            [12]  794 	mov	r2,#0x00
      0001C3 78 1F            [12]  795 	mov	r0,#_WIZnet_SetMAC_mac_10000_86
      0001C5 E2               [24]  796 	movx	a,@r0
      0001C6 2C               [12]  797 	add	a, r4
      0001C7 FD               [12]  798 	mov	r5,a
      0001C8 08               [12]  799 	inc	r0
      0001C9 E2               [24]  800 	movx	a,@r0
      0001CA 34 00            [12]  801 	addc	a, #0x00
      0001CC FE               [12]  802 	mov	r6,a
      0001CD 08               [12]  803 	inc	r0
      0001CE E2               [24]  804 	movx	a,@r0
      0001CF FF               [12]  805 	mov	r7,a
      0001D0 8D 82            [24]  806 	mov	dpl,r5
      0001D2 8E 83            [24]  807 	mov	dph,r6
      0001D4 8F F0            [24]  808 	mov	b,r7
      0001D6 78 1A            [12]  809 	mov	r0,#_WIZnet_Write_PARM_3
      0001D8 12 1B 12         [24]  810 	lcall	__gptrget
      0001DB F2               [24]  811 	movx	@r0,a
      0001DC 78 19            [12]  812 	mov	r0,#_WIZnet_Write_PARM_2
      0001DE E4               [12]  813 	clr	a
      0001DF F2               [24]  814 	movx	@r0,a
      0001E0 8B 82            [24]  815 	mov	dpl, r3
      0001E2 8A 83            [24]  816 	mov	dph, r2
      0001E4 C0 04            [24]  817 	push	ar4
      0001E6 12 01 18         [24]  818 	lcall	_WIZnet_Write
      0001E9 D0 04            [24]  819 	pop	ar4
                                    820 ;	optimized_main.c:84: for (unsigned char i = 0; i < 6; i++) {
      0001EB 0C               [12]  821 	inc	r4
      0001EC 80 C8            [24]  822 	sjmp	00103$
      0001EE                        823 00105$:
                                    824 ;	optimized_main.c:87: }
      0001EE 22               [24]  825 	ret
                                    826 ;------------------------------------------------------------
                                    827 ;Allocation info for local variables in function 'WIZnet_SetSubnetMask'
                                    828 ;------------------------------------------------------------
                                    829 ;	optimized_main.c:90: void WIZnet_SetSubnetMask(unsigned char *subnet) {
                                    830 ;	-----------------------------------------
                                    831 ;	 function WIZnet_SetSubnetMask
                                    832 ;	-----------------------------------------
      0001EF                        833 _WIZnet_SetSubnetMask:
      0001EF AF F0            [24]  834 	mov	r7,b
      0001F1 AE 83            [24]  835 	mov	r6,dph
      0001F3 E5 82            [12]  836 	mov	a,dpl
      0001F5 78 22            [12]  837 	mov	r0,#_WIZnet_SetSubnetMask_subnet_10000_90
      0001F7 F2               [24]  838 	movx	@r0,a
      0001F8 EE               [12]  839 	mov	a,r6
      0001F9 08               [12]  840 	inc	r0
      0001FA F2               [24]  841 	movx	@r0,a
      0001FB EF               [12]  842 	mov	a,r7
      0001FC 08               [12]  843 	inc	r0
      0001FD F2               [24]  844 	movx	@r0,a
                                    845 ;	optimized_main.c:92: for (unsigned char i = 0; i < 4; i++) {
      0001FE 7C 00            [12]  846 	mov	r4,#0x00
      000200                        847 00103$:
      000200 BC 04 00         [24]  848 	cjne	r4,#0x04,00120$
      000203                        849 00120$:
      000203 50 33            [24]  850 	jnc	00105$
                                    851 ;	optimized_main.c:93: WIZnet_Write(SUBR + i,CR, subnet[i]); // SUBR register starts at 0x0005
      000205 8C 03            [24]  852 	mov	ar3,r4
      000207 74 05            [12]  853 	mov	a,#0x05
      000209 2B               [12]  854 	add	a, r3
      00020A FB               [12]  855 	mov	r3,a
      00020B 7A 00            [12]  856 	mov	r2,#0x00
      00020D 78 22            [12]  857 	mov	r0,#_WIZnet_SetSubnetMask_subnet_10000_90
      00020F E2               [24]  858 	movx	a,@r0
      000210 2C               [12]  859 	add	a, r4
      000211 FD               [12]  860 	mov	r5,a
      000212 08               [12]  861 	inc	r0
      000213 E2               [24]  862 	movx	a,@r0
      000214 34 00            [12]  863 	addc	a, #0x00
      000216 FE               [12]  864 	mov	r6,a
      000217 08               [12]  865 	inc	r0
      000218 E2               [24]  866 	movx	a,@r0
      000219 FF               [12]  867 	mov	r7,a
      00021A 8D 82            [24]  868 	mov	dpl,r5
      00021C 8E 83            [24]  869 	mov	dph,r6
      00021E 8F F0            [24]  870 	mov	b,r7
      000220 78 1A            [12]  871 	mov	r0,#_WIZnet_Write_PARM_3
      000222 12 1B 12         [24]  872 	lcall	__gptrget
      000225 F2               [24]  873 	movx	@r0,a
      000226 78 19            [12]  874 	mov	r0,#_WIZnet_Write_PARM_2
      000228 E4               [12]  875 	clr	a
      000229 F2               [24]  876 	movx	@r0,a
      00022A 8B 82            [24]  877 	mov	dpl, r3
      00022C 8A 83            [24]  878 	mov	dph, r2
      00022E C0 04            [24]  879 	push	ar4
      000230 12 01 18         [24]  880 	lcall	_WIZnet_Write
      000233 D0 04            [24]  881 	pop	ar4
                                    882 ;	optimized_main.c:92: for (unsigned char i = 0; i < 4; i++) {
      000235 0C               [12]  883 	inc	r4
      000236 80 C8            [24]  884 	sjmp	00103$
      000238                        885 00105$:
                                    886 ;	optimized_main.c:95: }
      000238 22               [24]  887 	ret
                                    888 ;------------------------------------------------------------
                                    889 ;Allocation info for local variables in function 'WIZnet_SetGateway'
                                    890 ;------------------------------------------------------------
                                    891 ;	optimized_main.c:98: void WIZnet_SetGateway(unsigned char *gateway) {
                                    892 ;	-----------------------------------------
                                    893 ;	 function WIZnet_SetGateway
                                    894 ;	-----------------------------------------
      000239                        895 _WIZnet_SetGateway:
      000239 AF F0            [24]  896 	mov	r7,b
      00023B AE 83            [24]  897 	mov	r6,dph
      00023D E5 82            [12]  898 	mov	a,dpl
      00023F 78 25            [12]  899 	mov	r0,#_WIZnet_SetGateway_gateway_10000_94
      000241 F2               [24]  900 	movx	@r0,a
      000242 EE               [12]  901 	mov	a,r6
      000243 08               [12]  902 	inc	r0
      000244 F2               [24]  903 	movx	@r0,a
      000245 EF               [12]  904 	mov	a,r7
      000246 08               [12]  905 	inc	r0
      000247 F2               [24]  906 	movx	@r0,a
                                    907 ;	optimized_main.c:100: for (unsigned char i = 0; i < 4; i++) {
      000248 7C 00            [12]  908 	mov	r4,#0x00
      00024A                        909 00103$:
      00024A BC 04 00         [24]  910 	cjne	r4,#0x04,00120$
      00024D                        911 00120$:
      00024D 50 30            [24]  912 	jnc	00105$
                                    913 ;	optimized_main.c:101: WIZnet_Write(GAR + i,CR, gateway[i]); // GAR register starts at 0x0001
      00024F 8C 03            [24]  914 	mov	ar3,r4
      000251 0B               [12]  915 	inc	r3
      000252 7A 00            [12]  916 	mov	r2,#0x00
      000254 78 25            [12]  917 	mov	r0,#_WIZnet_SetGateway_gateway_10000_94
      000256 E2               [24]  918 	movx	a,@r0
      000257 2C               [12]  919 	add	a, r4
      000258 FD               [12]  920 	mov	r5,a
      000259 08               [12]  921 	inc	r0
      00025A E2               [24]  922 	movx	a,@r0
      00025B 34 00            [12]  923 	addc	a, #0x00
      00025D FE               [12]  924 	mov	r6,a
      00025E 08               [12]  925 	inc	r0
      00025F E2               [24]  926 	movx	a,@r0
      000260 FF               [12]  927 	mov	r7,a
      000261 8D 82            [24]  928 	mov	dpl,r5
      000263 8E 83            [24]  929 	mov	dph,r6
      000265 8F F0            [24]  930 	mov	b,r7
      000267 78 1A            [12]  931 	mov	r0,#_WIZnet_Write_PARM_3
      000269 12 1B 12         [24]  932 	lcall	__gptrget
      00026C F2               [24]  933 	movx	@r0,a
      00026D 78 19            [12]  934 	mov	r0,#_WIZnet_Write_PARM_2
      00026F E4               [12]  935 	clr	a
      000270 F2               [24]  936 	movx	@r0,a
      000271 8B 82            [24]  937 	mov	dpl, r3
      000273 8A 83            [24]  938 	mov	dph, r2
      000275 C0 04            [24]  939 	push	ar4
      000277 12 01 18         [24]  940 	lcall	_WIZnet_Write
      00027A D0 04            [24]  941 	pop	ar4
                                    942 ;	optimized_main.c:100: for (unsigned char i = 0; i < 4; i++) {
      00027C 0C               [12]  943 	inc	r4
      00027D 80 CB            [24]  944 	sjmp	00103$
      00027F                        945 00105$:
                                    946 ;	optimized_main.c:103: }
      00027F 22               [24]  947 	ret
                                    948 ;------------------------------------------------------------
                                    949 ;Allocation info for local variables in function 'WIZnet_SetSocketMode'
                                    950 ;------------------------------------------------------------
                                    951 ;	optimized_main.c:106: void WIZnet_SetSocketMode(unsigned char mode, unsigned char sock) {
                                    952 ;	-----------------------------------------
                                    953 ;	 function WIZnet_SetSocketMode
                                    954 ;	-----------------------------------------
      000280                        955 _WIZnet_SetSocketMode:
      000280 AF 82            [24]  956 	mov	r7, dpl
                                    957 ;	optimized_main.c:108: WIZnet_Write(Sn_MR,sock,mode); // Sn_MR register
      000282 78 28            [12]  958 	mov	r0,#_WIZnet_SetSocketMode_PARM_2
      000284 79 19            [12]  959 	mov	r1,#_WIZnet_Write_PARM_2
      000286 E2               [24]  960 	movx	a,@r0
      000287 F3               [24]  961 	movx	@r1,a
      000288 78 1A            [12]  962 	mov	r0,#_WIZnet_Write_PARM_3
      00028A EF               [12]  963 	mov	a,r7
      00028B F2               [24]  964 	movx	@r0,a
      00028C 90 00 00         [24]  965 	mov	dptr,#0x0000
                                    966 ;	optimized_main.c:109: }
      00028F 02 01 18         [24]  967 	ljmp	_WIZnet_Write
                                    968 ;------------------------------------------------------------
                                    969 ;Allocation info for local variables in function 'WIZnet_SetSocketPort'
                                    970 ;------------------------------------------------------------
                                    971 ;	optimized_main.c:112: void WIZnet_SetSocketPort(unsigned char sock, int port) {
                                    972 ;	-----------------------------------------
                                    973 ;	 function WIZnet_SetSocketPort
                                    974 ;	-----------------------------------------
      000292                        975 _WIZnet_SetSocketPort:
      000292 AF 82            [24]  976 	mov	r7, dpl
                                    977 ;	optimized_main.c:115: unsigned char highByte = (port >> 8) & 0xFF; // Get the high byte
      000294 78 29            [12]  978 	mov	r0,#_WIZnet_SetSocketPort_PARM_2
      000296 79 1A            [12]  979 	mov	r1,#_WIZnet_Write_PARM_3
      000298 08               [12]  980 	inc	r0
      000299 E2               [24]  981 	movx	a,@r0
      00029A F3               [24]  982 	movx	@r1,a
                                    983 ;	optimized_main.c:116: unsigned char lowByte = port & 0xFF; 
      00029B 78 29            [12]  984 	mov	r0,#_WIZnet_SetSocketPort_PARM_2
      00029D E2               [24]  985 	movx	a,@r0
      00029E FE               [12]  986 	mov	r6,a
                                    987 ;	optimized_main.c:118: WIZnet_Write(Sn_PORT,sock, highByte); // Set port high byte (5000 = 0x1388)
      00029F 78 19            [12]  988 	mov	r0,#_WIZnet_Write_PARM_2
      0002A1 EF               [12]  989 	mov	a,r7
      0002A2 F2               [24]  990 	movx	@r0,a
      0002A3 90 00 04         [24]  991 	mov	dptr,#0x0004
      0002A6 C0 07            [24]  992 	push	ar7
      0002A8 C0 06            [24]  993 	push	ar6
      0002AA 12 01 18         [24]  994 	lcall	_WIZnet_Write
      0002AD D0 06            [24]  995 	pop	ar6
      0002AF D0 07            [24]  996 	pop	ar7
                                    997 ;	optimized_main.c:119: WIZnet_Write(Sn_PORT+1, sock, lowByte);  // Set port low byte
      0002B1 78 19            [12]  998 	mov	r0,#_WIZnet_Write_PARM_2
      0002B3 EF               [12]  999 	mov	a,r7
      0002B4 F2               [24] 1000 	movx	@r0,a
      0002B5 78 1A            [12] 1001 	mov	r0,#_WIZnet_Write_PARM_3
      0002B7 EE               [12] 1002 	mov	a,r6
      0002B8 F2               [24] 1003 	movx	@r0,a
      0002B9 90 00 05         [24] 1004 	mov	dptr,#0x0005
                                   1005 ;	optimized_main.c:120: }
      0002BC 02 01 18         [24] 1006 	ljmp	_WIZnet_Write
                                   1007 ;------------------------------------------------------------
                                   1008 ;Allocation info for local variables in function 'WIZnet_OpenSocket'
                                   1009 ;------------------------------------------------------------
                                   1010 ;	optimized_main.c:123: void WIZnet_OpenSocket(unsigned char sock) {
                                   1011 ;	-----------------------------------------
                                   1012 ;	 function WIZnet_OpenSocket
                                   1013 ;	-----------------------------------------
      0002BF                       1014 _WIZnet_OpenSocket:
      0002BF AF 82            [24] 1015 	mov	r7, dpl
                                   1016 ;	optimized_main.c:125: WIZnet_Write(Sn_CR,sock, 0x01); // Sn_CR register: OPEN command
      0002C1 78 19            [12] 1017 	mov	r0,#_WIZnet_Write_PARM_2
      0002C3 EF               [12] 1018 	mov	a,r7
      0002C4 F2               [24] 1019 	movx	@r0,a
      0002C5 78 1A            [12] 1020 	mov	r0,#_WIZnet_Write_PARM_3
      0002C7 74 01            [12] 1021 	mov	a,#0x01
      0002C9 F2               [24] 1022 	movx	@r0,a
      0002CA 90 00 01         [24] 1023 	mov	dptr,#0x0001
                                   1024 ;	optimized_main.c:126: }
      0002CD 02 01 18         [24] 1025 	ljmp	_WIZnet_Write
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'WIZnet_CloseSocket'
                                   1028 ;------------------------------------------------------------
                                   1029 ;	optimized_main.c:129: void WIZnet_CloseSocket(unsigned char sock) {
                                   1030 ;	-----------------------------------------
                                   1031 ;	 function WIZnet_CloseSocket
                                   1032 ;	-----------------------------------------
      0002D0                       1033 _WIZnet_CloseSocket:
      0002D0 AF 82            [24] 1034 	mov	r7, dpl
                                   1035 ;	optimized_main.c:131: WIZnet_Write(Sn_CR,sock, 0x10); // Sn_CR register: CLOSE command
      0002D2 78 19            [12] 1036 	mov	r0,#_WIZnet_Write_PARM_2
      0002D4 EF               [12] 1037 	mov	a,r7
      0002D5 F2               [24] 1038 	movx	@r0,a
      0002D6 78 1A            [12] 1039 	mov	r0,#_WIZnet_Write_PARM_3
      0002D8 74 10            [12] 1040 	mov	a,#0x10
      0002DA F2               [24] 1041 	movx	@r0,a
      0002DB 90 00 01         [24] 1042 	mov	dptr,#0x0001
                                   1043 ;	optimized_main.c:132: }
      0002DE 02 01 18         [24] 1044 	ljmp	_WIZnet_Write
                                   1045 ;------------------------------------------------------------
                                   1046 ;Allocation info for local variables in function 'WIZnet_SetDestinationPort'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	optimized_main.c:135: void WIZnet_SetDestinationPort(unsigned char sock, int destPort) {
                                   1049 ;	-----------------------------------------
                                   1050 ;	 function WIZnet_SetDestinationPort
                                   1051 ;	-----------------------------------------
      0002E1                       1052 _WIZnet_SetDestinationPort:
      0002E1 AF 82            [24] 1053 	mov	r7, dpl
                                   1054 ;	optimized_main.c:138: unsigned char highByte = (destPort >> 8) & 0xFF; // Get the high byte
      0002E3 78 2B            [12] 1055 	mov	r0,#_WIZnet_SetDestinationPort_PARM_2
      0002E5 79 1A            [12] 1056 	mov	r1,#_WIZnet_Write_PARM_3
      0002E7 08               [12] 1057 	inc	r0
      0002E8 E2               [24] 1058 	movx	a,@r0
      0002E9 F3               [24] 1059 	movx	@r1,a
                                   1060 ;	optimized_main.c:139: unsigned char lowByte = destPort & 0xFF; 
      0002EA 78 2B            [12] 1061 	mov	r0,#_WIZnet_SetDestinationPort_PARM_2
      0002EC E2               [24] 1062 	movx	a,@r0
      0002ED FE               [12] 1063 	mov	r6,a
                                   1064 ;	optimized_main.c:141: WIZnet_Write(Sn_DPORT,sock, highByte); // Set port high byte (5000 = 0x1388)
      0002EE 78 19            [12] 1065 	mov	r0,#_WIZnet_Write_PARM_2
      0002F0 EF               [12] 1066 	mov	a,r7
      0002F1 F2               [24] 1067 	movx	@r0,a
      0002F2 90 00 10         [24] 1068 	mov	dptr,#0x0010
      0002F5 C0 07            [24] 1069 	push	ar7
      0002F7 C0 06            [24] 1070 	push	ar6
      0002F9 12 01 18         [24] 1071 	lcall	_WIZnet_Write
      0002FC D0 06            [24] 1072 	pop	ar6
      0002FE D0 07            [24] 1073 	pop	ar7
                                   1074 ;	optimized_main.c:142: WIZnet_Write(Sn_DPORT+1, sock, lowByte);  // Set port low byte
      000300 78 19            [12] 1075 	mov	r0,#_WIZnet_Write_PARM_2
      000302 EF               [12] 1076 	mov	a,r7
      000303 F2               [24] 1077 	movx	@r0,a
      000304 78 1A            [12] 1078 	mov	r0,#_WIZnet_Write_PARM_3
      000306 EE               [12] 1079 	mov	a,r6
      000307 F2               [24] 1080 	movx	@r0,a
      000308 90 00 11         [24] 1081 	mov	dptr,#0x0011
                                   1082 ;	optimized_main.c:143: }
      00030B 02 01 18         [24] 1083 	ljmp	_WIZnet_Write
                                   1084 ;------------------------------------------------------------
                                   1085 ;Allocation info for local variables in function 'WIZnet_SetDestinationIP'
                                   1086 ;------------------------------------------------------------
                                   1087 ;	optimized_main.c:146: void WIZnet_SetDestinationIP(unsigned char *ip, unsigned char sock) {
                                   1088 ;	-----------------------------------------
                                   1089 ;	 function WIZnet_SetDestinationIP
                                   1090 ;	-----------------------------------------
      00030E                       1091 _WIZnet_SetDestinationIP:
                                   1092 ;	optimized_main.c:149: WIZnet_Write(0x000C,sock, ip[0]);
      00030E AD 82            [24] 1093 	mov	r5,dpl
      000310 AE 83            [24] 1094 	mov	r6,dph
      000312 AF F0            [24] 1095 	mov	r7,b
      000314 78 1A            [12] 1096 	mov	r0,#_WIZnet_Write_PARM_3
      000316 12 1B 12         [24] 1097 	lcall	__gptrget
      000319 F2               [24] 1098 	movx	@r0,a
      00031A 78 2D            [12] 1099 	mov	r0,#_WIZnet_SetDestinationIP_PARM_2
      00031C 79 19            [12] 1100 	mov	r1,#_WIZnet_Write_PARM_2
      00031E E2               [24] 1101 	movx	a,@r0
      00031F F3               [24] 1102 	movx	@r1,a
      000320 90 00 0C         [24] 1103 	mov	dptr,#0x000c
      000323 C0 07            [24] 1104 	push	ar7
      000325 C0 06            [24] 1105 	push	ar6
      000327 C0 05            [24] 1106 	push	ar5
      000329 12 01 18         [24] 1107 	lcall	_WIZnet_Write
      00032C D0 05            [24] 1108 	pop	ar5
      00032E D0 06            [24] 1109 	pop	ar6
      000330 D0 07            [24] 1110 	pop	ar7
                                   1111 ;	optimized_main.c:150: WIZnet_Write(0x000D,sock, ip[1]);
      000332 74 01            [12] 1112 	mov	a,#0x01
      000334 2D               [12] 1113 	add	a, r5
      000335 FA               [12] 1114 	mov	r2,a
      000336 E4               [12] 1115 	clr	a
      000337 3E               [12] 1116 	addc	a, r6
      000338 FB               [12] 1117 	mov	r3,a
      000339 8F 04            [24] 1118 	mov	ar4,r7
      00033B 8A 82            [24] 1119 	mov	dpl,r2
      00033D 8B 83            [24] 1120 	mov	dph,r3
      00033F 8C F0            [24] 1121 	mov	b,r4
      000341 78 1A            [12] 1122 	mov	r0,#_WIZnet_Write_PARM_3
      000343 12 1B 12         [24] 1123 	lcall	__gptrget
      000346 F2               [24] 1124 	movx	@r0,a
      000347 78 2D            [12] 1125 	mov	r0,#_WIZnet_SetDestinationIP_PARM_2
      000349 79 19            [12] 1126 	mov	r1,#_WIZnet_Write_PARM_2
      00034B E2               [24] 1127 	movx	a,@r0
      00034C F3               [24] 1128 	movx	@r1,a
      00034D 90 00 0D         [24] 1129 	mov	dptr,#0x000d
      000350 C0 07            [24] 1130 	push	ar7
      000352 C0 06            [24] 1131 	push	ar6
      000354 C0 05            [24] 1132 	push	ar5
      000356 12 01 18         [24] 1133 	lcall	_WIZnet_Write
      000359 D0 05            [24] 1134 	pop	ar5
      00035B D0 06            [24] 1135 	pop	ar6
      00035D D0 07            [24] 1136 	pop	ar7
                                   1137 ;	optimized_main.c:151: WIZnet_Write(0x000E,sock, ip[2]);
      00035F 74 02            [12] 1138 	mov	a,#0x02
      000361 2D               [12] 1139 	add	a, r5
      000362 FA               [12] 1140 	mov	r2,a
      000363 E4               [12] 1141 	clr	a
      000364 3E               [12] 1142 	addc	a, r6
      000365 FB               [12] 1143 	mov	r3,a
      000366 8F 04            [24] 1144 	mov	ar4,r7
      000368 8A 82            [24] 1145 	mov	dpl,r2
      00036A 8B 83            [24] 1146 	mov	dph,r3
      00036C 8C F0            [24] 1147 	mov	b,r4
      00036E 78 1A            [12] 1148 	mov	r0,#_WIZnet_Write_PARM_3
      000370 12 1B 12         [24] 1149 	lcall	__gptrget
      000373 F2               [24] 1150 	movx	@r0,a
      000374 78 2D            [12] 1151 	mov	r0,#_WIZnet_SetDestinationIP_PARM_2
      000376 79 19            [12] 1152 	mov	r1,#_WIZnet_Write_PARM_2
      000378 E2               [24] 1153 	movx	a,@r0
      000379 F3               [24] 1154 	movx	@r1,a
      00037A 90 00 0E         [24] 1155 	mov	dptr,#0x000e
      00037D C0 07            [24] 1156 	push	ar7
      00037F C0 06            [24] 1157 	push	ar6
      000381 C0 05            [24] 1158 	push	ar5
      000383 12 01 18         [24] 1159 	lcall	_WIZnet_Write
      000386 D0 05            [24] 1160 	pop	ar5
      000388 D0 06            [24] 1161 	pop	ar6
      00038A D0 07            [24] 1162 	pop	ar7
                                   1163 ;	optimized_main.c:152: WIZnet_Write(0x000F,sock, ip[3]);
      00038C 74 03            [12] 1164 	mov	a,#0x03
      00038E 2D               [12] 1165 	add	a, r5
      00038F FD               [12] 1166 	mov	r5,a
      000390 E4               [12] 1167 	clr	a
      000391 3E               [12] 1168 	addc	a, r6
      000392 FE               [12] 1169 	mov	r6,a
      000393 8D 82            [24] 1170 	mov	dpl,r5
      000395 8E 83            [24] 1171 	mov	dph,r6
      000397 8F F0            [24] 1172 	mov	b,r7
      000399 78 1A            [12] 1173 	mov	r0,#_WIZnet_Write_PARM_3
      00039B 12 1B 12         [24] 1174 	lcall	__gptrget
      00039E F2               [24] 1175 	movx	@r0,a
      00039F 78 2D            [12] 1176 	mov	r0,#_WIZnet_SetDestinationIP_PARM_2
      0003A1 79 19            [12] 1177 	mov	r1,#_WIZnet_Write_PARM_2
      0003A3 E2               [24] 1178 	movx	a,@r0
      0003A4 F3               [24] 1179 	movx	@r1,a
      0003A5 90 00 0F         [24] 1180 	mov	dptr,#0x000f
                                   1181 ;	optimized_main.c:154: }
      0003A8 02 01 18         [24] 1182 	ljmp	_WIZnet_Write
                                   1183 ;------------------------------------------------------------
                                   1184 ;Allocation info for local variables in function 'Wiznet_SendPacket'
                                   1185 ;------------------------------------------------------------
                                   1186 ;	optimized_main.c:157: void Wiznet_SendPacket(unsigned char sock)
                                   1187 ;	-----------------------------------------
                                   1188 ;	 function Wiznet_SendPacket
                                   1189 ;	-----------------------------------------
      0003AB                       1190 _Wiznet_SendPacket:
      0003AB AF 82            [24] 1191 	mov	r7, dpl
                                   1192 ;	optimized_main.c:159: WIZnet_Write(Sn_CR, sock, 0x20); // Send the data in the TX buffer
      0003AD 78 19            [12] 1193 	mov	r0,#_WIZnet_Write_PARM_2
      0003AF EF               [12] 1194 	mov	a,r7
      0003B0 F2               [24] 1195 	movx	@r0,a
      0003B1 78 1A            [12] 1196 	mov	r0,#_WIZnet_Write_PARM_3
      0003B3 74 20            [12] 1197 	mov	a,#0x20
      0003B5 F2               [24] 1198 	movx	@r0,a
      0003B6 90 00 01         [24] 1199 	mov	dptr,#0x0001
      0003B9 C0 07            [24] 1200 	push	ar7
      0003BB 12 01 18         [24] 1201 	lcall	_WIZnet_Write
      0003BE D0 07            [24] 1202 	pop	ar7
                                   1203 ;	optimized_main.c:160: while(WIZnet_Read(Sn_CR, sock) != 0x00) // Wait until the socket is ready to send data
      0003C0                       1204 00101$:
      0003C0 78 1B            [12] 1205 	mov	r0,#_WIZnet_Read_PARM_2
      0003C2 EF               [12] 1206 	mov	a,r7
      0003C3 F2               [24] 1207 	movx	@r0,a
      0003C4 90 00 01         [24] 1208 	mov	dptr,#0x0001
      0003C7 C0 07            [24] 1209 	push	ar7
      0003C9 12 01 32         [24] 1210 	lcall	_WIZnet_Read
      0003CC E5 82            [12] 1211 	mov	a, dpl
      0003CE D0 07            [24] 1212 	pop	ar7
      0003D0 70 EE            [24] 1213 	jnz	00101$
                                   1214 ;	optimized_main.c:164: }
      0003D2 22               [24] 1215 	ret
                                   1216 ;------------------------------------------------------------
                                   1217 ;Allocation info for local variables in function 'setRxBufferSize'
                                   1218 ;------------------------------------------------------------
                                   1219 ;	optimized_main.c:167: void setRxBufferSize(unsigned char sock) //of socket n
                                   1220 ;	-----------------------------------------
                                   1221 ;	 function setRxBufferSize
                                   1222 ;	-----------------------------------------
      0003D3                       1223 _setRxBufferSize:
      0003D3 AF 82            [24] 1224 	mov	r7, dpl
                                   1225 ;	optimized_main.c:169: WIZnet_Write(Sn_BUF_SIZE, sock,0x10); // write 0x10 to the RX buffer size register
      0003D5 78 19            [12] 1226 	mov	r0,#_WIZnet_Write_PARM_2
      0003D7 EF               [12] 1227 	mov	a,r7
      0003D8 F2               [24] 1228 	movx	@r0,a
      0003D9 78 1A            [12] 1229 	mov	r0,#_WIZnet_Write_PARM_3
      0003DB 74 10            [12] 1230 	mov	a,#0x10
      0003DD F2               [24] 1231 	movx	@r0,a
      0003DE 90 00 1E         [24] 1232 	mov	dptr,#0x001e
                                   1233 ;	optimized_main.c:170: }
      0003E1 02 01 18         [24] 1234 	ljmp	_WIZnet_Write
                                   1235 ;------------------------------------------------------------
                                   1236 ;Allocation info for local variables in function 'getRxReadPointer'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	optimized_main.c:173: unsigned short getRxReadPointer(unsigned char sock) // of socket n
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function getRxReadPointer
                                   1241 ;	-----------------------------------------
      0003E4                       1242 _getRxReadPointer:
      0003E4 AF 82            [24] 1243 	mov	r7, dpl
                                   1244 ;	optimized_main.c:175: unsigned char highByte = WIZnet_Read(Sn_RX_PTR+2, sock); // Read the high byte of the RX read pointer.
      0003E6 78 1B            [12] 1245 	mov	r0,#_WIZnet_Read_PARM_2
      0003E8 EF               [12] 1246 	mov	a,r7
      0003E9 F2               [24] 1247 	movx	@r0,a
      0003EA 90 00 28         [24] 1248 	mov	dptr,#0x0028
      0003ED C0 07            [24] 1249 	push	ar7
      0003EF 12 01 32         [24] 1250 	lcall	_WIZnet_Read
      0003F2 AE 82            [24] 1251 	mov	r6, dpl
      0003F4 D0 07            [24] 1252 	pop	ar7
                                   1253 ;	optimized_main.c:176: unsigned char lowByte = WIZnet_Read(Sn_RX_PTR+3, sock); // Read the low byte of the RX read pointer
      0003F6 78 1B            [12] 1254 	mov	r0,#_WIZnet_Read_PARM_2
      0003F8 EF               [12] 1255 	mov	a,r7
      0003F9 F2               [24] 1256 	movx	@r0,a
      0003FA 90 00 29         [24] 1257 	mov	dptr,#0x0029
      0003FD C0 06            [24] 1258 	push	ar6
      0003FF 12 01 32         [24] 1259 	lcall	_WIZnet_Read
      000402 AF 82            [24] 1260 	mov	r7, dpl
      000404 D0 06            [24] 1261 	pop	ar6
                                   1262 ;	optimized_main.c:178: return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
      000406 8E 05            [24] 1263 	mov	ar5,r6
      000408 E4               [12] 1264 	clr	a
      000409 FE               [12] 1265 	mov	r6,a
      00040A FC               [12] 1266 	mov	r4,a
      00040B EF               [12] 1267 	mov	a,r7
      00040C 42 06            [12] 1268 	orl	ar6,a
      00040E EC               [12] 1269 	mov	a,r4
      00040F 42 05            [12] 1270 	orl	ar5,a
      000411 8E 82            [24] 1271 	mov	dpl,r6
      000413 8D 83            [24] 1272 	mov	dph,r5
                                   1273 ;	optimized_main.c:179: }
      000415 22               [24] 1274 	ret
                                   1275 ;------------------------------------------------------------
                                   1276 ;Allocation info for local variables in function 'getRxWritePointer'
                                   1277 ;------------------------------------------------------------
                                   1278 ;	optimized_main.c:182: unsigned short getRxWritePointer(unsigned char sock) // of socket n
                                   1279 ;	-----------------------------------------
                                   1280 ;	 function getRxWritePointer
                                   1281 ;	-----------------------------------------
      000416                       1282 _getRxWritePointer:
      000416 AF 82            [24] 1283 	mov	r7, dpl
                                   1284 ;	optimized_main.c:184: unsigned char highByte = WIZnet_Read(Sn_RX_PTR+4, sock); // Read the high byte of the RX read pointer.
      000418 78 1B            [12] 1285 	mov	r0,#_WIZnet_Read_PARM_2
      00041A EF               [12] 1286 	mov	a,r7
      00041B F2               [24] 1287 	movx	@r0,a
      00041C 90 00 2A         [24] 1288 	mov	dptr,#0x002a
      00041F C0 07            [24] 1289 	push	ar7
      000421 12 01 32         [24] 1290 	lcall	_WIZnet_Read
      000424 AE 82            [24] 1291 	mov	r6, dpl
      000426 D0 07            [24] 1292 	pop	ar7
                                   1293 ;	optimized_main.c:185: unsigned char lowByte = WIZnet_Read(Sn_RX_PTR+5, sock); // Read the low byte of the RX read pointer
      000428 78 1B            [12] 1294 	mov	r0,#_WIZnet_Read_PARM_2
      00042A EF               [12] 1295 	mov	a,r7
      00042B F2               [24] 1296 	movx	@r0,a
      00042C 90 00 2B         [24] 1297 	mov	dptr,#0x002b
      00042F C0 06            [24] 1298 	push	ar6
      000431 12 01 32         [24] 1299 	lcall	_WIZnet_Read
      000434 AF 82            [24] 1300 	mov	r7, dpl
      000436 D0 06            [24] 1301 	pop	ar6
                                   1302 ;	optimized_main.c:187: return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
      000438 8E 05            [24] 1303 	mov	ar5,r6
      00043A E4               [12] 1304 	clr	a
      00043B FE               [12] 1305 	mov	r6,a
      00043C FC               [12] 1306 	mov	r4,a
      00043D EF               [12] 1307 	mov	a,r7
      00043E 42 06            [12] 1308 	orl	ar6,a
      000440 EC               [12] 1309 	mov	a,r4
      000441 42 05            [12] 1310 	orl	ar5,a
      000443 8E 82            [24] 1311 	mov	dpl,r6
      000445 8D 83            [24] 1312 	mov	dph,r5
                                   1313 ;	optimized_main.c:188: }
      000447 22               [24] 1314 	ret
                                   1315 ;------------------------------------------------------------
                                   1316 ;Allocation info for local variables in function 'getTxReadPointer'
                                   1317 ;------------------------------------------------------------
                                   1318 ;	optimized_main.c:190: unsigned short getTxReadPointer(unsigned char sock) // of socket n
                                   1319 ;	-----------------------------------------
                                   1320 ;	 function getTxReadPointer
                                   1321 ;	-----------------------------------------
      000448                       1322 _getTxReadPointer:
      000448 AF 82            [24] 1323 	mov	r7, dpl
                                   1324 ;	optimized_main.c:192: unsigned char highByte = WIZnet_Read(Sn_TX_PTR, sock); // Read the high byte of the RX read pointer.
      00044A 78 1B            [12] 1325 	mov	r0,#_WIZnet_Read_PARM_2
      00044C EF               [12] 1326 	mov	a,r7
      00044D F2               [24] 1327 	movx	@r0,a
      00044E 90 00 22         [24] 1328 	mov	dptr,#0x0022
      000451 C0 07            [24] 1329 	push	ar7
      000453 12 01 32         [24] 1330 	lcall	_WIZnet_Read
      000456 AE 82            [24] 1331 	mov	r6, dpl
      000458 D0 07            [24] 1332 	pop	ar7
                                   1333 ;	optimized_main.c:193: unsigned char lowByte = WIZnet_Read(Sn_TX_PTR+1, sock); // Read the low byte of the RX read pointer
      00045A 78 1B            [12] 1334 	mov	r0,#_WIZnet_Read_PARM_2
      00045C EF               [12] 1335 	mov	a,r7
      00045D F2               [24] 1336 	movx	@r0,a
      00045E 90 00 23         [24] 1337 	mov	dptr,#0x0023
      000461 C0 06            [24] 1338 	push	ar6
      000463 12 01 32         [24] 1339 	lcall	_WIZnet_Read
      000466 AF 82            [24] 1340 	mov	r7, dpl
      000468 D0 06            [24] 1341 	pop	ar6
                                   1342 ;	optimized_main.c:195: return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
      00046A 8E 05            [24] 1343 	mov	ar5,r6
      00046C E4               [12] 1344 	clr	a
      00046D FE               [12] 1345 	mov	r6,a
      00046E FC               [12] 1346 	mov	r4,a
      00046F EF               [12] 1347 	mov	a,r7
      000470 42 06            [12] 1348 	orl	ar6,a
      000472 EC               [12] 1349 	mov	a,r4
      000473 42 05            [12] 1350 	orl	ar5,a
      000475 8E 82            [24] 1351 	mov	dpl,r6
      000477 8D 83            [24] 1352 	mov	dph,r5
                                   1353 ;	optimized_main.c:196: }
      000479 22               [24] 1354 	ret
                                   1355 ;------------------------------------------------------------
                                   1356 ;Allocation info for local variables in function 'getTxWritePointer'
                                   1357 ;------------------------------------------------------------
                                   1358 ;	optimized_main.c:198: unsigned short getTxWritePointer(unsigned char sock) // of socket n
                                   1359 ;	-----------------------------------------
                                   1360 ;	 function getTxWritePointer
                                   1361 ;	-----------------------------------------
      00047A                       1362 _getTxWritePointer:
      00047A AF 82            [24] 1363 	mov	r7, dpl
                                   1364 ;	optimized_main.c:200: unsigned char highByte = WIZnet_Read(Sn_TX_PTR+2, sock); // Read the high byte of the RX read pointer.
      00047C 78 1B            [12] 1365 	mov	r0,#_WIZnet_Read_PARM_2
      00047E EF               [12] 1366 	mov	a,r7
      00047F F2               [24] 1367 	movx	@r0,a
      000480 90 00 24         [24] 1368 	mov	dptr,#0x0024
      000483 C0 07            [24] 1369 	push	ar7
      000485 12 01 32         [24] 1370 	lcall	_WIZnet_Read
      000488 AE 82            [24] 1371 	mov	r6, dpl
      00048A D0 07            [24] 1372 	pop	ar7
                                   1373 ;	optimized_main.c:201: unsigned char lowByte = WIZnet_Read(Sn_TX_PTR+3, sock); // Read the low byte of the RX read pointer
      00048C 78 1B            [12] 1374 	mov	r0,#_WIZnet_Read_PARM_2
      00048E EF               [12] 1375 	mov	a,r7
      00048F F2               [24] 1376 	movx	@r0,a
      000490 90 00 25         [24] 1377 	mov	dptr,#0x0025
      000493 C0 06            [24] 1378 	push	ar6
      000495 12 01 32         [24] 1379 	lcall	_WIZnet_Read
      000498 AF 82            [24] 1380 	mov	r7, dpl
      00049A D0 06            [24] 1381 	pop	ar6
                                   1382 ;	optimized_main.c:203: return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
      00049C 8E 05            [24] 1383 	mov	ar5,r6
      00049E E4               [12] 1384 	clr	a
      00049F FE               [12] 1385 	mov	r6,a
      0004A0 FC               [12] 1386 	mov	r4,a
      0004A1 EF               [12] 1387 	mov	a,r7
      0004A2 42 06            [12] 1388 	orl	ar6,a
      0004A4 EC               [12] 1389 	mov	a,r4
      0004A5 42 05            [12] 1390 	orl	ar5,a
      0004A7 8E 82            [24] 1391 	mov	dpl,r6
      0004A9 8D 83            [24] 1392 	mov	dph,r5
                                   1393 ;	optimized_main.c:204: }
      0004AB 22               [24] 1394 	ret
                                   1395 ;------------------------------------------------------------
                                   1396 ;Allocation info for local variables in function 'validateMessage'
                                   1397 ;------------------------------------------------------------
                                   1398 ;sloc1         Allocated with name '_validateMessage_sloc1_1_0'
                                   1399 ;------------------------------------------------------------
                                   1400 ;	optimized_main.c:207: unsigned char validateMessage(unsigned char* message) {
                                   1401 ;	-----------------------------------------
                                   1402 ;	 function validateMessage
                                   1403 ;	-----------------------------------------
      0004AC                       1404 _validateMessage:
                                   1405 ;	optimized_main.c:209: if (message[0] != ':') {
      0004AC AD 82            [24] 1406 	mov	r5,dpl
      0004AE AE 83            [24] 1407 	mov	r6,dph
      0004B0 AF F0            [24] 1408 	mov	r7,b
      0004B2 12 1B 12         [24] 1409 	lcall	__gptrget
      0004B5 FC               [12] 1410 	mov	r4,a
      0004B6 BC 3A 02         [24] 1411 	cjne	r4,#0x3a,00178$
      0004B9 80 04            [24] 1412 	sjmp	00102$
      0004BB                       1413 00178$:
                                   1414 ;	optimized_main.c:210: return 0;
      0004BB 75 82 00         [24] 1415 	mov	dpl, #0x00
      0004BE 22               [24] 1416 	ret
      0004BF                       1417 00102$:
                                   1418 ;	optimized_main.c:214: if (message[1] != '<') {
      0004BF 74 01            [12] 1419 	mov	a,#0x01
      0004C1 2D               [12] 1420 	add	a, r5
      0004C2 FA               [12] 1421 	mov	r2,a
      0004C3 E4               [12] 1422 	clr	a
      0004C4 3E               [12] 1423 	addc	a, r6
      0004C5 FB               [12] 1424 	mov	r3,a
      0004C6 8F 04            [24] 1425 	mov	ar4,r7
      0004C8 8A 82            [24] 1426 	mov	dpl,r2
      0004CA 8B 83            [24] 1427 	mov	dph,r3
      0004CC 8C F0            [24] 1428 	mov	b,r4
      0004CE 12 1B 12         [24] 1429 	lcall	__gptrget
      0004D1 FA               [12] 1430 	mov	r2,a
      0004D2 BA 3C 02         [24] 1431 	cjne	r2,#0x3c,00179$
      0004D5 80 04            [24] 1432 	sjmp	00104$
      0004D7                       1433 00179$:
                                   1434 ;	optimized_main.c:215: return 0;
      0004D7 75 82 00         [24] 1435 	mov	dpl, #0x00
      0004DA 22               [24] 1436 	ret
      0004DB                       1437 00104$:
                                   1438 ;	optimized_main.c:219: if (!isdigit(message[2])) {
      0004DB 74 02            [12] 1439 	mov	a,#0x02
      0004DD 2D               [12] 1440 	add	a, r5
      0004DE FA               [12] 1441 	mov	r2,a
      0004DF E4               [12] 1442 	clr	a
      0004E0 3E               [12] 1443 	addc	a, r6
      0004E1 FB               [12] 1444 	mov	r3,a
      0004E2 8F 04            [24] 1445 	mov	ar4,r7
      0004E4 8A 82            [24] 1446 	mov	dpl,r2
      0004E6 8B 83            [24] 1447 	mov	dph,r3
      0004E8 8C F0            [24] 1448 	mov	b,r4
      0004EA 12 1B 12         [24] 1449 	lcall	__gptrget
      0004ED FA               [12] 1450 	mov	r2,a
      0004EE 7C 00            [12] 1451 	mov	r4,#0x00
                                   1452 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0004F0 8A 03            [24] 1453 	mov	ar3,r2
      0004F2 BB 30 00         [24] 1454 	cjne	r3,#0x30,00180$
      0004F5                       1455 00180$:
      0004F5 92 00            [24] 1456 	mov	_validateMessage_sloc0_1_0,c
      0004F7 40 07            [24] 1457 	jc	00122$
      0004F9 EB               [12] 1458 	mov	a,r3
      0004FA 24 C6            [12] 1459 	add	a,#0xff - 0x39
      0004FC 92 00            [24] 1460 	mov	_validateMessage_sloc0_1_0,c
      0004FE 50 04            [24] 1461 	jnc	00106$
      000500                       1462 00122$:
                                   1463 ;	optimized_main.c:220: return 0;
      000500 75 82 00         [24] 1464 	mov	dpl, #0x00
      000503 22               [24] 1465 	ret
      000504                       1466 00106$:
                                   1467 ;	optimized_main.c:224: if ((message[2] - '0') != rtu) {
      000504 C0 05            [24] 1468 	push	ar5
      000506 C0 06            [24] 1469 	push	ar6
      000508 C0 07            [24] 1470 	push	ar7
      00050A EA               [12] 1471 	mov	a,r2
      00050B 24 D0            [12] 1472 	add	a,#0xd0
      00050D FA               [12] 1473 	mov	r2,a
      00050E EC               [12] 1474 	mov	a,r4
      00050F 34 FF            [12] 1475 	addc	a,#0xff
      000511 FC               [12] 1476 	mov	r4,a
      000512 78 17            [12] 1477 	mov	r0,#_rtu
      000514 E2               [24] 1478 	movx	a,@r0
      000515 FB               [12] 1479 	mov	r3,a
      000516 7F 00            [12] 1480 	mov	r7,#0x00
      000518 EA               [12] 1481 	mov	a,r2
      000519 B5 03 0C         [24] 1482 	cjne	a,ar3,00183$
      00051C EC               [12] 1483 	mov	a,r4
      00051D B5 07 08         [24] 1484 	cjne	a,ar7,00183$
      000520 D0 07            [24] 1485 	pop	ar7
      000522 D0 06            [24] 1486 	pop	ar6
      000524 D0 05            [24] 1487 	pop	ar5
      000526 80 0A            [24] 1488 	sjmp	00132$
      000528                       1489 00183$:
      000528 D0 07            [24] 1490 	pop	ar7
      00052A D0 06            [24] 1491 	pop	ar6
      00052C D0 05            [24] 1492 	pop	ar5
                                   1493 ;	optimized_main.c:225: return 0;
      00052E 75 82 00         [24] 1494 	mov	dpl, #0x00
      000531 22               [24] 1495 	ret
                                   1496 ;	optimized_main.c:229: for (int i = 3; message[i] != '\0' && message[i] != '>'; i++) {
      000532                       1497 00132$:
      000532 78 2E            [12] 1498 	mov	r0,#_validateMessage_i_20000_129
      000534 74 03            [12] 1499 	mov	a,#0x03
      000536 F2               [24] 1500 	movx	@r0,a
      000537 E4               [12] 1501 	clr	a
      000538 08               [12] 1502 	inc	r0
      000539 F2               [24] 1503 	movx	@r0,a
      00053A                       1504 00116$:
      00053A 78 2E            [12] 1505 	mov	r0,#_validateMessage_i_20000_129
      00053C E2               [24] 1506 	movx	a,@r0
      00053D 2D               [12] 1507 	add	a, r5
      00053E FA               [12] 1508 	mov	r2,a
      00053F 08               [12] 1509 	inc	r0
      000540 E2               [24] 1510 	movx	a,@r0
      000541 3E               [12] 1511 	addc	a, r6
      000542 FB               [12] 1512 	mov	r3,a
      000543 8F 04            [24] 1513 	mov	ar4,r7
      000545 8A 82            [24] 1514 	mov	dpl,r2
      000547 8B 83            [24] 1515 	mov	dph,r3
      000549 8C F0            [24] 1516 	mov	b,r4
      00054B 12 1B 12         [24] 1517 	lcall	__gptrget
      00054E F5 08            [12] 1518 	mov	_validateMessage_sloc1_1_0,a
      000550 60 78            [24] 1519 	jz	00112$
      000552 74 3E            [12] 1520 	mov	a,#0x3e
      000554 B5 08 02         [24] 1521 	cjne	a,_validateMessage_sloc1_1_0,00185$
      000557 80 71            [24] 1522 	sjmp	00112$
      000559                       1523 00185$:
                                   1524 ;	optimized_main.c:230: if (!isalpha(message[i]) && !isspace(message[i])) {
      000559 C0 02            [24] 1525 	push	ar2
      00055B C0 03            [24] 1526 	push	ar3
      00055D C0 04            [24] 1527 	push	ar4
      00055F AB 08            [24] 1528 	mov	r3,_validateMessage_sloc1_1_0
      000561 7C 00            [12] 1529 	mov	r4,#0x00
      000563 8B 82            [24] 1530 	mov	dpl, r3
      000565 8C 83            [24] 1531 	mov	dph, r4
      000567 C0 07            [24] 1532 	push	ar7
      000569 C0 06            [24] 1533 	push	ar6
      00056B C0 05            [24] 1534 	push	ar5
      00056D C0 04            [24] 1535 	push	ar4
      00056F C0 03            [24] 1536 	push	ar3
      000571 C0 02            [24] 1537 	push	ar2
      000573 12 1A 5A         [24] 1538 	lcall	_isalpha
      000576 E5 82            [12] 1539 	mov	a, dpl
      000578 85 83 F0         [24] 1540 	mov	b, dph
      00057B D0 02            [24] 1541 	pop	ar2
      00057D D0 03            [24] 1542 	pop	ar3
      00057F D0 04            [24] 1543 	pop	ar4
      000581 D0 05            [24] 1544 	pop	ar5
      000583 D0 06            [24] 1545 	pop	ar6
      000585 D0 07            [24] 1546 	pop	ar7
      000587 D0 04            [24] 1547 	pop	ar4
      000589 D0 03            [24] 1548 	pop	ar3
      00058B D0 02            [24] 1549 	pop	ar2
      00058D 45 F0            [12] 1550 	orl	a,b
      00058F 70 2B            [24] 1551 	jnz	00117$
      000591 8A 82            [24] 1552 	mov	dpl,r2
      000593 8B 83            [24] 1553 	mov	dph,r3
      000595 8C F0            [24] 1554 	mov	b,r4
      000597 12 1B 12         [24] 1555 	lcall	__gptrget
      00059A FA               [12] 1556 	mov	r2,a
      00059B 7C 00            [12] 1557 	mov	r4,#0x00
      00059D 8A 82            [24] 1558 	mov	dpl, r2
      00059F 8C 83            [24] 1559 	mov	dph, r4
      0005A1 C0 07            [24] 1560 	push	ar7
      0005A3 C0 06            [24] 1561 	push	ar6
      0005A5 C0 05            [24] 1562 	push	ar5
      0005A7 12 1A 8A         [24] 1563 	lcall	_isspace
      0005AA E5 82            [12] 1564 	mov	a, dpl
      0005AC 85 83 F0         [24] 1565 	mov	b, dph
      0005AF D0 05            [24] 1566 	pop	ar5
      0005B1 D0 06            [24] 1567 	pop	ar6
      0005B3 D0 07            [24] 1568 	pop	ar7
      0005B5 45 F0            [12] 1569 	orl	a,b
                                   1570 ;	optimized_main.c:231: return 0;
      0005B7 70 03            [24] 1571 	jnz	00117$
      0005B9 F5 82            [12] 1572 	mov	dpl,a
      0005BB 22               [24] 1573 	ret
      0005BC                       1574 00117$:
                                   1575 ;	optimized_main.c:229: for (int i = 3; message[i] != '\0' && message[i] != '>'; i++) {
      0005BC 78 2E            [12] 1576 	mov	r0,#_validateMessage_i_20000_129
      0005BE E2               [24] 1577 	movx	a,@r0
      0005BF 24 01            [12] 1578 	add	a, #0x01
      0005C1 F2               [24] 1579 	movx	@r0,a
      0005C2 08               [12] 1580 	inc	r0
      0005C3 E2               [24] 1581 	movx	a,@r0
      0005C4 34 00            [12] 1582 	addc	a, #0x00
      0005C6 F2               [24] 1583 	movx	@r0,a
      0005C7 02 05 3A         [24] 1584 	ljmp	00116$
      0005CA                       1585 00112$:
                                   1586 ;	optimized_main.c:235: return 1;
      0005CA 75 82 01         [24] 1587 	mov	dpl, #0x01
                                   1588 ;	optimized_main.c:236: }
      0005CD 22               [24] 1589 	ret
                                   1590 ;------------------------------------------------------------
                                   1591 ;Allocation info for local variables in function 'formatResponse'
                                   1592 ;------------------------------------------------------------
                                   1593 ;sloc0         Allocated with name '_formatResponse_sloc0_1_0'
                                   1594 ;------------------------------------------------------------
                                   1595 ;	optimized_main.c:239: void formatResponse(unsigned char* input, unsigned char* output) {
                                   1596 ;	-----------------------------------------
                                   1597 ;	 function formatResponse
                                   1598 ;	-----------------------------------------
      0005CE                       1599 _formatResponse:
      0005CE AF F0            [24] 1600 	mov	r7,b
      0005D0 AE 83            [24] 1601 	mov	r6,dph
      0005D2 E5 82            [12] 1602 	mov	a,dpl
      0005D4 78 33            [12] 1603 	mov	r0,#_formatResponse_input_10000_135
      0005D6 F2               [24] 1604 	movx	@r0,a
      0005D7 EE               [12] 1605 	mov	a,r6
      0005D8 08               [12] 1606 	inc	r0
      0005D9 F2               [24] 1607 	movx	@r0,a
      0005DA EF               [12] 1608 	mov	a,r7
      0005DB 08               [12] 1609 	inc	r0
      0005DC F2               [24] 1610 	movx	@r0,a
                                   1611 ;	optimized_main.c:242: output[i++] = ':';  // Start character
      0005DD 78 30            [12] 1612 	mov	r0,#_formatResponse_PARM_2
      0005DF E2               [24] 1613 	movx	a,@r0
      0005E0 FA               [12] 1614 	mov	r2,a
      0005E1 08               [12] 1615 	inc	r0
      0005E2 E2               [24] 1616 	movx	a,@r0
      0005E3 FB               [12] 1617 	mov	r3,a
      0005E4 08               [12] 1618 	inc	r0
      0005E5 E2               [24] 1619 	movx	a,@r0
      0005E6 FC               [12] 1620 	mov	r4,a
      0005E7 8A 82            [24] 1621 	mov	dpl,r2
      0005E9 8B 83            [24] 1622 	mov	dph,r3
      0005EB 8C F0            [24] 1623 	mov	b,r4
      0005ED 74 3A            [12] 1624 	mov	a,#0x3a
      0005EF 12 1A D0         [24] 1625 	lcall	__gptrput
                                   1626 ;	optimized_main.c:243: output[i++] = '[';  // Opening bracket
      0005F2 74 01            [12] 1627 	mov	a,#0x01
      0005F4 2A               [12] 1628 	add	a, r2
      0005F5 FD               [12] 1629 	mov	r5,a
      0005F6 E4               [12] 1630 	clr	a
      0005F7 3B               [12] 1631 	addc	a, r3
      0005F8 FE               [12] 1632 	mov	r6,a
      0005F9 8C 07            [24] 1633 	mov	ar7,r4
      0005FB 8D 82            [24] 1634 	mov	dpl,r5
      0005FD 8E 83            [24] 1635 	mov	dph,r6
      0005FF 8F F0            [24] 1636 	mov	b,r7
      000601 74 5B            [12] 1637 	mov	a,#0x5b
      000603 12 1A D0         [24] 1638 	lcall	__gptrput
                                   1639 ;	optimized_main.c:244: output[i++] = rtu + '0';  // RTU address
      000606 74 02            [12] 1640 	mov	a,#0x02
      000608 2A               [12] 1641 	add	a, r2
      000609 F5 09            [12] 1642 	mov	_formatResponse_sloc0_1_0,a
      00060B E4               [12] 1643 	clr	a
      00060C 3B               [12] 1644 	addc	a, r3
      00060D F5 0A            [12] 1645 	mov	(_formatResponse_sloc0_1_0 + 1),a
      00060F 8C 0B            [24] 1646 	mov	(_formatResponse_sloc0_1_0 + 2),r4
      000611 78 17            [12] 1647 	mov	r0,#_rtu
      000613 E2               [24] 1648 	movx	a,@r0
      000614 24 30            [12] 1649 	add	a,#0x30
      000616 85 09 82         [24] 1650 	mov	dpl,_formatResponse_sloc0_1_0
      000619 85 0A 83         [24] 1651 	mov	dph,(_formatResponse_sloc0_1_0 + 1)
      00061C 85 0B F0         [24] 1652 	mov	b,(_formatResponse_sloc0_1_0 + 2)
      00061F 12 1A D0         [24] 1653 	lcall	__gptrput
                                   1654 ;	optimized_main.c:247: for (int j = 3; input[j] != '>' && input[j] != '\0'; j++) {
      000622 78 36            [12] 1655 	mov	r0,#_formatResponse_i_10000_136
      000624 74 03            [12] 1656 	mov	a,#0x03
      000626 F2               [24] 1657 	movx	@r0,a
      000627 E4               [12] 1658 	clr	a
      000628 08               [12] 1659 	inc	r0
      000629 F2               [24] 1660 	movx	@r0,a
      00062A 78 38            [12] 1661 	mov	r0,#_formatResponse_j_20000_137
      00062C 74 03            [12] 1662 	mov	a,#0x03
      00062E F2               [24] 1663 	movx	@r0,a
      00062F E4               [12] 1664 	clr	a
      000630 08               [12] 1665 	inc	r0
      000631 F2               [24] 1666 	movx	@r0,a
      000632                       1667 00104$:
      000632 78 33            [12] 1668 	mov	r0,#_formatResponse_input_10000_135
      000634 79 38            [12] 1669 	mov	r1,#_formatResponse_j_20000_137
      000636 E3               [24] 1670 	movx	a,@r1
      000637 C5 F0            [12] 1671 	xch	a,b
      000639 E2               [24] 1672 	movx	a,@r0
      00063A 25 F0            [12] 1673 	add	a,b
      00063C FD               [12] 1674 	mov	r5,a
      00063D 09               [12] 1675 	inc	r1
      00063E E3               [24] 1676 	movx	a,@r1
      00063F C5 F0            [12] 1677 	xch	a,b
      000641 08               [12] 1678 	inc	r0
      000642 E2               [24] 1679 	movx	a,@r0
      000643 35 F0            [12] 1680 	addc	a,b
      000645 FE               [12] 1681 	mov	r6,a
      000646 08               [12] 1682 	inc	r0
      000647 E2               [24] 1683 	movx	a,@r0
      000648 FF               [12] 1684 	mov	r7,a
      000649 8D 82            [24] 1685 	mov	dpl,r5
      00064B 8E 83            [24] 1686 	mov	dph,r6
      00064D 8F F0            [24] 1687 	mov	b,r7
      00064F 12 1B 12         [24] 1688 	lcall	__gptrget
      000652 F5 09            [12] 1689 	mov	_formatResponse_sloc0_1_0,a
      000654 74 3E            [12] 1690 	mov	a,#0x3e
      000656 B5 09 02         [24] 1691 	cjne	a,_formatResponse_sloc0_1_0,00127$
      000659 80 5B            [24] 1692 	sjmp	00101$
      00065B                       1693 00127$:
      00065B E5 09            [12] 1694 	mov	a,_formatResponse_sloc0_1_0
      00065D 60 57            [24] 1695 	jz	00101$
                                   1696 ;	optimized_main.c:248: output[i++] = toupper(input[j]);
      00065F 78 36            [12] 1697 	mov	r0,#_formatResponse_i_10000_136
      000661 E2               [24] 1698 	movx	a,@r0
      000662 2A               [12] 1699 	add	a, r2
      000663 FD               [12] 1700 	mov	r5,a
      000664 08               [12] 1701 	inc	r0
      000665 E2               [24] 1702 	movx	a,@r0
      000666 3B               [12] 1703 	addc	a, r3
      000667 FE               [12] 1704 	mov	r6,a
      000668 8C 07            [24] 1705 	mov	ar7,r4
      00066A 78 36            [12] 1706 	mov	r0,#_formatResponse_i_10000_136
      00066C E2               [24] 1707 	movx	a,@r0
      00066D 24 01            [12] 1708 	add	a, #0x01
      00066F F2               [24] 1709 	movx	@r0,a
      000670 08               [12] 1710 	inc	r0
      000671 E2               [24] 1711 	movx	a,@r0
      000672 34 00            [12] 1712 	addc	a, #0x00
      000674 F2               [24] 1713 	movx	@r0,a
      000675 C0 02            [24] 1714 	push	ar2
      000677 C0 03            [24] 1715 	push	ar3
      000679 C0 04            [24] 1716 	push	ar4
      00067B AB 09            [24] 1717 	mov	r3,_formatResponse_sloc0_1_0
      00067D 7C 00            [12] 1718 	mov	r4,#0x00
      00067F 8B 82            [24] 1719 	mov	dpl, r3
      000681 8C 83            [24] 1720 	mov	dph, r4
      000683 C0 07            [24] 1721 	push	ar7
      000685 C0 06            [24] 1722 	push	ar6
      000687 C0 05            [24] 1723 	push	ar5
      000689 C0 02            [24] 1724 	push	ar2
      00068B 12 1A EB         [24] 1725 	lcall	_toupper
      00068E AB 82            [24] 1726 	mov	r3, dpl
      000690 D0 02            [24] 1727 	pop	ar2
      000692 D0 05            [24] 1728 	pop	ar5
      000694 D0 06            [24] 1729 	pop	ar6
      000696 D0 07            [24] 1730 	pop	ar7
      000698 8D 82            [24] 1731 	mov	dpl,r5
      00069A 8E 83            [24] 1732 	mov	dph,r6
      00069C 8F F0            [24] 1733 	mov	b,r7
      00069E EB               [12] 1734 	mov	a,r3
      00069F 12 1A D0         [24] 1735 	lcall	__gptrput
                                   1736 ;	optimized_main.c:247: for (int j = 3; input[j] != '>' && input[j] != '\0'; j++) {
      0006A2 78 38            [12] 1737 	mov	r0,#_formatResponse_j_20000_137
      0006A4 E2               [24] 1738 	movx	a,@r0
      0006A5 24 01            [12] 1739 	add	a, #0x01
      0006A7 F2               [24] 1740 	movx	@r0,a
      0006A8 08               [12] 1741 	inc	r0
      0006A9 E2               [24] 1742 	movx	a,@r0
      0006AA 34 00            [12] 1743 	addc	a, #0x00
      0006AC F2               [24] 1744 	movx	@r0,a
      0006AD D0 04            [24] 1745 	pop	ar4
      0006AF D0 03            [24] 1746 	pop	ar3
      0006B1 D0 02            [24] 1747 	pop	ar2
      0006B3 02 06 32         [24] 1748 	ljmp	00104$
      0006B6                       1749 00101$:
                                   1750 ;	optimized_main.c:251: output[i++] = ']';  // Closing bracket
      0006B6 78 36            [12] 1751 	mov	r0,#_formatResponse_i_10000_136
      0006B8 E2               [24] 1752 	movx	a,@r0
      0006B9 24 01            [12] 1753 	add	a, #0x01
      0006BB F5 09            [12] 1754 	mov	_formatResponse_sloc0_1_0,a
      0006BD 08               [12] 1755 	inc	r0
      0006BE E2               [24] 1756 	movx	a,@r0
      0006BF 34 00            [12] 1757 	addc	a, #0x00
      0006C1 F5 0A            [12] 1758 	mov	(_formatResponse_sloc0_1_0 + 1),a
      0006C3 78 36            [12] 1759 	mov	r0,#_formatResponse_i_10000_136
      0006C5 E2               [24] 1760 	movx	a,@r0
      0006C6 2A               [12] 1761 	add	a, r2
      0006C7 FD               [12] 1762 	mov	r5,a
      0006C8 08               [12] 1763 	inc	r0
      0006C9 E2               [24] 1764 	movx	a,@r0
      0006CA 3B               [12] 1765 	addc	a, r3
      0006CB FE               [12] 1766 	mov	r6,a
      0006CC 8C 07            [24] 1767 	mov	ar7,r4
      0006CE 8D 82            [24] 1768 	mov	dpl,r5
      0006D0 8E 83            [24] 1769 	mov	dph,r6
      0006D2 8F F0            [24] 1770 	mov	b,r7
      0006D4 74 5D            [12] 1771 	mov	a,#0x5d
      0006D6 12 1A D0         [24] 1772 	lcall	__gptrput
                                   1773 ;	optimized_main.c:252: output[i] = '\0';   // Null terminator
      0006D9 E5 09            [12] 1774 	mov	a,_formatResponse_sloc0_1_0
      0006DB 2A               [12] 1775 	add	a, r2
      0006DC FA               [12] 1776 	mov	r2,a
      0006DD E5 0A            [12] 1777 	mov	a,(_formatResponse_sloc0_1_0 + 1)
      0006DF 3B               [12] 1778 	addc	a, r3
      0006E0 FB               [12] 1779 	mov	r3,a
      0006E1 8A 82            [24] 1780 	mov	dpl,r2
      0006E3 8B 83            [24] 1781 	mov	dph,r3
      0006E5 8C F0            [24] 1782 	mov	b,r4
      0006E7 E4               [12] 1783 	clr	a
                                   1784 ;	optimized_main.c:253: }
      0006E8 02 1A D0         [24] 1785 	ljmp	__gptrput
                                   1786 ;------------------------------------------------------------
                                   1787 ;Allocation info for local variables in function 'writeToTXBufferUDP'
                                   1788 ;------------------------------------------------------------
                                   1789 ;	optimized_main.c:256: void writeToTXBufferUDP(unsigned char sock, unsigned char socktx) {
                                   1790 ;	-----------------------------------------
                                   1791 ;	 function writeToTXBufferUDP
                                   1792 ;	-----------------------------------------
      0006EB                       1793 _writeToTXBufferUDP:
      0006EB AF 82            [24] 1794 	mov	r7, dpl
                                   1795 ;	optimized_main.c:257: RXD = 1;  // Start with LED off
                                   1796 ;	assignBit
      0006ED D2 B0            [12] 1797 	setb	_P3_0
                                   1798 ;	optimized_main.c:259: unsigned short sendPointer = getTxWritePointer(sock);
      0006EF 8F 82            [24] 1799 	mov	dpl, r7
      0006F1 C0 07            [24] 1800 	push	ar7
      0006F3 12 04 7A         [24] 1801 	lcall	_getTxWritePointer
      0006F6 AD 82            [24] 1802 	mov	r5, dpl
      0006F8 AE 83            [24] 1803 	mov	r6, dph
      0006FA D0 07            [24] 1804 	pop	ar7
                                   1805 ;	optimized_main.c:262: if(returnData[0] != '\0') {
      0006FC 78 01            [12] 1806 	mov	r0,#_returnData
      0006FE E2               [24] 1807 	movx	a,@r0
      0006FF 70 03            [24] 1808 	jnz	00144$
      000701 02 07 7C         [24] 1809 	ljmp	00103$
      000704                       1810 00144$:
                                   1811 ;	optimized_main.c:265: RXD = 0;  // Turn ON TX LED before starting transmission
                                   1812 ;	assignBit
      000704 C2 B0            [12] 1813 	clr	_P3_0
                                   1814 ;	optimized_main.c:268: for(char i = 0; returnData[i] != '\0'; i++) {
      000706 7C 00            [12] 1815 	mov	r4,#0x00
      000708                       1816 00109$:
      000708 EC               [12] 1817 	mov	a,r4
      000709 24 01            [12] 1818 	add	a, #_returnData
      00070B F9               [12] 1819 	mov	r1,a
      00070C E3               [24] 1820 	movx	a,@r1
      00070D FB               [12] 1821 	mov	r3,a
      00070E 60 31            [24] 1822 	jz	00101$
                                   1823 ;	optimized_main.c:269: WIZnet_Write(sendPointer, socktx, returnData[i]);
      000710 78 3A            [12] 1824 	mov	r0,#_writeToTXBufferUDP_PARM_2
      000712 79 19            [12] 1825 	mov	r1,#_WIZnet_Write_PARM_2
      000714 E2               [24] 1826 	movx	a,@r0
      000715 F3               [24] 1827 	movx	@r1,a
      000716 78 1A            [12] 1828 	mov	r0,#_WIZnet_Write_PARM_3
      000718 EB               [12] 1829 	mov	a,r3
      000719 F2               [24] 1830 	movx	@r0,a
      00071A 8D 82            [24] 1831 	mov	dpl, r5
      00071C 8E 83            [24] 1832 	mov	dph, r6
      00071E C0 07            [24] 1833 	push	ar7
      000720 C0 06            [24] 1834 	push	ar6
      000722 C0 05            [24] 1835 	push	ar5
      000724 C0 04            [24] 1836 	push	ar4
      000726 12 01 18         [24] 1837 	lcall	_WIZnet_Write
      000729 D0 04            [24] 1838 	pop	ar4
      00072B D0 05            [24] 1839 	pop	ar5
      00072D D0 06            [24] 1840 	pop	ar6
      00072F D0 07            [24] 1841 	pop	ar7
                                   1842 ;	optimized_main.c:270: sendPointer += 1;
      000731 8D 02            [24] 1843 	mov	ar2,r5
      000733 8E 03            [24] 1844 	mov	ar3,r6
      000735 0A               [12] 1845 	inc	r2
      000736 BA 00 01         [24] 1846 	cjne	r2,#0x00,00146$
      000739 0B               [12] 1847 	inc	r3
      00073A                       1848 00146$:
      00073A 8A 05            [24] 1849 	mov	ar5,r2
      00073C 8B 06            [24] 1850 	mov	ar6,r3
                                   1851 ;	optimized_main.c:268: for(char i = 0; returnData[i] != '\0'; i++) {
      00073E 0C               [12] 1852 	inc	r4
      00073F 80 C7            [24] 1853 	sjmp	00109$
      000741                       1854 00101$:
                                   1855 ;	optimized_main.c:274: WIZnet_Write(Sn_TX_PTR+2, sock, (sendPointer >> 8) & 0xFF);
      000741 78 1A            [12] 1856 	mov	r0,#_WIZnet_Write_PARM_3
      000743 EE               [12] 1857 	mov	a,r6
      000744 F2               [24] 1858 	movx	@r0,a
      000745 78 19            [12] 1859 	mov	r0,#_WIZnet_Write_PARM_2
      000747 EF               [12] 1860 	mov	a,r7
      000748 F2               [24] 1861 	movx	@r0,a
      000749 90 00 24         [24] 1862 	mov	dptr,#0x0024
      00074C C0 07            [24] 1863 	push	ar7
      00074E C0 06            [24] 1864 	push	ar6
      000750 C0 05            [24] 1865 	push	ar5
      000752 12 01 18         [24] 1866 	lcall	_WIZnet_Write
      000755 D0 05            [24] 1867 	pop	ar5
      000757 D0 06            [24] 1868 	pop	ar6
      000759 D0 07            [24] 1869 	pop	ar7
                                   1870 ;	optimized_main.c:275: WIZnet_Write(Sn_TX_PTR+3, sock, sendPointer & 0xFF);
      00075B 78 1A            [12] 1871 	mov	r0,#_WIZnet_Write_PARM_3
      00075D ED               [12] 1872 	mov	a,r5
      00075E F2               [24] 1873 	movx	@r0,a
      00075F 78 19            [12] 1874 	mov	r0,#_WIZnet_Write_PARM_2
      000761 EF               [12] 1875 	mov	a,r7
      000762 F2               [24] 1876 	movx	@r0,a
      000763 90 00 25         [24] 1877 	mov	dptr,#0x0025
      000766 C0 07            [24] 1878 	push	ar7
      000768 12 01 18         [24] 1879 	lcall	_WIZnet_Write
      00076B D0 07            [24] 1880 	pop	ar7
                                   1881 ;	optimized_main.c:277: Wiznet_SendPacket(sock); // Actually transmit the data
      00076D 8F 82            [24] 1882 	mov	dpl, r7
      00076F C0 07            [24] 1883 	push	ar7
      000771 12 03 AB         [24] 1884 	lcall	_Wiznet_SendPacket
      000774 D0 07            [24] 1885 	pop	ar7
                                   1886 ;	optimized_main.c:279: RXD = 1;  // Turn OFF TX LED after transmission complete
                                   1887 ;	assignBit
      000776 D2 B0            [12] 1888 	setb	_P3_0
                                   1889 ;	optimized_main.c:280: returnData[0] = '\0'; // Clear the buffer
      000778 78 01            [12] 1890 	mov	r0,#_returnData
      00077A E4               [12] 1891 	clr	a
      00077B F2               [24] 1892 	movx	@r0,a
      00077C                       1893 00103$:
                                   1894 ;	optimized_main.c:284: interrupt = WIZnet_Read(Sn_IR, sock);
      00077C 78 1B            [12] 1895 	mov	r0,#_WIZnet_Read_PARM_2
      00077E EF               [12] 1896 	mov	a,r7
      00077F F2               [24] 1897 	movx	@r0,a
      000780 90 00 02         [24] 1898 	mov	dptr,#0x0002
      000783 C0 07            [24] 1899 	push	ar7
      000785 12 01 32         [24] 1900 	lcall	_WIZnet_Read
      000788 AE 82            [24] 1901 	mov	r6, dpl
      00078A D0 07            [24] 1902 	pop	ar7
                                   1903 ;	optimized_main.c:285: if(interrupt & 0x10) { // SEND_OK
      00078C EE               [12] 1904 	mov	a,r6
      00078D 30 E4 17         [24] 1905 	jnb	acc.4,00105$
                                   1906 ;	optimized_main.c:286: WIZnet_Write(Sn_IR, sock, 0x10);
      000790 78 19            [12] 1907 	mov	r0,#_WIZnet_Write_PARM_2
      000792 EF               [12] 1908 	mov	a,r7
      000793 F2               [24] 1909 	movx	@r0,a
      000794 78 1A            [12] 1910 	mov	r0,#_WIZnet_Write_PARM_3
      000796 74 10            [12] 1911 	mov	a,#0x10
      000798 F2               [24] 1912 	movx	@r0,a
      000799 90 00 02         [24] 1913 	mov	dptr,#0x0002
      00079C C0 07            [24] 1914 	push	ar7
      00079E C0 06            [24] 1915 	push	ar6
      0007A0 12 01 18         [24] 1916 	lcall	_WIZnet_Write
      0007A3 D0 06            [24] 1917 	pop	ar6
      0007A5 D0 07            [24] 1918 	pop	ar7
      0007A7                       1919 00105$:
                                   1920 ;	optimized_main.c:288: if(interrupt & 0x08) { // TIMEOUT
      0007A7 EE               [12] 1921 	mov	a,r6
      0007A8 30 E3 0F         [24] 1922 	jnb	acc.3,00111$
                                   1923 ;	optimized_main.c:289: WIZnet_Write(Sn_IR, sock, 0x08);
      0007AB 78 19            [12] 1924 	mov	r0,#_WIZnet_Write_PARM_2
      0007AD EF               [12] 1925 	mov	a,r7
      0007AE F2               [24] 1926 	movx	@r0,a
      0007AF 78 1A            [12] 1927 	mov	r0,#_WIZnet_Write_PARM_3
      0007B1 74 08            [12] 1928 	mov	a,#0x08
      0007B3 F2               [24] 1929 	movx	@r0,a
      0007B4 90 00 02         [24] 1930 	mov	dptr,#0x0002
                                   1931 ;	optimized_main.c:291: }
      0007B7 02 01 18         [24] 1932 	ljmp	_WIZnet_Write
      0007BA                       1933 00111$:
      0007BA 22               [24] 1934 	ret
                                   1935 ;------------------------------------------------------------
                                   1936 ;Allocation info for local variables in function 'readFromRXBufferUDP'
                                   1937 ;------------------------------------------------------------
                                   1938 ;	optimized_main.c:294: void readFromRXBufferUDP(unsigned char sock, unsigned char sockrx) {
                                   1939 ;	-----------------------------------------
                                   1940 ;	 function readFromRXBufferUDP
                                   1941 ;	-----------------------------------------
      0007BB                       1942 _readFromRXBufferUDP:
      0007BB AF 82            [24] 1943 	mov	r7, dpl
                                   1944 ;	optimized_main.c:295: TXD = 1;
                                   1945 ;	assignBit
      0007BD D2 B1            [12] 1946 	setb	_P3_1
                                   1947 ;	optimized_main.c:297: returnData[0] = '\0';
      0007BF 78 01            [12] 1948 	mov	r0,#_returnData
      0007C1 E4               [12] 1949 	clr	a
      0007C2 F2               [24] 1950 	movx	@r0,a
                                   1951 ;	optimized_main.c:299: if(WIZnet_Read(Sn_RX_PTR, sock) != 0x00 || WIZnet_Read(Sn_RX_PTR+1, sock) != 0x00) {
      0007C3 78 1B            [12] 1952 	mov	r0,#_WIZnet_Read_PARM_2
      0007C5 EF               [12] 1953 	mov	a,r7
      0007C6 F2               [24] 1954 	movx	@r0,a
      0007C7 90 00 26         [24] 1955 	mov	dptr,#0x0026
      0007CA C0 07            [24] 1956 	push	ar7
      0007CC 12 01 32         [24] 1957 	lcall	_WIZnet_Read
      0007CF E5 82            [12] 1958 	mov	a, dpl
      0007D1 D0 07            [24] 1959 	pop	ar7
      0007D3 70 13            [24] 1960 	jnz	00105$
      0007D5 78 1B            [12] 1961 	mov	r0,#_WIZnet_Read_PARM_2
      0007D7 EF               [12] 1962 	mov	a,r7
      0007D8 F2               [24] 1963 	movx	@r0,a
      0007D9 90 00 27         [24] 1964 	mov	dptr,#0x0027
      0007DC C0 07            [24] 1965 	push	ar7
      0007DE 12 01 32         [24] 1966 	lcall	_WIZnet_Read
      0007E1 E5 82            [12] 1967 	mov	a, dpl
      0007E3 D0 07            [24] 1968 	pop	ar7
      0007E5 70 01            [24] 1969 	jnz	00151$
      0007E7 22               [24] 1970 	ret
      0007E8                       1971 00151$:
      0007E8                       1972 00105$:
                                   1973 ;	optimized_main.c:300: TXD = 0;
                                   1974 ;	assignBit
      0007E8 C2 B1            [12] 1975 	clr	_P3_1
                                   1976 ;	optimized_main.c:302: unsigned short readPointer = getRxReadPointer(sock);
      0007EA 8F 82            [24] 1977 	mov	dpl, r7
      0007EC C0 07            [24] 1978 	push	ar7
      0007EE 12 03 E4         [24] 1979 	lcall	_getRxReadPointer
      0007F1 AD 82            [24] 1980 	mov	r5, dpl
      0007F3 AE 83            [24] 1981 	mov	r6, dph
                                   1982 ;	optimized_main.c:308: peer_ip[0] = WIZnet_Read(readPointer, sockrx);
      0007F5 78 3B            [12] 1983 	mov	r0,#_readFromRXBufferUDP_PARM_2
      0007F7 79 1B            [12] 1984 	mov	r1,#_WIZnet_Read_PARM_2
      0007F9 E2               [24] 1985 	movx	a,@r0
      0007FA F3               [24] 1986 	movx	@r1,a
      0007FB 8D 82            [24] 1987 	mov	dpl, r5
      0007FD 8E 83            [24] 1988 	mov	dph, r6
      0007FF C0 06            [24] 1989 	push	ar6
      000801 C0 05            [24] 1990 	push	ar5
      000803 12 01 32         [24] 1991 	lcall	_WIZnet_Read
      000806 E5 82            [12] 1992 	mov	a, dpl
      000808 D0 05            [24] 1993 	pop	ar5
      00080A D0 06            [24] 1994 	pop	ar6
      00080C 78 40            [12] 1995 	mov	r0,#_readFromRXBufferUDP_peer_ip_20002_151
      00080E F2               [24] 1996 	movx	@r0,a
                                   1997 ;	optimized_main.c:309: peer_ip[1] = WIZnet_Read(readPointer+1, sockrx);
      00080F 74 01            [12] 1998 	mov	a,#0x01
      000811 2D               [12] 1999 	add	a, r5
      000812 FB               [12] 2000 	mov	r3,a
      000813 E4               [12] 2001 	clr	a
      000814 3E               [12] 2002 	addc	a, r6
      000815 FC               [12] 2003 	mov	r4,a
      000816 8B 82            [24] 2004 	mov	dpl,r3
      000818 8C 83            [24] 2005 	mov	dph,r4
      00081A 78 3B            [12] 2006 	mov	r0,#_readFromRXBufferUDP_PARM_2
      00081C 79 1B            [12] 2007 	mov	r1,#_WIZnet_Read_PARM_2
      00081E E2               [24] 2008 	movx	a,@r0
      00081F F3               [24] 2009 	movx	@r1,a
      000820 C0 06            [24] 2010 	push	ar6
      000822 C0 05            [24] 2011 	push	ar5
      000824 12 01 32         [24] 2012 	lcall	_WIZnet_Read
      000827 E5 82            [12] 2013 	mov	a, dpl
      000829 D0 05            [24] 2014 	pop	ar5
      00082B D0 06            [24] 2015 	pop	ar6
      00082D 78 41            [12] 2016 	mov	r0,#(_readFromRXBufferUDP_peer_ip_20002_151 + 0x0001)
      00082F F2               [24] 2017 	movx	@r0,a
                                   2018 ;	optimized_main.c:310: peer_ip[2] = WIZnet_Read(readPointer+2, sockrx);
      000830 74 02            [12] 2019 	mov	a,#0x02
      000832 2D               [12] 2020 	add	a, r5
      000833 FB               [12] 2021 	mov	r3,a
      000834 E4               [12] 2022 	clr	a
      000835 3E               [12] 2023 	addc	a, r6
      000836 FC               [12] 2024 	mov	r4,a
      000837 8B 82            [24] 2025 	mov	dpl,r3
      000839 8C 83            [24] 2026 	mov	dph,r4
      00083B 78 3B            [12] 2027 	mov	r0,#_readFromRXBufferUDP_PARM_2
      00083D 79 1B            [12] 2028 	mov	r1,#_WIZnet_Read_PARM_2
      00083F E2               [24] 2029 	movx	a,@r0
      000840 F3               [24] 2030 	movx	@r1,a
      000841 C0 06            [24] 2031 	push	ar6
      000843 C0 05            [24] 2032 	push	ar5
      000845 12 01 32         [24] 2033 	lcall	_WIZnet_Read
      000848 E5 82            [12] 2034 	mov	a, dpl
      00084A D0 05            [24] 2035 	pop	ar5
      00084C D0 06            [24] 2036 	pop	ar6
      00084E 78 42            [12] 2037 	mov	r0,#(_readFromRXBufferUDP_peer_ip_20002_151 + 0x0002)
      000850 F2               [24] 2038 	movx	@r0,a
                                   2039 ;	optimized_main.c:311: peer_ip[3] = WIZnet_Read(readPointer+3, sockrx);
      000851 74 03            [12] 2040 	mov	a,#0x03
      000853 2D               [12] 2041 	add	a, r5
      000854 FB               [12] 2042 	mov	r3,a
      000855 E4               [12] 2043 	clr	a
      000856 3E               [12] 2044 	addc	a, r6
      000857 FC               [12] 2045 	mov	r4,a
      000858 8B 82            [24] 2046 	mov	dpl,r3
      00085A 8C 83            [24] 2047 	mov	dph,r4
      00085C 78 3B            [12] 2048 	mov	r0,#_readFromRXBufferUDP_PARM_2
      00085E 79 1B            [12] 2049 	mov	r1,#_WIZnet_Read_PARM_2
      000860 E2               [24] 2050 	movx	a,@r0
      000861 F3               [24] 2051 	movx	@r1,a
      000862 C0 06            [24] 2052 	push	ar6
      000864 C0 05            [24] 2053 	push	ar5
      000866 12 01 32         [24] 2054 	lcall	_WIZnet_Read
      000869 E5 82            [12] 2055 	mov	a, dpl
      00086B D0 05            [24] 2056 	pop	ar5
      00086D D0 06            [24] 2057 	pop	ar6
      00086F D0 07            [24] 2058 	pop	ar7
      000871 78 43            [12] 2059 	mov	r0,#(_readFromRXBufferUDP_peer_ip_20002_151 + 0x0003)
      000873 F2               [24] 2060 	movx	@r0,a
                                   2061 ;	optimized_main.c:313: WIZnet_SetDestinationIP(peer_ip, sock);
      000874 78 2D            [12] 2062 	mov	r0,#_WIZnet_SetDestinationIP_PARM_2
      000876 EF               [12] 2063 	mov	a,r7
      000877 F2               [24] 2064 	movx	@r0,a
      000878 90 00 40         [24] 2065 	mov	dptr,#_readFromRXBufferUDP_peer_ip_20002_151
      00087B 75 F0 60         [24] 2066 	mov	b, #0x60
      00087E C0 07            [24] 2067 	push	ar7
      000880 C0 06            [24] 2068 	push	ar6
      000882 C0 05            [24] 2069 	push	ar5
      000884 12 03 0E         [24] 2070 	lcall	_WIZnet_SetDestinationIP
      000887 D0 05            [24] 2071 	pop	ar5
      000889 D0 06            [24] 2072 	pop	ar6
      00088B D0 07            [24] 2073 	pop	ar7
                                   2074 ;	optimized_main.c:314: WIZnet_SetDestinationPort(sock, 5000);
      00088D 78 2B            [12] 2075 	mov	r0,#_WIZnet_SetDestinationPort_PARM_2
      00088F 74 88            [12] 2076 	mov	a,#0x88
      000891 F2               [24] 2077 	movx	@r0,a
      000892 74 13            [12] 2078 	mov	a,#0x13
      000894 08               [12] 2079 	inc	r0
      000895 F2               [24] 2080 	movx	@r0,a
      000896 8F 82            [24] 2081 	mov	dpl, r7
      000898 C0 07            [24] 2082 	push	ar7
      00089A C0 06            [24] 2083 	push	ar6
      00089C C0 05            [24] 2084 	push	ar5
      00089E 12 02 E1         [24] 2085 	lcall	_WIZnet_SetDestinationPort
      0008A1 D0 05            [24] 2086 	pop	ar5
      0008A3 D0 06            [24] 2087 	pop	ar6
                                   2088 ;	optimized_main.c:316: getSize = ((WIZnet_Read(readPointer+6, sockrx) << 8) | 
      0008A5 74 06            [12] 2089 	mov	a,#0x06
      0008A7 2D               [12] 2090 	add	a, r5
      0008A8 FB               [12] 2091 	mov	r3,a
      0008A9 E4               [12] 2092 	clr	a
      0008AA 3E               [12] 2093 	addc	a, r6
      0008AB FC               [12] 2094 	mov	r4,a
      0008AC 8B 82            [24] 2095 	mov	dpl,r3
      0008AE 8C 83            [24] 2096 	mov	dph,r4
      0008B0 78 3B            [12] 2097 	mov	r0,#_readFromRXBufferUDP_PARM_2
      0008B2 79 1B            [12] 2098 	mov	r1,#_WIZnet_Read_PARM_2
      0008B4 E2               [24] 2099 	movx	a,@r0
      0008B5 F3               [24] 2100 	movx	@r1,a
      0008B6 C0 06            [24] 2101 	push	ar6
      0008B8 C0 05            [24] 2102 	push	ar5
      0008BA 12 01 32         [24] 2103 	lcall	_WIZnet_Read
      0008BD AC 82            [24] 2104 	mov	r4, dpl
      0008BF D0 05            [24] 2105 	pop	ar5
      0008C1 D0 06            [24] 2106 	pop	ar6
      0008C3 8C 03            [24] 2107 	mov	ar3,r4
      0008C5 7C 00            [12] 2108 	mov	r4,#0x00
                                   2109 ;	optimized_main.c:317: WIZnet_Read(readPointer+7, sockrx));
      0008C7 74 07            [12] 2110 	mov	a,#0x07
      0008C9 2D               [12] 2111 	add	a, r5
      0008CA FA               [12] 2112 	mov	r2,a
      0008CB E4               [12] 2113 	clr	a
      0008CC 3E               [12] 2114 	addc	a, r6
      0008CD FF               [12] 2115 	mov	r7,a
      0008CE 8A 82            [24] 2116 	mov	dpl,r2
      0008D0 8F 83            [24] 2117 	mov	dph,r7
      0008D2 78 3B            [12] 2118 	mov	r0,#_readFromRXBufferUDP_PARM_2
      0008D4 79 1B            [12] 2119 	mov	r1,#_WIZnet_Read_PARM_2
      0008D6 E2               [24] 2120 	movx	a,@r0
      0008D7 F3               [24] 2121 	movx	@r1,a
      0008D8 C0 06            [24] 2122 	push	ar6
      0008DA C0 05            [24] 2123 	push	ar5
      0008DC C0 04            [24] 2124 	push	ar4
      0008DE C0 03            [24] 2125 	push	ar3
      0008E0 12 01 32         [24] 2126 	lcall	_WIZnet_Read
      0008E3 AF 82            [24] 2127 	mov	r7, dpl
      0008E5 D0 03            [24] 2128 	pop	ar3
      0008E7 D0 04            [24] 2129 	pop	ar4
      0008E9 D0 05            [24] 2130 	pop	ar5
      0008EB D0 06            [24] 2131 	pop	ar6
      0008ED 7A 00            [12] 2132 	mov	r2,#0x00
      0008EF EF               [12] 2133 	mov	a,r7
      0008F0 42 04            [12] 2134 	orl	ar4,a
      0008F2 EA               [12] 2135 	mov	a,r2
      0008F3 42 03            [12] 2136 	orl	ar3,a
      0008F5 78 3E            [12] 2137 	mov	r0,#_readFromRXBufferUDP_getSize_20002_151
      0008F7 EC               [12] 2138 	mov	a,r4
      0008F8 F2               [24] 2139 	movx	@r0,a
      0008F9 EB               [12] 2140 	mov	a,r3
      0008FA 08               [12] 2141 	inc	r0
      0008FB F2               [24] 2142 	movx	@r0,a
                                   2143 ;	optimized_main.c:319: readPointer += 8;
      0008FC 74 08            [12] 2144 	mov	a,#0x08
      0008FE 2D               [12] 2145 	add	a, r5
      0008FF FD               [12] 2146 	mov	r5,a
      000900 E4               [12] 2147 	clr	a
      000901 3E               [12] 2148 	addc	a, r6
      000902 FE               [12] 2149 	mov	r6,a
      000903 78 3C            [12] 2150 	mov	r0,#_readFromRXBufferUDP_readPointer_20002_151
      000905 ED               [12] 2151 	mov	a,r5
      000906 F2               [24] 2152 	movx	@r0,a
      000907 EE               [12] 2153 	mov	a,r6
      000908 08               [12] 2154 	inc	r0
      000909 F2               [24] 2155 	movx	@r0,a
                                   2156 ;	optimized_main.c:322: for(int i = 0; i < getSize && i < sizeof(tempBuffer)-1; i++) {
      00090A 7A 00            [12] 2157 	mov	r2,#0x00
                                   2158 ;	optimized_main.c:341: TXD = 1;
      00090C D0 07            [24] 2159 	pop	ar7
                                   2160 ;	optimized_main.c:322: for(int i = 0; i < getSize && i < sizeof(tempBuffer)-1; i++) {
      00090E                       2161 00110$:
      00090E 8A 05            [24] 2162 	mov	ar5,r2
      000910 7E 00            [12] 2163 	mov	r6,#0x00
      000912 78 3E            [12] 2164 	mov	r0,#_readFromRXBufferUDP_getSize_20002_151
      000914 C3               [12] 2165 	clr	c
      000915 E2               [24] 2166 	movx	a,@r0
      000916 F5 F0            [12] 2167 	mov	b,a
      000918 ED               [12] 2168 	mov	a,r5
      000919 95 F0            [12] 2169 	subb	a,b
      00091B 08               [12] 2170 	inc	r0
      00091C E2               [24] 2171 	movx	a,@r0
      00091D F5 F0            [12] 2172 	mov	b,a
      00091F EE               [12] 2173 	mov	a,r6
      000920 95 F0            [12] 2174 	subb	a,b
      000922 50 3D            [24] 2175 	jnc	00101$
      000924 BA 15 00         [24] 2176 	cjne	r2,#0x15,00153$
      000927                       2177 00153$:
      000927 50 38            [24] 2178 	jnc	00101$
                                   2179 ;	optimized_main.c:323: tempBuffer[i] = WIZnet_Read(readPointer+i, sockrx);
      000929 EA               [12] 2180 	mov	a,r2
      00092A 24 44            [12] 2181 	add	a, #_readFromRXBufferUDP_tempBuffer_20002_151
      00092C F9               [12] 2182 	mov	r1,a
      00092D 78 3C            [12] 2183 	mov	r0,#_readFromRXBufferUDP_readPointer_20002_151
      00092F E2               [24] 2184 	movx	a,@r0
      000930 FD               [12] 2185 	mov	r5,a
      000931 08               [12] 2186 	inc	r0
      000932 E2               [24] 2187 	movx	a,@r0
      000933 FE               [12] 2188 	mov	r6,a
      000934 8A 03            [24] 2189 	mov	ar3,r2
      000936 7C 00            [12] 2190 	mov	r4,#0x00
      000938 EB               [12] 2191 	mov	a,r3
      000939 2D               [12] 2192 	add	a, r5
      00093A FD               [12] 2193 	mov	r5,a
      00093B EC               [12] 2194 	mov	a,r4
      00093C 3E               [12] 2195 	addc	a, r6
      00093D FE               [12] 2196 	mov	r6,a
      00093E 8D 82            [24] 2197 	mov	dpl,r5
      000940 8E 83            [24] 2198 	mov	dph,r6
      000942 78 3B            [12] 2199 	mov	r0,#_readFromRXBufferUDP_PARM_2
      000944 C0 01            [24] 2200 	push	ar1
      000946 79 1B            [12] 2201 	mov	r1,#_WIZnet_Read_PARM_2
      000948 E2               [24] 2202 	movx	a,@r0
      000949 F3               [24] 2203 	movx	@r1,a
      00094A D0 01            [24] 2204 	pop	ar1
      00094C C0 07            [24] 2205 	push	ar7
      00094E C0 02            [24] 2206 	push	ar2
      000950 C0 01            [24] 2207 	push	ar1
      000952 12 01 32         [24] 2208 	lcall	_WIZnet_Read
      000955 E5 82            [12] 2209 	mov	a, dpl
      000957 D0 01            [24] 2210 	pop	ar1
      000959 D0 02            [24] 2211 	pop	ar2
      00095B D0 07            [24] 2212 	pop	ar7
      00095D F3               [24] 2213 	movx	@r1,a
                                   2214 ;	optimized_main.c:322: for(int i = 0; i < getSize && i < sizeof(tempBuffer)-1; i++) {
      00095E 0A               [12] 2215 	inc	r2
      00095F 80 AD            [24] 2216 	sjmp	00110$
      000961                       2217 00101$:
                                   2218 ;	optimized_main.c:325: tempBuffer[getSize] = '\0';
      000961 78 3E            [12] 2219 	mov	r0,#_readFromRXBufferUDP_getSize_20002_151
      000963 E2               [24] 2220 	movx	a,@r0
      000964 24 44            [12] 2221 	add	a, #_readFromRXBufferUDP_tempBuffer_20002_151
      000966 F8               [12] 2222 	mov	r0,a
      000967 E4               [12] 2223 	clr	a
      000968 F2               [24] 2224 	movx	@r0,a
                                   2225 ;	optimized_main.c:328: if (validateMessage(tempBuffer)) {
      000969 90 00 44         [24] 2226 	mov	dptr,#_readFromRXBufferUDP_tempBuffer_20002_151
      00096C 75 F0 60         [24] 2227 	mov	b, #0x60
      00096F C0 07            [24] 2228 	push	ar7
      000971 12 04 AC         [24] 2229 	lcall	_validateMessage
      000974 E5 82            [12] 2230 	mov	a, dpl
      000976 D0 07            [24] 2231 	pop	ar7
      000978 60 1A            [24] 2232 	jz	00103$
                                   2233 ;	optimized_main.c:330: formatResponse(tempBuffer, returnData);
      00097A 78 30            [12] 2234 	mov	r0,#_formatResponse_PARM_2
      00097C 74 01            [12] 2235 	mov	a,#_returnData
      00097E F2               [24] 2236 	movx	@r0,a
      00097F E4               [12] 2237 	clr	a
      000980 08               [12] 2238 	inc	r0
      000981 F2               [24] 2239 	movx	@r0,a
      000982 74 60            [12] 2240 	mov	a,#0x60
      000984 08               [12] 2241 	inc	r0
      000985 F2               [24] 2242 	movx	@r0,a
      000986 90 00 44         [24] 2243 	mov	dptr,#_readFromRXBufferUDP_tempBuffer_20002_151
      000989 F5 F0            [12] 2244 	mov	b,a
      00098B C0 07            [24] 2245 	push	ar7
      00098D 12 05 CE         [24] 2246 	lcall	_formatResponse
      000990 D0 07            [24] 2247 	pop	ar7
      000992 80 04            [24] 2248 	sjmp	00104$
      000994                       2249 00103$:
                                   2250 ;	optimized_main.c:333: returnData[0] = '\0';
      000994 78 01            [12] 2251 	mov	r0,#_returnData
      000996 E4               [12] 2252 	clr	a
      000997 F2               [24] 2253 	movx	@r0,a
      000998                       2254 00104$:
                                   2255 ;	optimized_main.c:336: readPointer += getSize;
      000998 78 3C            [12] 2256 	mov	r0,#_readFromRXBufferUDP_readPointer_20002_151
      00099A 79 3E            [12] 2257 	mov	r1,#_readFromRXBufferUDP_getSize_20002_151
      00099C E3               [24] 2258 	movx	a,@r1
      00099D C5 F0            [12] 2259 	xch	a,b
      00099F E2               [24] 2260 	movx	a,@r0
      0009A0 25 F0            [12] 2261 	add	a,b
      0009A2 FD               [12] 2262 	mov	r5,a
      0009A3 09               [12] 2263 	inc	r1
      0009A4 E3               [24] 2264 	movx	a,@r1
      0009A5 C5 F0            [12] 2265 	xch	a,b
      0009A7 08               [12] 2266 	inc	r0
      0009A8 E2               [24] 2267 	movx	a,@r0
      0009A9 35 F0            [12] 2268 	addc	a,b
                                   2269 ;	optimized_main.c:338: WIZnet_Write(Sn_RX_PTR+2, sock, (readPointer >> 8) & 0xFF);
      0009AB FE               [12] 2270 	mov	r6,a
      0009AC 78 1A            [12] 2271 	mov	r0,#_WIZnet_Write_PARM_3
      0009AE F2               [24] 2272 	movx	@r0,a
      0009AF 78 19            [12] 2273 	mov	r0,#_WIZnet_Write_PARM_2
      0009B1 EF               [12] 2274 	mov	a,r7
      0009B2 F2               [24] 2275 	movx	@r0,a
      0009B3 90 00 28         [24] 2276 	mov	dptr,#0x0028
      0009B6 C0 07            [24] 2277 	push	ar7
      0009B8 C0 06            [24] 2278 	push	ar6
      0009BA C0 05            [24] 2279 	push	ar5
      0009BC 12 01 18         [24] 2280 	lcall	_WIZnet_Write
      0009BF D0 05            [24] 2281 	pop	ar5
      0009C1 D0 06            [24] 2282 	pop	ar6
      0009C3 D0 07            [24] 2283 	pop	ar7
                                   2284 ;	optimized_main.c:339: WIZnet_Write(Sn_RX_PTR+3, sock, readPointer & 0xFF);
      0009C5 78 1A            [12] 2285 	mov	r0,#_WIZnet_Write_PARM_3
      0009C7 ED               [12] 2286 	mov	a,r5
      0009C8 F2               [24] 2287 	movx	@r0,a
      0009C9 78 19            [12] 2288 	mov	r0,#_WIZnet_Write_PARM_2
      0009CB EF               [12] 2289 	mov	a,r7
      0009CC F2               [24] 2290 	movx	@r0,a
      0009CD 90 00 29         [24] 2291 	mov	dptr,#0x0029
      0009D0 C0 07            [24] 2292 	push	ar7
      0009D2 12 01 18         [24] 2293 	lcall	_WIZnet_Write
      0009D5 D0 07            [24] 2294 	pop	ar7
                                   2295 ;	optimized_main.c:340: WIZnet_Write(Sn_CR, sock, 0x40);
      0009D7 78 19            [12] 2296 	mov	r0,#_WIZnet_Write_PARM_2
      0009D9 EF               [12] 2297 	mov	a,r7
      0009DA F2               [24] 2298 	movx	@r0,a
      0009DB 78 1A            [12] 2299 	mov	r0,#_WIZnet_Write_PARM_3
      0009DD 74 40            [12] 2300 	mov	a,#0x40
      0009DF F2               [24] 2301 	movx	@r0,a
      0009E0 90 00 01         [24] 2302 	mov	dptr,#0x0001
      0009E3 12 01 18         [24] 2303 	lcall	_WIZnet_Write
                                   2304 ;	optimized_main.c:341: TXD = 1;
                                   2305 ;	assignBit
      0009E6 D2 B1            [12] 2306 	setb	_P3_1
                                   2307 ;	optimized_main.c:343: }
      0009E8 22               [24] 2308 	ret
                                   2309 ;------------------------------------------------------------
                                   2310 ;Allocation info for local variables in function 'tcpListen'
                                   2311 ;------------------------------------------------------------
                                   2312 ;	optimized_main.c:346: void tcpListen(unsigned char sock) {
                                   2313 ;	-----------------------------------------
                                   2314 ;	 function tcpListen
                                   2315 ;	-----------------------------------------
      0009E9                       2316 _tcpListen:
      0009E9 AF 82            [24] 2317 	mov	r7, dpl
                                   2318 ;	optimized_main.c:348: WIZnet_Write(Sn_CR, sock, 0x02); // Send the LISTEN command to the socket Sn_CR register
      0009EB 78 19            [12] 2319 	mov	r0,#_WIZnet_Write_PARM_2
      0009ED EF               [12] 2320 	mov	a,r7
      0009EE F2               [24] 2321 	movx	@r0,a
      0009EF 78 1A            [12] 2322 	mov	r0,#_WIZnet_Write_PARM_3
      0009F1 74 02            [12] 2323 	mov	a,#0x02
      0009F3 F2               [24] 2324 	movx	@r0,a
      0009F4 90 00 01         [24] 2325 	mov	dptr,#0x0001
                                   2326 ;	optimized_main.c:350: }
      0009F7 02 01 18         [24] 2327 	ljmp	_WIZnet_Write
                                   2328 ;------------------------------------------------------------
                                   2329 ;Allocation info for local variables in function 'tcpConnect'
                                   2330 ;------------------------------------------------------------
                                   2331 ;	optimized_main.c:352: void tcpConnect(unsigned char sock,unsigned char ip[],int destPort) {
                                   2332 ;	-----------------------------------------
                                   2333 ;	 function tcpConnect
                                   2334 ;	-----------------------------------------
      0009FA                       2335 _tcpConnect:
      0009FA AF 82            [24] 2336 	mov	r7, dpl
                                   2337 ;	optimized_main.c:354: WIZnet_SetDestinationIP(ip,sock);
      0009FC 78 2D            [12] 2338 	mov	r0,#_WIZnet_SetDestinationIP_PARM_2
      0009FE EF               [12] 2339 	mov	a,r7
      0009FF F2               [24] 2340 	movx	@r0,a
      000A00 78 5A            [12] 2341 	mov	r0,#_tcpConnect_PARM_2
      000A02 E2               [24] 2342 	movx	a,@r0
      000A03 F5 82            [12] 2343 	mov	dpl, a
      000A05 08               [12] 2344 	inc	r0
      000A06 E2               [24] 2345 	movx	a,@r0
      000A07 F5 83            [12] 2346 	mov	dph, a
      000A09 08               [12] 2347 	inc	r0
      000A0A E2               [24] 2348 	movx	a,@r0
      000A0B F5 F0            [12] 2349 	mov	b, a
      000A0D C0 07            [24] 2350 	push	ar7
      000A0F 12 03 0E         [24] 2351 	lcall	_WIZnet_SetDestinationIP
      000A12 D0 07            [24] 2352 	pop	ar7
                                   2353 ;	optimized_main.c:355: WIZnet_SetDestinationPort(sock, destPort);
      000A14 78 5D            [12] 2354 	mov	r0,#_tcpConnect_PARM_3
      000A16 79 2B            [12] 2355 	mov	r1,#_WIZnet_SetDestinationPort_PARM_2
      000A18 E2               [24] 2356 	movx	a,@r0
      000A19 F3               [24] 2357 	movx	@r1,a
      000A1A 08               [12] 2358 	inc	r0
      000A1B E2               [24] 2359 	movx	a,@r0
      000A1C 09               [12] 2360 	inc	r1
      000A1D F3               [24] 2361 	movx	@r1,a
      000A1E 8F 82            [24] 2362 	mov	dpl, r7
      000A20 C0 07            [24] 2363 	push	ar7
      000A22 12 02 E1         [24] 2364 	lcall	_WIZnet_SetDestinationPort
      000A25 D0 07            [24] 2365 	pop	ar7
                                   2366 ;	optimized_main.c:357: WIZnet_Write(Sn_CR, sock, 0x04); // Send the CONNECT command to the socket Sn_CR register
      000A27 78 19            [12] 2367 	mov	r0,#_WIZnet_Write_PARM_2
      000A29 EF               [12] 2368 	mov	a,r7
      000A2A F2               [24] 2369 	movx	@r0,a
      000A2B 78 1A            [12] 2370 	mov	r0,#_WIZnet_Write_PARM_3
      000A2D 74 04            [12] 2371 	mov	a,#0x04
      000A2F F2               [24] 2372 	movx	@r0,a
      000A30 90 00 01         [24] 2373 	mov	dptr,#0x0001
                                   2374 ;	optimized_main.c:359: }
      000A33 02 01 18         [24] 2375 	ljmp	_WIZnet_Write
                                   2376 ;------------------------------------------------------------
                                   2377 ;Allocation info for local variables in function 'readFromRXBufferTCP'
                                   2378 ;------------------------------------------------------------
                                   2379 ;	optimized_main.c:361: void readFromRXBufferTCP(unsigned char sock, unsigned char sockrx) {
                                   2380 ;	-----------------------------------------
                                   2381 ;	 function readFromRXBufferTCP
                                   2382 ;	-----------------------------------------
      000A36                       2383 _readFromRXBufferTCP:
      000A36 E5 82            [12] 2384 	mov	a,dpl
      000A38 78 60            [12] 2385 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000A3A F2               [24] 2386 	movx	@r0,a
                                   2387 ;	optimized_main.c:362: TXD = 1;
                                   2388 ;	assignBit
      000A3B D2 B1            [12] 2389 	setb	_P3_1
                                   2390 ;	optimized_main.c:363: if(WIZnet_Read(Sn_RX_PTR, sock) != 0x00 || WIZnet_Read(Sn_RX_PTR+1, sock) != 0x00) {
      000A3D 78 60            [12] 2391 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000A3F 79 1B            [12] 2392 	mov	r1,#_WIZnet_Read_PARM_2
      000A41 E2               [24] 2393 	movx	a,@r0
      000A42 F3               [24] 2394 	movx	@r1,a
      000A43 90 00 26         [24] 2395 	mov	dptr,#0x0026
      000A46 12 01 32         [24] 2396 	lcall	_WIZnet_Read
      000A49 E5 82            [12] 2397 	mov	a, dpl
      000A4B 70 11            [24] 2398 	jnz	00105$
      000A4D 78 60            [12] 2399 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000A4F 79 1B            [12] 2400 	mov	r1,#_WIZnet_Read_PARM_2
      000A51 E2               [24] 2401 	movx	a,@r0
      000A52 F3               [24] 2402 	movx	@r1,a
      000A53 90 00 27         [24] 2403 	mov	dptr,#0x0027
      000A56 12 01 32         [24] 2404 	lcall	_WIZnet_Read
      000A59 E5 82            [12] 2405 	mov	a, dpl
      000A5B 70 01            [24] 2406 	jnz	00151$
      000A5D 22               [24] 2407 	ret
      000A5E                       2408 00151$:
      000A5E                       2409 00105$:
                                   2410 ;	optimized_main.c:364: TXD = 0;  // Turn ON LED when receiving TCP packet
                                   2411 ;	assignBit
      000A5E C2 B1            [12] 2412 	clr	_P3_1
                                   2413 ;	optimized_main.c:366: returnData[0] = '\0';
      000A60 78 01            [12] 2414 	mov	r0,#_returnData
      000A62 E4               [12] 2415 	clr	a
      000A63 F2               [24] 2416 	movx	@r0,a
                                   2417 ;	optimized_main.c:369: unsigned short getSize = ((WIZnet_Read(Sn_RX_PTR, sock)<< 8) | 
      000A64 78 60            [12] 2418 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000A66 79 1B            [12] 2419 	mov	r1,#_WIZnet_Read_PARM_2
      000A68 E2               [24] 2420 	movx	a,@r0
      000A69 F3               [24] 2421 	movx	@r1,a
      000A6A 90 00 26         [24] 2422 	mov	dptr,#0x0026
      000A6D 12 01 32         [24] 2423 	lcall	_WIZnet_Read
      000A70 AD 82            [24] 2424 	mov	r5,dpl
      000A72 7E 00            [12] 2425 	mov	r6,#0x00
      000A74 78 60            [12] 2426 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000A76 79 1B            [12] 2427 	mov	r1,#_WIZnet_Read_PARM_2
      000A78 E2               [24] 2428 	movx	a,@r0
      000A79 F3               [24] 2429 	movx	@r1,a
      000A7A 90 00 27         [24] 2430 	mov	dptr,#0x0027
      000A7D C0 06            [24] 2431 	push	ar6
      000A7F C0 05            [24] 2432 	push	ar5
      000A81 12 01 32         [24] 2433 	lcall	_WIZnet_Read
      000A84 AC 82            [24] 2434 	mov	r4, dpl
      000A86 D0 05            [24] 2435 	pop	ar5
      000A88 D0 06            [24] 2436 	pop	ar6
      000A8A 7B 00            [12] 2437 	mov	r3,#0x00
      000A8C EC               [12] 2438 	mov	a,r4
      000A8D 42 06            [12] 2439 	orl	ar6,a
      000A8F EB               [12] 2440 	mov	a,r3
      000A90 42 05            [12] 2441 	orl	ar5,a
                                   2442 ;	optimized_main.c:372: unsigned short readPointer = getRxReadPointer(sock);
      000A92 78 60            [12] 2443 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000A94 E2               [24] 2444 	movx	a,@r0
      000A95 F5 82            [12] 2445 	mov	dpl, a
      000A97 C0 06            [24] 2446 	push	ar6
      000A99 C0 05            [24] 2447 	push	ar5
      000A9B 12 03 E4         [24] 2448 	lcall	_getRxReadPointer
      000A9E AB 82            [24] 2449 	mov	r3, dpl
      000AA0 AC 83            [24] 2450 	mov	r4, dph
      000AA2 D0 05            [24] 2451 	pop	ar5
      000AA4 D0 06            [24] 2452 	pop	ar6
                                   2453 ;	optimized_main.c:375: for(int i = 0; i < getSize && i < sizeof(tempBuffer)-1; i++) {
      000AA6 78 77            [12] 2454 	mov	r0,#_readFromRXBufferTCP_i_30001_164
      000AA8 E4               [12] 2455 	clr	a
      000AA9 F2               [24] 2456 	movx	@r0,a
      000AAA                       2457 00110$:
      000AAA C0 03            [24] 2458 	push	ar3
      000AAC C0 04            [24] 2459 	push	ar4
      000AAE 78 77            [12] 2460 	mov	r0,#_readFromRXBufferTCP_i_30001_164
      000AB0 E2               [24] 2461 	movx	a,@r0
      000AB1 FB               [12] 2462 	mov	r3,a
      000AB2 7C 00            [12] 2463 	mov	r4,#0x00
      000AB4 C3               [12] 2464 	clr	c
      000AB5 EB               [12] 2465 	mov	a,r3
      000AB6 9E               [12] 2466 	subb	a,r6
      000AB7 EC               [12] 2467 	mov	a,r4
      000AB8 9D               [12] 2468 	subb	a,r5
      000AB9 D0 04            [24] 2469 	pop	ar4
      000ABB D0 03            [24] 2470 	pop	ar3
      000ABD 50 56            [24] 2471 	jnc	00101$
      000ABF 78 77            [12] 2472 	mov	r0,#_readFromRXBufferTCP_i_30001_164
      000AC1 E2               [24] 2473 	movx	a,@r0
      000AC2 B4 15 00         [24] 2474 	cjne	a,#0x15,00153$
      000AC5                       2475 00153$:
      000AC5 50 4E            [24] 2476 	jnc	00101$
                                   2477 ;	optimized_main.c:376: tempBuffer[i] = WIZnet_Read(readPointer+i, sockrx);
      000AC7 C0 06            [24] 2478 	push	ar6
      000AC9 C0 05            [24] 2479 	push	ar5
      000ACB 78 77            [12] 2480 	mov	r0,#_readFromRXBufferTCP_i_30001_164
      000ACD E2               [24] 2481 	movx	a,@r0
      000ACE 24 61            [12] 2482 	add	a, #_readFromRXBufferTCP_tempBuffer_20001_163
      000AD0 F9               [12] 2483 	mov	r1,a
      000AD1 8B 05            [24] 2484 	mov	ar5,r3
      000AD3 8C 06            [24] 2485 	mov	ar6,r4
      000AD5 78 77            [12] 2486 	mov	r0,#_readFromRXBufferTCP_i_30001_164
      000AD7 E2               [24] 2487 	movx	a,@r0
      000AD8 7F 00            [12] 2488 	mov	r7,#0x00
      000ADA 2D               [12] 2489 	add	a, r5
      000ADB FD               [12] 2490 	mov	r5,a
      000ADC EF               [12] 2491 	mov	a,r7
      000ADD 3E               [12] 2492 	addc	a, r6
      000ADE FE               [12] 2493 	mov	r6,a
      000ADF 8D 82            [24] 2494 	mov	dpl,r5
      000AE1 8E 83            [24] 2495 	mov	dph,r6
      000AE3 78 5F            [12] 2496 	mov	r0,#_readFromRXBufferTCP_PARM_2
      000AE5 C0 01            [24] 2497 	push	ar1
      000AE7 79 1B            [12] 2498 	mov	r1,#_WIZnet_Read_PARM_2
      000AE9 E2               [24] 2499 	movx	a,@r0
      000AEA F3               [24] 2500 	movx	@r1,a
      000AEB D0 01            [24] 2501 	pop	ar1
      000AED C0 06            [24] 2502 	push	ar6
      000AEF C0 05            [24] 2503 	push	ar5
      000AF1 C0 04            [24] 2504 	push	ar4
      000AF3 C0 03            [24] 2505 	push	ar3
      000AF5 C0 01            [24] 2506 	push	ar1
      000AF7 12 01 32         [24] 2507 	lcall	_WIZnet_Read
      000AFA E5 82            [12] 2508 	mov	a, dpl
      000AFC D0 01            [24] 2509 	pop	ar1
      000AFE D0 03            [24] 2510 	pop	ar3
      000B00 D0 04            [24] 2511 	pop	ar4
      000B02 D0 05            [24] 2512 	pop	ar5
      000B04 D0 06            [24] 2513 	pop	ar6
      000B06 F3               [24] 2514 	movx	@r1,a
                                   2515 ;	optimized_main.c:375: for(int i = 0; i < getSize && i < sizeof(tempBuffer)-1; i++) {
      000B07 78 77            [12] 2516 	mov	r0,#_readFromRXBufferTCP_i_30001_164
      000B09 79 77            [12] 2517 	mov	r1,#_readFromRXBufferTCP_i_30001_164
      000B0B E2               [24] 2518 	movx	a,@r0
      000B0C 24 01            [12] 2519 	add	a, #0x01
      000B0E F3               [24] 2520 	movx	@r1,a
      000B0F D0 05            [24] 2521 	pop	ar5
      000B11 D0 06            [24] 2522 	pop	ar6
      000B13 80 95            [24] 2523 	sjmp	00110$
      000B15                       2524 00101$:
                                   2525 ;	optimized_main.c:378: tempBuffer[getSize] = '\0';
      000B15 EE               [12] 2526 	mov	a,r6
      000B16 24 61            [12] 2527 	add	a, #_readFromRXBufferTCP_tempBuffer_20001_163
      000B18 F8               [12] 2528 	mov	r0,a
      000B19 E4               [12] 2529 	clr	a
      000B1A F2               [24] 2530 	movx	@r0,a
                                   2531 ;	optimized_main.c:381: if (validateMessage(tempBuffer)) {
      000B1B 90 00 61         [24] 2532 	mov	dptr,#_readFromRXBufferTCP_tempBuffer_20001_163
      000B1E 75 F0 60         [24] 2533 	mov	b, #0x60
      000B21 C0 06            [24] 2534 	push	ar6
      000B23 C0 05            [24] 2535 	push	ar5
      000B25 C0 04            [24] 2536 	push	ar4
      000B27 C0 03            [24] 2537 	push	ar3
      000B29 12 04 AC         [24] 2538 	lcall	_validateMessage
      000B2C E5 82            [12] 2539 	mov	a, dpl
      000B2E D0 03            [24] 2540 	pop	ar3
      000B30 D0 04            [24] 2541 	pop	ar4
      000B32 D0 05            [24] 2542 	pop	ar5
      000B34 D0 06            [24] 2543 	pop	ar6
      000B36 60 26            [24] 2544 	jz	00103$
                                   2545 ;	optimized_main.c:383: formatResponse(tempBuffer, returnData);
      000B38 78 30            [12] 2546 	mov	r0,#_formatResponse_PARM_2
      000B3A 74 01            [12] 2547 	mov	a,#_returnData
      000B3C F2               [24] 2548 	movx	@r0,a
      000B3D E4               [12] 2549 	clr	a
      000B3E 08               [12] 2550 	inc	r0
      000B3F F2               [24] 2551 	movx	@r0,a
      000B40 74 60            [12] 2552 	mov	a,#0x60
      000B42 08               [12] 2553 	inc	r0
      000B43 F2               [24] 2554 	movx	@r0,a
      000B44 90 00 61         [24] 2555 	mov	dptr,#_readFromRXBufferTCP_tempBuffer_20001_163
      000B47 F5 F0            [12] 2556 	mov	b,a
      000B49 C0 06            [24] 2557 	push	ar6
      000B4B C0 05            [24] 2558 	push	ar5
      000B4D C0 04            [24] 2559 	push	ar4
      000B4F C0 03            [24] 2560 	push	ar3
      000B51 12 05 CE         [24] 2561 	lcall	_formatResponse
      000B54 D0 03            [24] 2562 	pop	ar3
      000B56 D0 04            [24] 2563 	pop	ar4
      000B58 D0 05            [24] 2564 	pop	ar5
      000B5A D0 06            [24] 2565 	pop	ar6
      000B5C 80 04            [24] 2566 	sjmp	00104$
      000B5E                       2567 00103$:
                                   2568 ;	optimized_main.c:386: returnData[0] = '\0';
      000B5E 78 01            [12] 2569 	mov	r0,#_returnData
      000B60 E4               [12] 2570 	clr	a
      000B61 F2               [24] 2571 	movx	@r0,a
      000B62                       2572 00104$:
                                   2573 ;	optimized_main.c:389: readPointer += getSize;
      000B62 EE               [12] 2574 	mov	a,r6
      000B63 2B               [12] 2575 	add	a, r3
      000B64 FE               [12] 2576 	mov	r6,a
      000B65 ED               [12] 2577 	mov	a,r5
      000B66 3C               [12] 2578 	addc	a, r4
                                   2579 ;	optimized_main.c:391: WIZnet_Write(Sn_RX_PTR+2, sock, (readPointer >> 8) & 0xFF);
      000B67 FD               [12] 2580 	mov	r5,a
      000B68 78 1A            [12] 2581 	mov	r0,#_WIZnet_Write_PARM_3
      000B6A F2               [24] 2582 	movx	@r0,a
      000B6B 78 60            [12] 2583 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000B6D 79 19            [12] 2584 	mov	r1,#_WIZnet_Write_PARM_2
      000B6F E2               [24] 2585 	movx	a,@r0
      000B70 F3               [24] 2586 	movx	@r1,a
      000B71 90 00 28         [24] 2587 	mov	dptr,#0x0028
      000B74 C0 06            [24] 2588 	push	ar6
      000B76 C0 05            [24] 2589 	push	ar5
      000B78 12 01 18         [24] 2590 	lcall	_WIZnet_Write
      000B7B D0 05            [24] 2591 	pop	ar5
      000B7D D0 06            [24] 2592 	pop	ar6
                                   2593 ;	optimized_main.c:392: WIZnet_Write(Sn_RX_PTR+3, sock, readPointer & 0xFF);    
      000B7F 78 1A            [12] 2594 	mov	r0,#_WIZnet_Write_PARM_3
      000B81 EE               [12] 2595 	mov	a,r6
      000B82 F2               [24] 2596 	movx	@r0,a
      000B83 78 60            [12] 2597 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000B85 79 19            [12] 2598 	mov	r1,#_WIZnet_Write_PARM_2
      000B87 E2               [24] 2599 	movx	a,@r0
      000B88 F3               [24] 2600 	movx	@r1,a
      000B89 90 00 29         [24] 2601 	mov	dptr,#0x0029
      000B8C 12 01 18         [24] 2602 	lcall	_WIZnet_Write
                                   2603 ;	optimized_main.c:394: WIZnet_Write(Sn_CR, sock, 0x40);
      000B8F 78 60            [12] 2604 	mov	r0,#_readFromRXBufferTCP_sock_10000_160
      000B91 79 19            [12] 2605 	mov	r1,#_WIZnet_Write_PARM_2
      000B93 E2               [24] 2606 	movx	a,@r0
      000B94 F3               [24] 2607 	movx	@r1,a
      000B95 78 1A            [12] 2608 	mov	r0,#_WIZnet_Write_PARM_3
      000B97 74 40            [12] 2609 	mov	a,#0x40
      000B99 F2               [24] 2610 	movx	@r0,a
      000B9A 90 00 01         [24] 2611 	mov	dptr,#0x0001
      000B9D 12 01 18         [24] 2612 	lcall	_WIZnet_Write
                                   2613 ;	optimized_main.c:395: TXD = 1;  // Turn OFF LED after processing
                                   2614 ;	assignBit
      000BA0 D2 B1            [12] 2615 	setb	_P3_1
                                   2616 ;	optimized_main.c:397: }
      000BA2 22               [24] 2617 	ret
                                   2618 ;------------------------------------------------------------
                                   2619 ;Allocation info for local variables in function 'writeToTxBufferTCP'
                                   2620 ;------------------------------------------------------------
                                   2621 ;	optimized_main.c:400: void writeToTxBufferTCP(unsigned char sock, unsigned char socktx) {
                                   2622 ;	-----------------------------------------
                                   2623 ;	 function writeToTxBufferTCP
                                   2624 ;	-----------------------------------------
      000BA3                       2625 _writeToTxBufferTCP:
      000BA3 AF 82            [24] 2626 	mov	r7, dpl
                                   2627 ;	optimized_main.c:401: RXD = 1;  // Start with LED off
                                   2628 ;	assignBit
      000BA5 D2 B0            [12] 2629 	setb	_P3_0
                                   2630 ;	optimized_main.c:402: if(returnData[0] != '\0') {
      000BA7 78 01            [12] 2631 	mov	r0,#_returnData
      000BA9 E2               [24] 2632 	movx	a,@r0
      000BAA 70 01            [24] 2633 	jnz	00144$
      000BAC 22               [24] 2634 	ret
      000BAD                       2635 00144$:
                                   2636 ;	optimized_main.c:404: RXD = 0;  // Turn ON LED when sending TCP packet
                                   2637 ;	assignBit
      000BAD C2 B0            [12] 2638 	clr	_P3_0
                                   2639 ;	optimized_main.c:406: unsigned short sendPointer = getTxWritePointer(sock);
      000BAF 8F 82            [24] 2640 	mov	dpl, r7
      000BB1 C0 07            [24] 2641 	push	ar7
      000BB3 12 04 7A         [24] 2642 	lcall	_getTxWritePointer
      000BB6 AD 82            [24] 2643 	mov	r5, dpl
      000BB8 AE 83            [24] 2644 	mov	r6, dph
      000BBA D0 07            [24] 2645 	pop	ar7
                                   2646 ;	optimized_main.c:409: for(char i = 0; returnData[i] != '\0'; i++) {
      000BBC 7C 00            [12] 2647 	mov	r4,#0x00
      000BBE                       2648 00109$:
      000BBE EC               [12] 2649 	mov	a,r4
      000BBF 24 01            [12] 2650 	add	a, #_returnData
      000BC1 F9               [12] 2651 	mov	r1,a
      000BC2 E3               [24] 2652 	movx	a,@r1
      000BC3 FB               [12] 2653 	mov	r3,a
      000BC4 60 31            [24] 2654 	jz	00101$
                                   2655 ;	optimized_main.c:410: WIZnet_Write(sendPointer, socktx, returnData[i]);
      000BC6 78 79            [12] 2656 	mov	r0,#_writeToTxBufferTCP_PARM_2
      000BC8 79 19            [12] 2657 	mov	r1,#_WIZnet_Write_PARM_2
      000BCA E2               [24] 2658 	movx	a,@r0
      000BCB F3               [24] 2659 	movx	@r1,a
      000BCC 78 1A            [12] 2660 	mov	r0,#_WIZnet_Write_PARM_3
      000BCE EB               [12] 2661 	mov	a,r3
      000BCF F2               [24] 2662 	movx	@r0,a
      000BD0 8D 82            [24] 2663 	mov	dpl, r5
      000BD2 8E 83            [24] 2664 	mov	dph, r6
      000BD4 C0 07            [24] 2665 	push	ar7
      000BD6 C0 06            [24] 2666 	push	ar6
      000BD8 C0 05            [24] 2667 	push	ar5
      000BDA C0 04            [24] 2668 	push	ar4
      000BDC 12 01 18         [24] 2669 	lcall	_WIZnet_Write
      000BDF D0 04            [24] 2670 	pop	ar4
      000BE1 D0 05            [24] 2671 	pop	ar5
      000BE3 D0 06            [24] 2672 	pop	ar6
      000BE5 D0 07            [24] 2673 	pop	ar7
                                   2674 ;	optimized_main.c:411: sendPointer += 1;
      000BE7 8D 02            [24] 2675 	mov	ar2,r5
      000BE9 8E 03            [24] 2676 	mov	ar3,r6
      000BEB 0A               [12] 2677 	inc	r2
      000BEC BA 00 01         [24] 2678 	cjne	r2,#0x00,00146$
      000BEF 0B               [12] 2679 	inc	r3
      000BF0                       2680 00146$:
      000BF0 8A 05            [24] 2681 	mov	ar5,r2
      000BF2 8B 06            [24] 2682 	mov	ar6,r3
                                   2683 ;	optimized_main.c:409: for(char i = 0; returnData[i] != '\0'; i++) {
      000BF4 0C               [12] 2684 	inc	r4
      000BF5 80 C7            [24] 2685 	sjmp	00109$
      000BF7                       2686 00101$:
                                   2687 ;	optimized_main.c:414: WIZnet_Write(Sn_TX_PTR+2, sock, (sendPointer >> 8) & 0xFF);
      000BF7 78 1A            [12] 2688 	mov	r0,#_WIZnet_Write_PARM_3
      000BF9 EE               [12] 2689 	mov	a,r6
      000BFA F2               [24] 2690 	movx	@r0,a
      000BFB 78 19            [12] 2691 	mov	r0,#_WIZnet_Write_PARM_2
      000BFD EF               [12] 2692 	mov	a,r7
      000BFE F2               [24] 2693 	movx	@r0,a
      000BFF 90 00 24         [24] 2694 	mov	dptr,#0x0024
      000C02 C0 07            [24] 2695 	push	ar7
      000C04 C0 06            [24] 2696 	push	ar6
      000C06 C0 05            [24] 2697 	push	ar5
      000C08 12 01 18         [24] 2698 	lcall	_WIZnet_Write
      000C0B D0 05            [24] 2699 	pop	ar5
      000C0D D0 06            [24] 2700 	pop	ar6
      000C0F D0 07            [24] 2701 	pop	ar7
                                   2702 ;	optimized_main.c:415: WIZnet_Write(Sn_TX_PTR+3, sock, sendPointer & 0xFF);
      000C11 78 1A            [12] 2703 	mov	r0,#_WIZnet_Write_PARM_3
      000C13 ED               [12] 2704 	mov	a,r5
      000C14 F2               [24] 2705 	movx	@r0,a
      000C15 78 19            [12] 2706 	mov	r0,#_WIZnet_Write_PARM_2
      000C17 EF               [12] 2707 	mov	a,r7
      000C18 F2               [24] 2708 	movx	@r0,a
      000C19 90 00 25         [24] 2709 	mov	dptr,#0x0025
      000C1C C0 07            [24] 2710 	push	ar7
      000C1E 12 01 18         [24] 2711 	lcall	_WIZnet_Write
      000C21 D0 07            [24] 2712 	pop	ar7
                                   2713 ;	optimized_main.c:417: Wiznet_SendPacket(sock);
      000C23 8F 82            [24] 2714 	mov	dpl, r7
      000C25 C0 07            [24] 2715 	push	ar7
      000C27 12 03 AB         [24] 2716 	lcall	_Wiznet_SendPacket
      000C2A D0 07            [24] 2717 	pop	ar7
                                   2718 ;	optimized_main.c:418: RXD = 1;  // Turn OFF LED after sending
                                   2719 ;	assignBit
      000C2C D2 B0            [12] 2720 	setb	_P3_0
                                   2721 ;	optimized_main.c:421: interrupt = WIZnet_Read(Sn_IR, sock);
      000C2E 78 1B            [12] 2722 	mov	r0,#_WIZnet_Read_PARM_2
      000C30 EF               [12] 2723 	mov	a,r7
      000C31 F2               [24] 2724 	movx	@r0,a
      000C32 90 00 02         [24] 2725 	mov	dptr,#0x0002
      000C35 C0 07            [24] 2726 	push	ar7
      000C37 12 01 32         [24] 2727 	lcall	_WIZnet_Read
      000C3A AE 82            [24] 2728 	mov	r6, dpl
      000C3C D0 07            [24] 2729 	pop	ar7
                                   2730 ;	optimized_main.c:422: if(interrupt & 0x10) {
      000C3E EE               [12] 2731 	mov	a,r6
      000C3F 30 E4 17         [24] 2732 	jnb	acc.4,00103$
                                   2733 ;	optimized_main.c:423: WIZnet_Write(Sn_IMR, sock, 0x10);
      000C42 78 19            [12] 2734 	mov	r0,#_WIZnet_Write_PARM_2
      000C44 EF               [12] 2735 	mov	a,r7
      000C45 F2               [24] 2736 	movx	@r0,a
      000C46 78 1A            [12] 2737 	mov	r0,#_WIZnet_Write_PARM_3
      000C48 74 10            [12] 2738 	mov	a,#0x10
      000C4A F2               [24] 2739 	movx	@r0,a
      000C4B 90 00 2C         [24] 2740 	mov	dptr,#0x002c
      000C4E C0 07            [24] 2741 	push	ar7
      000C50 C0 06            [24] 2742 	push	ar6
      000C52 12 01 18         [24] 2743 	lcall	_WIZnet_Write
      000C55 D0 06            [24] 2744 	pop	ar6
      000C57 D0 07            [24] 2745 	pop	ar7
      000C59                       2746 00103$:
                                   2747 ;	optimized_main.c:425: if(interrupt & 0x08) {
      000C59 EE               [12] 2748 	mov	a,r6
      000C5A 30 E3 13         [24] 2749 	jnb	acc.3,00105$
                                   2750 ;	optimized_main.c:426: WIZnet_Write(Sn_IMR, sock, 0x08);
      000C5D 78 19            [12] 2751 	mov	r0,#_WIZnet_Write_PARM_2
      000C5F EF               [12] 2752 	mov	a,r7
      000C60 F2               [24] 2753 	movx	@r0,a
      000C61 78 1A            [12] 2754 	mov	r0,#_WIZnet_Write_PARM_3
      000C63 74 08            [12] 2755 	mov	a,#0x08
      000C65 F2               [24] 2756 	movx	@r0,a
      000C66 90 00 2C         [24] 2757 	mov	dptr,#0x002c
      000C69 C0 07            [24] 2758 	push	ar7
      000C6B 12 01 18         [24] 2759 	lcall	_WIZnet_Write
      000C6E D0 07            [24] 2760 	pop	ar7
      000C70                       2761 00105$:
                                   2762 ;	optimized_main.c:430: unsigned short tx_read_pointer = WIZnet_Read(Sn_TX_PTR, sock) << 8 | 
      000C70 78 1B            [12] 2763 	mov	r0,#_WIZnet_Read_PARM_2
      000C72 EF               [12] 2764 	mov	a,r7
      000C73 F2               [24] 2765 	movx	@r0,a
      000C74 90 00 22         [24] 2766 	mov	dptr,#0x0022
      000C77 C0 07            [24] 2767 	push	ar7
      000C79 12 01 32         [24] 2768 	lcall	_WIZnet_Read
      000C7C AE 82            [24] 2769 	mov	r6, dpl
      000C7E D0 07            [24] 2770 	pop	ar7
      000C80 8E 05            [24] 2771 	mov	ar5,r6
      000C82 7E 00            [12] 2772 	mov	r6,#0x00
      000C84 78 1B            [12] 2773 	mov	r0,#_WIZnet_Read_PARM_2
      000C86 EF               [12] 2774 	mov	a,r7
      000C87 F2               [24] 2775 	movx	@r0,a
      000C88 90 00 23         [24] 2776 	mov	dptr,#0x0023
      000C8B C0 07            [24] 2777 	push	ar7
      000C8D C0 06            [24] 2778 	push	ar6
      000C8F C0 05            [24] 2779 	push	ar5
      000C91 12 01 32         [24] 2780 	lcall	_WIZnet_Read
      000C94 AC 82            [24] 2781 	mov	r4, dpl
      000C96 D0 05            [24] 2782 	pop	ar5
      000C98 D0 06            [24] 2783 	pop	ar6
      000C9A D0 07            [24] 2784 	pop	ar7
      000C9C 7B 00            [12] 2785 	mov	r3,#0x00
      000C9E EC               [12] 2786 	mov	a,r4
      000C9F 42 06            [12] 2787 	orl	ar6,a
      000CA1 EB               [12] 2788 	mov	a,r3
      000CA2 42 05            [12] 2789 	orl	ar5,a
                                   2790 ;	optimized_main.c:432: WIZnet_Write(Sn_TX_PTR+2, sock, (tx_read_pointer >> 8) & 0xFF);
      000CA4 78 1A            [12] 2791 	mov	r0,#_WIZnet_Write_PARM_3
      000CA6 ED               [12] 2792 	mov	a,r5
      000CA7 F2               [24] 2793 	movx	@r0,a
      000CA8 78 19            [12] 2794 	mov	r0,#_WIZnet_Write_PARM_2
      000CAA EF               [12] 2795 	mov	a,r7
      000CAB F2               [24] 2796 	movx	@r0,a
      000CAC 90 00 24         [24] 2797 	mov	dptr,#0x0024
      000CAF C0 07            [24] 2798 	push	ar7
      000CB1 C0 06            [24] 2799 	push	ar6
      000CB3 C0 05            [24] 2800 	push	ar5
      000CB5 12 01 18         [24] 2801 	lcall	_WIZnet_Write
      000CB8 D0 05            [24] 2802 	pop	ar5
      000CBA D0 06            [24] 2803 	pop	ar6
      000CBC D0 07            [24] 2804 	pop	ar7
                                   2805 ;	optimized_main.c:433: WIZnet_Write(Sn_TX_PTR+3, sock, tx_read_pointer & 0xFF);
      000CBE 78 1A            [12] 2806 	mov	r0,#_WIZnet_Write_PARM_3
      000CC0 EE               [12] 2807 	mov	a,r6
      000CC1 F2               [24] 2808 	movx	@r0,a
      000CC2 78 19            [12] 2809 	mov	r0,#_WIZnet_Write_PARM_2
      000CC4 EF               [12] 2810 	mov	a,r7
      000CC5 F2               [24] 2811 	movx	@r0,a
      000CC6 90 00 25         [24] 2812 	mov	dptr,#0x0025
                                   2813 ;	optimized_main.c:435: }
      000CC9 02 01 18         [24] 2814 	ljmp	_WIZnet_Write
                                   2815 ;------------------------------------------------------------
                                   2816 ;Allocation info for local variables in function 'main'
                                   2817 ;------------------------------------------------------------
                                   2818 ;ip            Allocated with name '_main_ip_10000_178'
                                   2819 ;mac           Allocated with name '_main_mac_10000_178'
                                   2820 ;subnet        Allocated with name '_main_subnet_10000_178'
                                   2821 ;gateway       Allocated with name '_main_gateway_10000_178'
                                   2822 ;------------------------------------------------------------
                                   2823 ;	optimized_main.c:438: void main(void) {
                                   2824 ;	-----------------------------------------
                                   2825 ;	 function main
                                   2826 ;	-----------------------------------------
      000CCC                       2827 _main:
                                   2828 ;	optimized_main.c:441: __xdata unsigned char ip[4] = {192, 168, 32, 27};   //test ip
      000CCC 90 00 91         [24] 2829 	mov	dptr,#_main_ip_10000_178
      000CCF 74 C0            [12] 2830 	mov	a,#0xc0
      000CD1 F0               [24] 2831 	movx	@dptr,a
      000CD2 90 00 92         [24] 2832 	mov	dptr,#(_main_ip_10000_178 + 0x0001)
      000CD5 74 A8            [12] 2833 	mov	a,#0xa8
      000CD7 F0               [24] 2834 	movx	@dptr,a
      000CD8 90 00 93         [24] 2835 	mov	dptr,#(_main_ip_10000_178 + 0x0002)
      000CDB 74 20            [12] 2836 	mov	a,#0x20
      000CDD F0               [24] 2837 	movx	@dptr,a
      000CDE 90 00 94         [24] 2838 	mov	dptr,#(_main_ip_10000_178 + 0x0003)
      000CE1 74 1B            [12] 2839 	mov	a,#0x1b
      000CE3 F0               [24] 2840 	movx	@dptr,a
                                   2841 ;	optimized_main.c:442: __xdata unsigned char mac[6] = {0x00, 0x08, 0xDC, 0x01, 0x02, 0x03}; //test mac address
      000CE4 90 00 95         [24] 2842 	mov	dptr,#_main_mac_10000_178
      000CE7 E4               [12] 2843 	clr	a
      000CE8 F0               [24] 2844 	movx	@dptr,a
      000CE9 90 00 96         [24] 2845 	mov	dptr,#(_main_mac_10000_178 + 0x0001)
      000CEC 74 08            [12] 2846 	mov	a,#0x08
      000CEE F0               [24] 2847 	movx	@dptr,a
      000CEF 90 00 97         [24] 2848 	mov	dptr,#(_main_mac_10000_178 + 0x0002)
      000CF2 74 DC            [12] 2849 	mov	a,#0xdc
      000CF4 F0               [24] 2850 	movx	@dptr,a
      000CF5 90 00 98         [24] 2851 	mov	dptr,#(_main_mac_10000_178 + 0x0003)
      000CF8 74 01            [12] 2852 	mov	a,#0x01
      000CFA F0               [24] 2853 	movx	@dptr,a
      000CFB 90 00 99         [24] 2854 	mov	dptr,#(_main_mac_10000_178 + 0x0004)
      000CFE 04               [12] 2855 	inc	a
      000CFF F0               [24] 2856 	movx	@dptr,a
      000D00 90 00 9A         [24] 2857 	mov	dptr,#(_main_mac_10000_178 + 0x0005)
      000D03 04               [12] 2858 	inc	a
      000D04 F0               [24] 2859 	movx	@dptr,a
                                   2860 ;	optimized_main.c:443: __xdata unsigned char subnet[4] = {255, 255, 255, 0};               // Example Subnet Mask
      000D05 90 00 9B         [24] 2861 	mov	dptr,#_main_subnet_10000_178
      000D08 74 FF            [12] 2862 	mov	a,#0xff
      000D0A F0               [24] 2863 	movx	@dptr,a
      000D0B 90 00 9C         [24] 2864 	mov	dptr,#(_main_subnet_10000_178 + 0x0001)
      000D0E F0               [24] 2865 	movx	@dptr,a
      000D0F 90 00 9D         [24] 2866 	mov	dptr,#(_main_subnet_10000_178 + 0x0002)
      000D12 F0               [24] 2867 	movx	@dptr,a
      000D13 90 00 9E         [24] 2868 	mov	dptr,#(_main_subnet_10000_178 + 0x0003)
      000D16 E4               [12] 2869 	clr	a
      000D17 F0               [24] 2870 	movx	@dptr,a
                                   2871 ;	optimized_main.c:444: __xdata unsigned char gateway[4] = {192, 168, 32, 1};                // Example Gateway
      000D18 90 00 9F         [24] 2872 	mov	dptr,#_main_gateway_10000_178
      000D1B 74 C0            [12] 2873 	mov	a,#0xc0
      000D1D F0               [24] 2874 	movx	@dptr,a
      000D1E 90 00 A0         [24] 2875 	mov	dptr,#(_main_gateway_10000_178 + 0x0001)
      000D21 74 A8            [12] 2876 	mov	a,#0xa8
      000D23 F0               [24] 2877 	movx	@dptr,a
      000D24 90 00 A1         [24] 2878 	mov	dptr,#(_main_gateway_10000_178 + 0x0002)
      000D27 74 20            [12] 2879 	mov	a,#0x20
      000D29 F0               [24] 2880 	movx	@dptr,a
      000D2A 90 00 A2         [24] 2881 	mov	dptr,#(_main_gateway_10000_178 + 0x0003)
      000D2D 74 01            [12] 2882 	mov	a,#0x01
      000D2F F0               [24] 2883 	movx	@dptr,a
                                   2884 ;	optimized_main.c:455: unsigned char mode = 0; //0 is udp 1 is tcp
      000D30 7F 00            [12] 2885 	mov	r7,#0x00
                                   2886 ;	optimized_main.c:464: rtu = 1;
      000D32 78 17            [12] 2887 	mov	r0,#_rtu
      000D34 F2               [24] 2888 	movx	@r0,a
                                   2889 ;	optimized_main.c:465: RXD = 1; // Initialize RXD and TXD LEDs
                                   2890 ;	assignBit
      000D35 D2 B0            [12] 2891 	setb	_P3_0
                                   2892 ;	optimized_main.c:466: TXD = 1; // Initialize RXD and TXD LEDs
                                   2893 ;	assignBit
      000D37 D2 B1            [12] 2894 	setb	_P3_1
                                   2895 ;	optimized_main.c:471: SPI_Init();
      000D39 C0 07            [24] 2896 	push	ar7
      000D3B 12 1A 0D         [24] 2897 	lcall	_SPI_Init
                                   2898 ;	optimized_main.c:472: WIZnet_Init();
      000D3E 12 01 45         [24] 2899 	lcall	_WIZnet_Init
                                   2900 ;	optimized_main.c:473: UART_Init();
      000D41 12 18 86         [24] 2901 	lcall	_UART_Init
                                   2902 ;	optimized_main.c:479: WIZnet_SetMAC(mac);
      000D44 90 00 95         [24] 2903 	mov	dptr,#_main_mac_10000_178
      000D47 75 F0 00         [24] 2904 	mov	b, #0x00
      000D4A 12 01 A5         [24] 2905 	lcall	_WIZnet_SetMAC
                                   2906 ;	optimized_main.c:480: WIZnet_SetIP(ip);
      000D4D 90 00 91         [24] 2907 	mov	dptr,#_main_ip_10000_178
      000D50 75 F0 00         [24] 2908 	mov	b, #0x00
      000D53 12 01 5B         [24] 2909 	lcall	_WIZnet_SetIP
                                   2910 ;	optimized_main.c:481: WIZnet_SetSubnetMask(subnet);
      000D56 90 00 9B         [24] 2911 	mov	dptr,#_main_subnet_10000_178
      000D59 75 F0 00         [24] 2912 	mov	b, #0x00
      000D5C 12 01 EF         [24] 2913 	lcall	_WIZnet_SetSubnetMask
                                   2914 ;	optimized_main.c:482: WIZnet_SetGateway(gateway);  
      000D5F 90 00 9F         [24] 2915 	mov	dptr,#_main_gateway_10000_178
      000D62 75 F0 00         [24] 2916 	mov	b, #0x00
      000D65 12 02 39         [24] 2917 	lcall	_WIZnet_SetGateway
                                   2918 ;	optimized_main.c:488: WIZnet_SetSocketMode(Sn_PUDP,S0_R);
      000D68 78 28            [12] 2919 	mov	r0,#_WIZnet_SetSocketMode_PARM_2
      000D6A 74 08            [12] 2920 	mov	a,#0x08
      000D6C F2               [24] 2921 	movx	@r0,a
      000D6D 75 82 02         [24] 2922 	mov	dpl, #0x02
      000D70 12 02 80         [24] 2923 	lcall	_WIZnet_SetSocketMode
                                   2924 ;	optimized_main.c:489: WIZnet_SetSocketPort(S0_R,5000);
      000D73 78 29            [12] 2925 	mov	r0,#_WIZnet_SetSocketPort_PARM_2
      000D75 74 88            [12] 2926 	mov	a,#0x88
      000D77 F2               [24] 2927 	movx	@r0,a
      000D78 74 13            [12] 2928 	mov	a,#0x13
      000D7A 08               [12] 2929 	inc	r0
      000D7B F2               [24] 2930 	movx	@r0,a
      000D7C 75 82 08         [24] 2931 	mov	dpl, #0x08
      000D7F 12 02 92         [24] 2932 	lcall	_WIZnet_SetSocketPort
                                   2933 ;	optimized_main.c:490: WIZnet_OpenSocket(S0_R);
      000D82 75 82 08         [24] 2934 	mov	dpl, #0x08
      000D85 12 02 BF         [24] 2935 	lcall	_WIZnet_OpenSocket
                                   2936 ;	optimized_main.c:496: WIZnet_SetSocketMode(Sn_PTCP,S1_R);
      000D88 78 28            [12] 2937 	mov	r0,#_WIZnet_SetSocketMode_PARM_2
      000D8A 74 28            [12] 2938 	mov	a,#0x28
      000D8C F2               [24] 2939 	movx	@r0,a
      000D8D 75 82 01         [24] 2940 	mov	dpl, #0x01
      000D90 12 02 80         [24] 2941 	lcall	_WIZnet_SetSocketMode
                                   2942 ;	optimized_main.c:497: WIZnet_SetSocketPort(S1_R,5001);
      000D93 78 29            [12] 2943 	mov	r0,#_WIZnet_SetSocketPort_PARM_2
      000D95 74 89            [12] 2944 	mov	a,#0x89
      000D97 F2               [24] 2945 	movx	@r0,a
      000D98 23               [12] 2946 	rl	a
      000D99 08               [12] 2947 	inc	r0
      000D9A F2               [24] 2948 	movx	@r0,a
      000D9B 75 82 28         [24] 2949 	mov	dpl, #0x28
      000D9E 12 02 92         [24] 2950 	lcall	_WIZnet_SetSocketPort
                                   2951 ;	optimized_main.c:498: WIZnet_OpenSocket(S1_R);
      000DA1 75 82 28         [24] 2952 	mov	dpl, #0x28
      000DA4 12 02 BF         [24] 2953 	lcall	_WIZnet_OpenSocket
                                   2954 ;	optimized_main.c:501: WIZnet_CloseSocket(S0_R);
      000DA7 75 82 08         [24] 2955 	mov	dpl, #0x08
      000DAA 12 02 D0         [24] 2956 	lcall	_WIZnet_CloseSocket
                                   2957 ;	optimized_main.c:502: WIZnet_OpenSocket(S0_R); 
      000DAD 75 82 08         [24] 2958 	mov	dpl, #0x08
      000DB0 12 02 BF         [24] 2959 	lcall	_WIZnet_OpenSocket
                                   2960 ;	optimized_main.c:503: WIZnet_CloseSocket(S1_R);
      000DB3 75 82 28         [24] 2961 	mov	dpl, #0x28
      000DB6 12 02 D0         [24] 2962 	lcall	_WIZnet_CloseSocket
                                   2963 ;	optimized_main.c:504: WIZnet_OpenSocket(S1_R); 
      000DB9 75 82 28         [24] 2964 	mov	dpl, #0x28
      000DBC 12 02 BF         [24] 2965 	lcall	_WIZnet_OpenSocket
                                   2966 ;	optimized_main.c:506: tcpListen(S1_R); //listen for incoming connections
      000DBF 75 82 28         [24] 2967 	mov	dpl, #0x28
      000DC2 12 09 E9         [24] 2968 	lcall	_tcpListen
                                   2969 ;	optimized_main.c:510: WIZnet_Write(Sn_MR,CR,0b00010000);
      000DC5 78 19            [12] 2970 	mov	r0,#_WIZnet_Write_PARM_2
      000DC7 E4               [12] 2971 	clr	a
      000DC8 F2               [24] 2972 	movx	@r0,a
      000DC9 78 1A            [12] 2973 	mov	r0,#_WIZnet_Write_PARM_3
      000DCB 74 10            [12] 2974 	mov	a,#0x10
      000DCD F2               [24] 2975 	movx	@r0,a
      000DCE 90 00 00         [24] 2976 	mov	dptr,#0x0000
      000DD1 12 01 18         [24] 2977 	lcall	_WIZnet_Write
                                   2978 ;	optimized_main.c:512: WIZnet_Write(Sn_IMR, S0_R, 0b00000100);   
      000DD4 78 19            [12] 2979 	mov	r0,#_WIZnet_Write_PARM_2
      000DD6 74 08            [12] 2980 	mov	a,#0x08
      000DD8 F2               [24] 2981 	movx	@r0,a
      000DD9 78 1A            [12] 2982 	mov	r0,#_WIZnet_Write_PARM_3
      000DDB 03               [12] 2983 	rr	a
      000DDC F2               [24] 2984 	movx	@r0,a
      000DDD 90 00 2C         [24] 2985 	mov	dptr,#0x002c
      000DE0 12 01 18         [24] 2986 	lcall	_WIZnet_Write
      000DE3 D0 07            [24] 2987 	pop	ar7
                                   2988 ;	optimized_main.c:516: char bufferIndex = 0;
      000DE5 7E 00            [12] 2989 	mov	r6,#0x00
                                   2990 ;	optimized_main.c:517: char serialInputMode = 0;
      000DE7 7D 00            [12] 2991 	mov	r5,#0x00
                                   2992 ;	optimized_main.c:521: while(1)
      000DE9                       2993 00283$:
                                   2994 ;	optimized_main.c:523: if(WIZnet_Read(Sn_IR, S0_R) == 0b00000100) {
      000DE9 78 1B            [12] 2995 	mov	r0,#_WIZnet_Read_PARM_2
      000DEB 74 08            [12] 2996 	mov	a,#0x08
      000DED F2               [24] 2997 	movx	@r0,a
      000DEE 90 00 02         [24] 2998 	mov	dptr,#0x0002
      000DF1 C0 07            [24] 2999 	push	ar7
      000DF3 C0 06            [24] 3000 	push	ar6
      000DF5 C0 05            [24] 3001 	push	ar5
      000DF7 12 01 32         [24] 3002 	lcall	_WIZnet_Read
      000DFA AC 82            [24] 3003 	mov	r4, dpl
      000DFC D0 05            [24] 3004 	pop	ar5
      000DFE D0 06            [24] 3005 	pop	ar6
      000E00 D0 07            [24] 3006 	pop	ar7
      000E02 BC 04 4E         [24] 3007 	cjne	r4,#0x04,00104$
                                   3008 ;	optimized_main.c:524: readFromRXBufferUDP(S0_R, S0_RX);
      000E05 78 3B            [12] 3009 	mov	r0,#_readFromRXBufferUDP_PARM_2
      000E07 74 18            [12] 3010 	mov	a,#0x18
      000E09 F2               [24] 3011 	movx	@r0,a
      000E0A 75 82 08         [24] 3012 	mov	dpl, #0x08
      000E0D C0 07            [24] 3013 	push	ar7
      000E0F C0 06            [24] 3014 	push	ar6
      000E11 C0 05            [24] 3015 	push	ar5
      000E13 12 07 BB         [24] 3016 	lcall	_readFromRXBufferUDP
      000E16 D0 05            [24] 3017 	pop	ar5
      000E18 D0 06            [24] 3018 	pop	ar6
      000E1A D0 07            [24] 3019 	pop	ar7
                                   3020 ;	optimized_main.c:525: if (returnData[0] != '\0') {  // Only send if we have a valid response
      000E1C 78 01            [12] 3021 	mov	r0,#_returnData
      000E1E E2               [24] 3022 	movx	a,@r0
      000E1F 60 17            [24] 3023 	jz	00102$
                                   3024 ;	optimized_main.c:526: writeToTXBufferUDP(S0_R, S0_TX);
      000E21 78 3A            [12] 3025 	mov	r0,#_writeToTXBufferUDP_PARM_2
      000E23 74 10            [12] 3026 	mov	a,#0x10
      000E25 F2               [24] 3027 	movx	@r0,a
      000E26 75 82 08         [24] 3028 	mov	dpl, #0x08
      000E29 C0 07            [24] 3029 	push	ar7
      000E2B C0 06            [24] 3030 	push	ar6
      000E2D C0 05            [24] 3031 	push	ar5
      000E2F 12 06 EB         [24] 3032 	lcall	_writeToTXBufferUDP
      000E32 D0 05            [24] 3033 	pop	ar5
      000E34 D0 06            [24] 3034 	pop	ar6
      000E36 D0 07            [24] 3035 	pop	ar7
      000E38                       3036 00102$:
                                   3037 ;	optimized_main.c:528: WIZnet_Write(Sn_IR, S0_R, 0b00000100);
      000E38 78 19            [12] 3038 	mov	r0,#_WIZnet_Write_PARM_2
      000E3A 74 08            [12] 3039 	mov	a,#0x08
      000E3C F2               [24] 3040 	movx	@r0,a
      000E3D 78 1A            [12] 3041 	mov	r0,#_WIZnet_Write_PARM_3
      000E3F 03               [12] 3042 	rr	a
      000E40 F2               [24] 3043 	movx	@r0,a
      000E41 90 00 02         [24] 3044 	mov	dptr,#0x0002
      000E44 C0 07            [24] 3045 	push	ar7
      000E46 C0 06            [24] 3046 	push	ar6
      000E48 C0 05            [24] 3047 	push	ar5
      000E4A 12 01 18         [24] 3048 	lcall	_WIZnet_Write
      000E4D D0 05            [24] 3049 	pop	ar5
      000E4F D0 06            [24] 3050 	pop	ar6
      000E51 D0 07            [24] 3051 	pop	ar7
      000E53                       3052 00104$:
                                   3053 ;	optimized_main.c:533: if(bufferIndex == 0)
      000E53 EE               [12] 3054 	mov	a,r6
      000E54 60 03            [24] 3055 	jz	01352$
      000E56 02 0F 65         [24] 3056 	ljmp	00117$
      000E59                       3057 01352$:
                                   3058 ;	optimized_main.c:535: if(WIZnet_Read(Sn_IR, S0_R) == 0b00000100)
      000E59 78 1B            [12] 3059 	mov	r0,#_WIZnet_Read_PARM_2
      000E5B 74 08            [12] 3060 	mov	a,#0x08
      000E5D F2               [24] 3061 	movx	@r0,a
      000E5E 90 00 02         [24] 3062 	mov	dptr,#0x0002
      000E61 C0 07            [24] 3063 	push	ar7
      000E63 C0 06            [24] 3064 	push	ar6
      000E65 C0 05            [24] 3065 	push	ar5
      000E67 12 01 32         [24] 3066 	lcall	_WIZnet_Read
      000E6A AC 82            [24] 3067 	mov	r4, dpl
      000E6C D0 05            [24] 3068 	pop	ar5
      000E6E D0 06            [24] 3069 	pop	ar6
      000E70 D0 07            [24] 3070 	pop	ar7
      000E72 BC 04 31         [24] 3071 	cjne	r4,#0x04,00106$
                                   3072 ;	optimized_main.c:537: readFromRXBufferUDP(S0_R,S0_RX);
      000E75 78 3B            [12] 3073 	mov	r0,#_readFromRXBufferUDP_PARM_2
      000E77 74 18            [12] 3074 	mov	a,#0x18
      000E79 F2               [24] 3075 	movx	@r0,a
      000E7A 75 82 08         [24] 3076 	mov	dpl, #0x08
      000E7D C0 07            [24] 3077 	push	ar7
      000E7F C0 06            [24] 3078 	push	ar6
      000E81 C0 05            [24] 3079 	push	ar5
      000E83 12 07 BB         [24] 3080 	lcall	_readFromRXBufferUDP
                                   3081 ;	optimized_main.c:538: writeToTXBufferUDP(S0_R,S0_TX); //send the data back
      000E86 78 3A            [12] 3082 	mov	r0,#_writeToTXBufferUDP_PARM_2
      000E88 74 10            [12] 3083 	mov	a,#0x10
      000E8A F2               [24] 3084 	movx	@r0,a
      000E8B 75 82 08         [24] 3085 	mov	dpl, #0x08
      000E8E 12 06 EB         [24] 3086 	lcall	_writeToTXBufferUDP
                                   3087 ;	optimized_main.c:540: WIZnet_Write(Sn_IR, S0_R, 0b00000100);   // clear Sn_IR
      000E91 78 19            [12] 3088 	mov	r0,#_WIZnet_Write_PARM_2
      000E93 74 08            [12] 3089 	mov	a,#0x08
      000E95 F2               [24] 3090 	movx	@r0,a
      000E96 78 1A            [12] 3091 	mov	r0,#_WIZnet_Write_PARM_3
      000E98 03               [12] 3092 	rr	a
      000E99 F2               [24] 3093 	movx	@r0,a
      000E9A 90 00 02         [24] 3094 	mov	dptr,#0x0002
      000E9D 12 01 18         [24] 3095 	lcall	_WIZnet_Write
      000EA0 D0 05            [24] 3096 	pop	ar5
      000EA2 D0 06            [24] 3097 	pop	ar6
      000EA4 D0 07            [24] 3098 	pop	ar7
      000EA6                       3099 00106$:
                                   3100 ;	optimized_main.c:542: if(WIZnet_Read(Sn_SR, S1_R) == 0x17) {
      000EA6 78 1B            [12] 3101 	mov	r0,#_WIZnet_Read_PARM_2
      000EA8 74 28            [12] 3102 	mov	a,#0x28
      000EAA F2               [24] 3103 	movx	@r0,a
      000EAB 90 00 03         [24] 3104 	mov	dptr,#0x0003
      000EAE C0 07            [24] 3105 	push	ar7
      000EB0 C0 06            [24] 3106 	push	ar6
      000EB2 C0 05            [24] 3107 	push	ar5
      000EB4 12 01 32         [24] 3108 	lcall	_WIZnet_Read
      000EB7 AC 82            [24] 3109 	mov	r4, dpl
      000EB9 D0 05            [24] 3110 	pop	ar5
      000EBB D0 06            [24] 3111 	pop	ar6
      000EBD D0 07            [24] 3112 	pop	ar7
      000EBF BC 17 69         [24] 3113 	cjne	r4,#0x17,00113$
                                   3114 ;	optimized_main.c:543: if(WIZnet_Read(Sn_RX_PTR, S1_R) != 0x00 || WIZnet_Read(Sn_RX_PTR+1, S1_R) != 0x00) {
      000EC2 78 1B            [12] 3115 	mov	r0,#_WIZnet_Read_PARM_2
      000EC4 74 28            [12] 3116 	mov	a,#0x28
      000EC6 F2               [24] 3117 	movx	@r0,a
      000EC7 90 00 26         [24] 3118 	mov	dptr,#0x0026
      000ECA C0 07            [24] 3119 	push	ar7
      000ECC C0 06            [24] 3120 	push	ar6
      000ECE C0 05            [24] 3121 	push	ar5
      000ED0 12 01 32         [24] 3122 	lcall	_WIZnet_Read
      000ED3 E5 82            [12] 3123 	mov	a, dpl
      000ED5 D0 05            [24] 3124 	pop	ar5
      000ED7 D0 06            [24] 3125 	pop	ar6
      000ED9 D0 07            [24] 3126 	pop	ar7
      000EDB 70 1B            [24] 3127 	jnz	00109$
      000EDD 78 1B            [12] 3128 	mov	r0,#_WIZnet_Read_PARM_2
      000EDF 74 28            [12] 3129 	mov	a,#0x28
      000EE1 F2               [24] 3130 	movx	@r0,a
      000EE2 90 00 27         [24] 3131 	mov	dptr,#0x0027
      000EE5 C0 07            [24] 3132 	push	ar7
      000EE7 C0 06            [24] 3133 	push	ar6
      000EE9 C0 05            [24] 3134 	push	ar5
      000EEB 12 01 32         [24] 3135 	lcall	_WIZnet_Read
      000EEE E5 82            [12] 3136 	mov	a, dpl
      000EF0 D0 05            [24] 3137 	pop	ar5
      000EF2 D0 06            [24] 3138 	pop	ar6
      000EF4 D0 07            [24] 3139 	pop	ar7
      000EF6 60 33            [24] 3140 	jz	00113$
      000EF8                       3141 00109$:
                                   3142 ;	optimized_main.c:544: readFromRXBufferTCP(S1_R, S1_RX);
      000EF8 78 5F            [12] 3143 	mov	r0,#_readFromRXBufferTCP_PARM_2
      000EFA 74 38            [12] 3144 	mov	a,#0x38
      000EFC F2               [24] 3145 	movx	@r0,a
      000EFD 75 82 28         [24] 3146 	mov	dpl, #0x28
      000F00 C0 07            [24] 3147 	push	ar7
      000F02 C0 06            [24] 3148 	push	ar6
      000F04 C0 05            [24] 3149 	push	ar5
      000F06 12 0A 36         [24] 3150 	lcall	_readFromRXBufferTCP
      000F09 D0 05            [24] 3151 	pop	ar5
      000F0B D0 06            [24] 3152 	pop	ar6
      000F0D D0 07            [24] 3153 	pop	ar7
                                   3154 ;	optimized_main.c:545: if (returnData[0] != '\0') {  // Only send if we have a valid response
      000F0F 78 01            [12] 3155 	mov	r0,#_returnData
      000F11 E2               [24] 3156 	movx	a,@r0
      000F12 60 17            [24] 3157 	jz	00113$
                                   3158 ;	optimized_main.c:546: writeToTxBufferTCP(S1_R, S1_TX);
      000F14 78 79            [12] 3159 	mov	r0,#_writeToTxBufferTCP_PARM_2
      000F16 74 30            [12] 3160 	mov	a,#0x30
      000F18 F2               [24] 3161 	movx	@r0,a
      000F19 75 82 28         [24] 3162 	mov	dpl, #0x28
      000F1C C0 07            [24] 3163 	push	ar7
      000F1E C0 06            [24] 3164 	push	ar6
      000F20 C0 05            [24] 3165 	push	ar5
      000F22 12 0B A3         [24] 3166 	lcall	_writeToTxBufferTCP
      000F25 D0 05            [24] 3167 	pop	ar5
      000F27 D0 06            [24] 3168 	pop	ar6
      000F29 D0 07            [24] 3169 	pop	ar7
      000F2B                       3170 00113$:
                                   3171 ;	optimized_main.c:550: if(WIZnet_Read(Sn_SR, S1_R) == 0x1C)
      000F2B 78 1B            [12] 3172 	mov	r0,#_WIZnet_Read_PARM_2
      000F2D 74 28            [12] 3173 	mov	a,#0x28
      000F2F F2               [24] 3174 	movx	@r0,a
      000F30 90 00 03         [24] 3175 	mov	dptr,#0x0003
      000F33 C0 07            [24] 3176 	push	ar7
      000F35 C0 06            [24] 3177 	push	ar6
      000F37 C0 05            [24] 3178 	push	ar5
      000F39 12 01 32         [24] 3179 	lcall	_WIZnet_Read
      000F3C AC 82            [24] 3180 	mov	r4, dpl
      000F3E D0 05            [24] 3181 	pop	ar5
      000F40 D0 06            [24] 3182 	pop	ar6
      000F42 D0 07            [24] 3183 	pop	ar7
      000F44 BC 1C 1E         [24] 3184 	cjne	r4,#0x1c,00117$
                                   3185 ;	optimized_main.c:552: WIZnet_CloseSocket(S1_R); //when connection is closed reset the socket for a new connection
      000F47 75 82 28         [24] 3186 	mov	dpl, #0x28
      000F4A C0 07            [24] 3187 	push	ar7
      000F4C C0 06            [24] 3188 	push	ar6
      000F4E C0 05            [24] 3189 	push	ar5
      000F50 12 02 D0         [24] 3190 	lcall	_WIZnet_CloseSocket
                                   3191 ;	optimized_main.c:553: WIZnet_OpenSocket(S1_R);
      000F53 75 82 28         [24] 3192 	mov	dpl, #0x28
      000F56 12 02 BF         [24] 3193 	lcall	_WIZnet_OpenSocket
                                   3194 ;	optimized_main.c:554: tcpListen(S1_R);
      000F59 75 82 28         [24] 3195 	mov	dpl, #0x28
      000F5C 12 09 E9         [24] 3196 	lcall	_tcpListen
      000F5F D0 05            [24] 3197 	pop	ar5
      000F61 D0 06            [24] 3198 	pop	ar6
      000F63 D0 07            [24] 3199 	pop	ar7
      000F65                       3200 00117$:
                                   3201 ;	optimized_main.c:561: if(bufferIndex > 21) // Check if the buffer is full
      000F65 EE               [12] 3202 	mov	a,r6
      000F66 24 EA            [12] 3203 	add	a,#0xff - 0x15
      000F68 50 02            [24] 3204 	jnc	00119$
                                   3205 ;	optimized_main.c:563: bufferIndex = 0; // Reset the buffer index
      000F6A 7E 00            [12] 3206 	mov	r6,#0x00
      000F6C                       3207 00119$:
                                   3208 ;	optimized_main.c:567: recievedInput = UART_RxChar();
      000F6C C0 07            [24] 3209 	push	ar7
      000F6E C0 06            [24] 3210 	push	ar6
      000F70 C0 05            [24] 3211 	push	ar5
      000F72 12 18 9B         [24] 3212 	lcall	_UART_RxChar
      000F75 AC 82            [24] 3213 	mov	r4, dpl
      000F77 D0 05            [24] 3214 	pop	ar5
      000F79 D0 06            [24] 3215 	pop	ar6
      000F7B D0 07            [24] 3216 	pop	ar7
                                   3217 ;	optimized_main.c:569: if(recievedInput!='\0')
      000F7D EC               [12] 3218 	mov	a,r4
      000F7E FB               [12] 3219 	mov	r3,a
      000F7F 60 07            [24] 3220 	jz	00121$
                                   3221 ;	optimized_main.c:571: buffer[bufferIndex] = recievedInput;  
      000F81 EE               [12] 3222 	mov	a,r6
      000F82 24 7A            [12] 3223 	add	a, #_main_buffer_10001_179
      000F84 F8               [12] 3224 	mov	r0,a
      000F85 EB               [12] 3225 	mov	a,r3
      000F86 F2               [24] 3226 	movx	@r0,a
                                   3227 ;	optimized_main.c:572: bufferIndex++;
      000F87 0E               [12] 3228 	inc	r6
      000F88                       3229 00121$:
                                   3230 ;	optimized_main.c:575: if(buffer[bufferIndex-1] == '?')
      000F88 8E 04            [24] 3231 	mov	ar4,r6
      000F8A EC               [12] 3232 	mov	a,r4
      000F8B 14               [12] 3233 	dec	a
      000F8C 24 7A            [12] 3234 	add	a, #_main_buffer_10001_179
      000F8E F9               [12] 3235 	mov	r1,a
      000F8F E3               [24] 3236 	movx	a,@r1
      000F90 FB               [12] 3237 	mov	r3,a
      000F91 BB 3F 02         [24] 3238 	cjne	r3,#0x3f,01364$
      000F94 80 03            [24] 3239 	sjmp	01365$
      000F96                       3240 01364$:
      000F96 02 11 3F         [24] 3241 	ljmp	00126$
      000F99                       3242 01365$:
                                   3243 ;	optimized_main.c:577: UART_PrintString(STR_CURRENT_CONFIG);
      000F99 90 1B 32         [24] 3244 	mov	dptr,#_main_STR_CURRENT_CONFIG_10000_178
      000F9C 75 F0 80         [24] 3245 	mov	b, #0x80
      000F9F C0 07            [24] 3246 	push	ar7
      000FA1 C0 05            [24] 3247 	push	ar5
      000FA3 12 18 A7         [24] 3248 	lcall	_UART_PrintString
                                   3249 ;	optimized_main.c:578: UART_TxChar('\r'); 
      000FA6 75 82 0D         [24] 3250 	mov	dpl, #0x0d
      000FA9 12 18 92         [24] 3251 	lcall	_UART_TxChar
                                   3252 ;	optimized_main.c:579: UART_TxChar('\n'); 
      000FAC 75 82 0A         [24] 3253 	mov	dpl, #0x0a
      000FAF 12 18 92         [24] 3254 	lcall	_UART_TxChar
                                   3255 ;	optimized_main.c:581: UART_PrintString(STR_RTU);
      000FB2 90 1B 43         [24] 3256 	mov	dptr,#_main_STR_RTU_10000_178
      000FB5 75 F0 80         [24] 3257 	mov	b, #0x80
      000FB8 12 18 A7         [24] 3258 	lcall	_UART_PrintString
                                   3259 ;	optimized_main.c:582: UART_PrintNumber(rtu);
      000FBB 78 17            [12] 3260 	mov	r0,#_rtu
      000FBD E2               [24] 3261 	movx	a,@r0
      000FBE F5 82            [12] 3262 	mov	dpl, a
      000FC0 12 18 F1         [24] 3263 	lcall	_UART_PrintNumber
                                   3264 ;	optimized_main.c:583: UART_TxChar('\r'); 
      000FC3 75 82 0D         [24] 3265 	mov	dpl, #0x0d
      000FC6 12 18 92         [24] 3266 	lcall	_UART_TxChar
                                   3267 ;	optimized_main.c:584: UART_TxChar('\n'); 
      000FC9 75 82 0A         [24] 3268 	mov	dpl, #0x0a
      000FCC 12 18 92         [24] 3269 	lcall	_UART_TxChar
                                   3270 ;	optimized_main.c:586: UART_PrintString(STR_IP);
      000FCF 90 1B 54         [24] 3271 	mov	dptr,#_main_STR_IP_10000_178
      000FD2 75 F0 80         [24] 3272 	mov	b, #0x80
      000FD5 12 18 A7         [24] 3273 	lcall	_UART_PrintString
                                   3274 ;	optimized_main.c:587: UART_PrintIP(ip); // Print the IP address
      000FD8 90 00 91         [24] 3275 	mov	dptr,#_main_ip_10000_178
      000FDB 75 F0 00         [24] 3276 	mov	b, #0x00
      000FDE 12 19 6D         [24] 3277 	lcall	_UART_PrintIP
                                   3278 ;	optimized_main.c:588: UART_TxChar('\r'); 
      000FE1 75 82 0D         [24] 3279 	mov	dpl, #0x0d
      000FE4 12 18 92         [24] 3280 	lcall	_UART_TxChar
                                   3281 ;	optimized_main.c:589: UART_TxChar('\n'); 
      000FE7 75 82 0A         [24] 3282 	mov	dpl, #0x0a
      000FEA 12 18 92         [24] 3283 	lcall	_UART_TxChar
                                   3284 ;	optimized_main.c:591: UART_PrintString(STR_SUBNET);
      000FED 90 1B 5E         [24] 3285 	mov	dptr,#_main_STR_SUBNET_10000_178
      000FF0 75 F0 80         [24] 3286 	mov	b, #0x80
      000FF3 12 18 A7         [24] 3287 	lcall	_UART_PrintString
                                   3288 ;	optimized_main.c:592: UART_PrintIP(subnet);
      000FF6 90 00 9B         [24] 3289 	mov	dptr,#_main_subnet_10000_178
      000FF9 75 F0 00         [24] 3290 	mov	b, #0x00
      000FFC 12 19 6D         [24] 3291 	lcall	_UART_PrintIP
                                   3292 ;	optimized_main.c:593: UART_TxChar('\r'); 
      000FFF 75 82 0D         [24] 3293 	mov	dpl, #0x0d
      001002 12 18 92         [24] 3294 	lcall	_UART_TxChar
                                   3295 ;	optimized_main.c:594: UART_TxChar('\n'); 
      001005 75 82 0A         [24] 3296 	mov	dpl, #0x0a
      001008 12 18 92         [24] 3297 	lcall	_UART_TxChar
                                   3298 ;	optimized_main.c:596: UART_PrintString(STR_GATE);
      00100B 90 1B 6C         [24] 3299 	mov	dptr,#_main_STR_GATE_10000_178
      00100E 75 F0 80         [24] 3300 	mov	b, #0x80
      001011 12 18 A7         [24] 3301 	lcall	_UART_PrintString
                                   3302 ;	optimized_main.c:597: UART_PrintIP(gateway);
      001014 90 00 9F         [24] 3303 	mov	dptr,#_main_gateway_10000_178
      001017 75 F0 00         [24] 3304 	mov	b, #0x00
      00101A 12 19 6D         [24] 3305 	lcall	_UART_PrintIP
                                   3306 ;	optimized_main.c:598: UART_TxChar('\r'); 
      00101D 75 82 0D         [24] 3307 	mov	dpl, #0x0d
      001020 12 18 92         [24] 3308 	lcall	_UART_TxChar
                                   3309 ;	optimized_main.c:599: UART_TxChar('\n'); 
      001023 75 82 0A         [24] 3310 	mov	dpl, #0x0a
      001026 12 18 92         [24] 3311 	lcall	_UART_TxChar
                                   3312 ;	optimized_main.c:601: UART_PrintString(STR_MAC);
      001029 90 1B 76         [24] 3313 	mov	dptr,#_main_STR_MAC_10000_178
      00102C 75 F0 80         [24] 3314 	mov	b, #0x80
      00102F 12 18 A7         [24] 3315 	lcall	_UART_PrintString
                                   3316 ;	optimized_main.c:602: UART_PrintMAC(mac);
      001032 90 00 95         [24] 3317 	mov	dptr,#_main_mac_10000_178
      001035 75 F0 00         [24] 3318 	mov	b, #0x00
      001038 12 19 BD         [24] 3319 	lcall	_UART_PrintMAC
                                   3320 ;	optimized_main.c:603: UART_TxChar('\r'); 
      00103B 75 82 0D         [24] 3321 	mov	dpl, #0x0d
      00103E 12 18 92         [24] 3322 	lcall	_UART_TxChar
                                   3323 ;	optimized_main.c:604: UART_TxChar('\n'); 
      001041 75 82 0A         [24] 3324 	mov	dpl, #0x0a
      001044 12 18 92         [24] 3325 	lcall	_UART_TxChar
                                   3326 ;	optimized_main.c:606: UART_PrintString(STR_MODE);
      001047 90 1B 81         [24] 3327 	mov	dptr,#_main_STR_MODE_10000_178
      00104A 75 F0 80         [24] 3328 	mov	b, #0x80
      00104D 12 18 A7         [24] 3329 	lcall	_UART_PrintString
      001050 D0 05            [24] 3330 	pop	ar5
      001052 D0 07            [24] 3331 	pop	ar7
                                   3332 ;	optimized_main.c:607: if(mode == 0)
      001054 EF               [12] 3333 	mov	a,r7
      001055 70 13            [24] 3334 	jnz	00123$
                                   3335 ;	optimized_main.c:609: UART_PrintString(STR_UDP);
      001057 90 1B 88         [24] 3336 	mov	dptr,#_main_STR_UDP_10000_178
      00105A 75 F0 80         [24] 3337 	mov	b, #0x80
      00105D C0 07            [24] 3338 	push	ar7
      00105F C0 05            [24] 3339 	push	ar5
      001061 12 18 A7         [24] 3340 	lcall	_UART_PrintString
      001064 D0 05            [24] 3341 	pop	ar5
      001066 D0 07            [24] 3342 	pop	ar7
      001068 80 11            [24] 3343 	sjmp	00124$
      00106A                       3344 00123$:
                                   3345 ;	optimized_main.c:613: UART_PrintString(STR_TCP);
      00106A 90 1B 8C         [24] 3346 	mov	dptr,#_main_STR_TCP_10000_178
      00106D 75 F0 80         [24] 3347 	mov	b, #0x80
      001070 C0 07            [24] 3348 	push	ar7
      001072 C0 05            [24] 3349 	push	ar5
      001074 12 18 A7         [24] 3350 	lcall	_UART_PrintString
      001077 D0 05            [24] 3351 	pop	ar5
      001079 D0 07            [24] 3352 	pop	ar7
      00107B                       3353 00124$:
                                   3354 ;	optimized_main.c:615: UART_TxChar('\r'); 
      00107B 75 82 0D         [24] 3355 	mov	dpl, #0x0d
      00107E C0 07            [24] 3356 	push	ar7
      001080 C0 05            [24] 3357 	push	ar5
      001082 12 18 92         [24] 3358 	lcall	_UART_TxChar
                                   3359 ;	optimized_main.c:616: UART_TxChar('\n'); 
      001085 75 82 0A         [24] 3360 	mov	dpl, #0x0a
      001088 12 18 92         [24] 3361 	lcall	_UART_TxChar
                                   3362 ;	optimized_main.c:617: UART_TxChar('\r'); 
      00108B 75 82 0D         [24] 3363 	mov	dpl, #0x0d
      00108E 12 18 92         [24] 3364 	lcall	_UART_TxChar
                                   3365 ;	optimized_main.c:618: UART_TxChar('\n'); 
      001091 75 82 0A         [24] 3366 	mov	dpl, #0x0a
      001094 12 18 92         [24] 3367 	lcall	_UART_TxChar
                                   3368 ;	optimized_main.c:620: UART_PrintString(STR_CMD);
      001097 90 1B 90         [24] 3369 	mov	dptr,#_main_STR_CMD_10000_178
      00109A 75 F0 80         [24] 3370 	mov	b, #0x80
      00109D 12 18 A7         [24] 3371 	lcall	_UART_PrintString
                                   3372 ;	optimized_main.c:621: UART_TxChar('\r'); 
      0010A0 75 82 0D         [24] 3373 	mov	dpl, #0x0d
      0010A3 12 18 92         [24] 3374 	lcall	_UART_TxChar
                                   3375 ;	optimized_main.c:622: UART_TxChar('\n'); 
      0010A6 75 82 0A         [24] 3376 	mov	dpl, #0x0a
      0010A9 12 18 92         [24] 3377 	lcall	_UART_TxChar
                                   3378 ;	optimized_main.c:624: UART_PrintString(STR_RTU_FORMAT);
      0010AC 90 1B 9C         [24] 3379 	mov	dptr,#_main_STR_RTU_FORMAT_10000_178
      0010AF 75 F0 80         [24] 3380 	mov	b, #0x80
      0010B2 12 18 A7         [24] 3381 	lcall	_UART_PrintString
                                   3382 ;	optimized_main.c:625: UART_TxChar('\r'); 
      0010B5 75 82 0D         [24] 3383 	mov	dpl, #0x0d
      0010B8 12 18 92         [24] 3384 	lcall	_UART_TxChar
                                   3385 ;	optimized_main.c:626: UART_TxChar('\n'); 
      0010BB 75 82 0A         [24] 3386 	mov	dpl, #0x0a
      0010BE 12 18 92         [24] 3387 	lcall	_UART_TxChar
                                   3388 ;	optimized_main.c:628: UART_PrintString(STR_IP_FORMAT);
      0010C1 90 1B A2         [24] 3389 	mov	dptr,#_main_STR_IP_FORMAT_10000_178
      0010C4 75 F0 80         [24] 3390 	mov	b, #0x80
      0010C7 12 18 A7         [24] 3391 	lcall	_UART_PrintString
                                   3392 ;	optimized_main.c:629: UART_TxChar('\r'); 
      0010CA 75 82 0D         [24] 3393 	mov	dpl, #0x0d
      0010CD 12 18 92         [24] 3394 	lcall	_UART_TxChar
                                   3395 ;	optimized_main.c:630: UART_TxChar('\n'); 
      0010D0 75 82 0A         [24] 3396 	mov	dpl, #0x0a
      0010D3 12 18 92         [24] 3397 	lcall	_UART_TxChar
                                   3398 ;	optimized_main.c:632: UART_PrintString(STR_SUB_FORMAT);
      0010D6 90 1B B5         [24] 3399 	mov	dptr,#_main_STR_SUB_FORMAT_10000_178
      0010D9 75 F0 80         [24] 3400 	mov	b, #0x80
      0010DC 12 18 A7         [24] 3401 	lcall	_UART_PrintString
                                   3402 ;	optimized_main.c:633: UART_TxChar('\r'); 
      0010DF 75 82 0D         [24] 3403 	mov	dpl, #0x0d
      0010E2 12 18 92         [24] 3404 	lcall	_UART_TxChar
                                   3405 ;	optimized_main.c:634: UART_TxChar('\n'); 
      0010E5 75 82 0A         [24] 3406 	mov	dpl, #0x0a
      0010E8 12 18 92         [24] 3407 	lcall	_UART_TxChar
                                   3408 ;	optimized_main.c:636: UART_PrintString(STR_GATE_FORMAT);
      0010EB 90 1B C9         [24] 3409 	mov	dptr,#_main_STR_GATE_FORMAT_10000_178
      0010EE 75 F0 80         [24] 3410 	mov	b, #0x80
      0010F1 12 18 A7         [24] 3411 	lcall	_UART_PrintString
                                   3412 ;	optimized_main.c:637: UART_TxChar('\r'); 
      0010F4 75 82 0D         [24] 3413 	mov	dpl, #0x0d
      0010F7 12 18 92         [24] 3414 	lcall	_UART_TxChar
                                   3415 ;	optimized_main.c:638: UART_TxChar('\n'); 
      0010FA 75 82 0A         [24] 3416 	mov	dpl, #0x0a
      0010FD 12 18 92         [24] 3417 	lcall	_UART_TxChar
                                   3418 ;	optimized_main.c:640: UART_PrintString(STR_MAC_FORMAT);
      001100 90 1B DE         [24] 3419 	mov	dptr,#_main_STR_MAC_FORMAT_10000_178
      001103 75 F0 80         [24] 3420 	mov	b, #0x80
      001106 12 18 A7         [24] 3421 	lcall	_UART_PrintString
                                   3422 ;	optimized_main.c:641: UART_TxChar('\r'); 
      001109 75 82 0D         [24] 3423 	mov	dpl, #0x0d
      00110C 12 18 92         [24] 3424 	lcall	_UART_TxChar
                                   3425 ;	optimized_main.c:642: UART_TxChar('\n'); 
      00110F 75 82 0A         [24] 3426 	mov	dpl, #0x0a
      001112 12 18 92         [24] 3427 	lcall	_UART_TxChar
                                   3428 ;	optimized_main.c:644: UART_PrintString(STR_MODE_FORMAT);
      001115 90 1B F4         [24] 3429 	mov	dptr,#_main_STR_MODE_FORMAT_10000_178
      001118 75 F0 80         [24] 3430 	mov	b, #0x80
      00111B 12 18 A7         [24] 3431 	lcall	_UART_PrintString
                                   3432 ;	optimized_main.c:645: UART_TxChar('\r'); 
      00111E 75 82 0D         [24] 3433 	mov	dpl, #0x0d
      001121 12 18 92         [24] 3434 	lcall	_UART_TxChar
                                   3435 ;	optimized_main.c:646: UART_TxChar('\n'); 
      001124 75 82 0A         [24] 3436 	mov	dpl, #0x0a
      001127 12 18 92         [24] 3437 	lcall	_UART_TxChar
                                   3438 ;	optimized_main.c:648: UART_TxChar('\r'); 
      00112A 75 82 0D         [24] 3439 	mov	dpl, #0x0d
      00112D 12 18 92         [24] 3440 	lcall	_UART_TxChar
                                   3441 ;	optimized_main.c:649: UART_TxChar('\n'); 
      001130 75 82 0A         [24] 3442 	mov	dpl, #0x0a
      001133 12 18 92         [24] 3443 	lcall	_UART_TxChar
      001136 D0 05            [24] 3444 	pop	ar5
      001138 D0 07            [24] 3445 	pop	ar7
                                   3446 ;	optimized_main.c:651: bufferIndex = 0; // Reset the buffer index
      00113A 7E 00            [12] 3447 	mov	r6,#0x00
                                   3448 ;	optimized_main.c:652: continue;
      00113C 02 0D E9         [24] 3449 	ljmp	00283$
      00113F                       3450 00126$:
                                   3451 ;	optimized_main.c:655: if(buffer[bufferIndex-1] == '}') //Print buffer
      00113F EC               [12] 3452 	mov	a,r4
      001140 14               [12] 3453 	dec	a
      001141 24 7A            [12] 3454 	add	a, #_main_buffer_10001_179
      001143 F9               [12] 3455 	mov	r1,a
      001144 E3               [24] 3456 	movx	a,@r1
      001145 FC               [12] 3457 	mov	r4,a
      001146 BC 7D 22         [24] 3458 	cjne	r4,#0x7d,00128$
                                   3459 ;	optimized_main.c:657: UART_PrintCharArr(buffer); 
      001149 90 00 7A         [24] 3460 	mov	dptr,#_main_buffer_10001_179
      00114C 75 F0 60         [24] 3461 	mov	b, #0x60
      00114F C0 07            [24] 3462 	push	ar7
      001151 C0 05            [24] 3463 	push	ar5
      001153 12 18 A7         [24] 3464 	lcall	_UART_PrintString
                                   3465 ;	optimized_main.c:658: UART_TxChar('\r'); 
      001156 75 82 0D         [24] 3466 	mov	dpl, #0x0d
      001159 12 18 92         [24] 3467 	lcall	_UART_TxChar
                                   3468 ;	optimized_main.c:659: UART_TxChar('\n'); 
      00115C 75 82 0A         [24] 3469 	mov	dpl, #0x0a
      00115F 12 18 92         [24] 3470 	lcall	_UART_TxChar
      001162 D0 05            [24] 3471 	pop	ar5
      001164 D0 07            [24] 3472 	pop	ar7
                                   3473 ;	optimized_main.c:661: bufferIndex = 0; // Reset the buffer index
      001166 7E 00            [12] 3474 	mov	r6,#0x00
                                   3475 ;	optimized_main.c:662: continue;
      001168 02 0D E9         [24] 3476 	ljmp	00283$
      00116B                       3477 00128$:
                                   3478 ;	optimized_main.c:667: if(serialInputMode == 1) //IP address input mode
      00116B BD 01 02         [24] 3479 	cjne	r5,#0x01,01369$
      00116E 80 03            [24] 3480 	sjmp	01370$
      001170                       3481 01369$:
      001170 02 12 FD         [24] 3482 	ljmp	00243$
      001173                       3483 01370$:
                                   3484 ;	optimized_main.c:670: if(isdigit(buffer[3]) && isdigit(buffer[4]) && isdigit(buffer[5]) && bufferIndex >= 5)
      001173 78 7D            [12] 3485 	mov	r0,#(_main_buffer_10001_179 + 0x0003)
      001175 E2               [24] 3486 	movx	a,@r0
      001176 FC               [12] 3487 	mov	r4,a
                                   3488 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001177 BC 30 00         [24] 3489 	cjne	r4,#0x30,01371$
      00117A                       3490 01371$:
      00117A 92 01            [24] 3491 	mov	_main_sloc0_1_0,c
      00117C 40 4F            [24] 3492 	jc	00130$
      00117E EC               [12] 3493 	mov	a,r4
      00117F 24 C6            [12] 3494 	add	a,#0xff - 0x39
      001181 92 01            [24] 3495 	mov	_main_sloc0_1_0,c
      001183 40 48            [24] 3496 	jc	00130$
                                   3497 ;	optimized_main.c:670: if(isdigit(buffer[3]) && isdigit(buffer[4]) && isdigit(buffer[5]) && bufferIndex >= 5)
      001185 78 7E            [12] 3498 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      001187 E2               [24] 3499 	movx	a,@r0
      001188 FC               [12] 3500 	mov	r4,a
                                   3501 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001189 BC 30 00         [24] 3502 	cjne	r4,#0x30,01374$
      00118C                       3503 01374$:
      00118C 92 01            [24] 3504 	mov	_main_sloc0_1_0,c
      00118E 40 3D            [24] 3505 	jc	00130$
      001190 EC               [12] 3506 	mov	a,r4
      001191 24 C6            [12] 3507 	add	a,#0xff - 0x39
      001193 92 01            [24] 3508 	mov	_main_sloc0_1_0,c
      001195 40 36            [24] 3509 	jc	00130$
                                   3510 ;	optimized_main.c:670: if(isdigit(buffer[3]) && isdigit(buffer[4]) && isdigit(buffer[5]) && bufferIndex >= 5)
      001197 78 7F            [12] 3511 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      001199 E2               [24] 3512 	movx	a,@r0
      00119A FC               [12] 3513 	mov	r4,a
                                   3514 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00119B BC 30 00         [24] 3515 	cjne	r4,#0x30,01377$
      00119E                       3516 01377$:
      00119E 92 01            [24] 3517 	mov	_main_sloc0_1_0,c
      0011A0 40 2B            [24] 3518 	jc	00130$
      0011A2 EC               [12] 3519 	mov	a,r4
      0011A3 24 C6            [12] 3520 	add	a,#0xff - 0x39
      0011A5 92 01            [24] 3521 	mov	_main_sloc0_1_0,c
      0011A7 40 24            [24] 3522 	jc	00130$
                                   3523 ;	optimized_main.c:670: if(isdigit(buffer[3]) && isdigit(buffer[4]) && isdigit(buffer[5]) && bufferIndex >= 5)
      0011A9 BE 05 00         [24] 3524 	cjne	r6,#0x05,01380$
      0011AC                       3525 01380$:
      0011AC 40 1F            [24] 3526 	jc	00130$
                                   3527 ;	optimized_main.c:673: ip[0] =  ((buffer[3] - '0') * 100) + ((buffer[4] - '0') * 10) + ((buffer[5] - '0'));
      0011AE 78 7D            [12] 3528 	mov	r0,#(_main_buffer_10001_179 + 0x0003)
      0011B0 E2               [24] 3529 	movx	a,@r0
      0011B1 24 D0            [12] 3530 	add	a,#0xd0
      0011B3 75 F0 64         [24] 3531 	mov	b,#0x64
      0011B6 A4               [48] 3532 	mul	ab
      0011B7 FC               [12] 3533 	mov	r4,a
      0011B8 78 7E            [12] 3534 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      0011BA E2               [24] 3535 	movx	a,@r0
      0011BB 24 D0            [12] 3536 	add	a,#0xd0
      0011BD 75 F0 0A         [24] 3537 	mov	b,#0x0a
      0011C0 A4               [48] 3538 	mul	ab
      0011C1 2C               [12] 3539 	add	a, r4
      0011C2 FC               [12] 3540 	mov	r4,a
      0011C3 78 7F            [12] 3541 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      0011C5 E2               [24] 3542 	movx	a,@r0
      0011C6 24 D0            [12] 3543 	add	a,#0xd0
      0011C8 2C               [12] 3544 	add	a, r4
      0011C9 90 00 91         [24] 3545 	mov	dptr,#_main_ip_10000_178
      0011CC F0               [24] 3546 	movx	@dptr,a
      0011CD                       3547 00130$:
                                   3548 ;	optimized_main.c:676: if(isdigit(buffer[7]) && isdigit(buffer[8]) && isdigit(buffer[9]) && bufferIndex >= 9)
      0011CD 78 81            [12] 3549 	mov	r0,#(_main_buffer_10001_179 + 0x0007)
      0011CF E2               [24] 3550 	movx	a,@r0
      0011D0 FC               [12] 3551 	mov	r4,a
                                   3552 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0011D1 BC 30 00         [24] 3553 	cjne	r4,#0x30,01382$
      0011D4                       3554 01382$:
      0011D4 92 01            [24] 3555 	mov	_main_sloc0_1_0,c
      0011D6 40 4F            [24] 3556 	jc	00135$
      0011D8 EC               [12] 3557 	mov	a,r4
      0011D9 24 C6            [12] 3558 	add	a,#0xff - 0x39
      0011DB 92 01            [24] 3559 	mov	_main_sloc0_1_0,c
      0011DD 40 48            [24] 3560 	jc	00135$
                                   3561 ;	optimized_main.c:676: if(isdigit(buffer[7]) && isdigit(buffer[8]) && isdigit(buffer[9]) && bufferIndex >= 9)
      0011DF 78 82            [12] 3562 	mov	r0,#(_main_buffer_10001_179 + 0x0008)
      0011E1 E2               [24] 3563 	movx	a,@r0
      0011E2 FC               [12] 3564 	mov	r4,a
                                   3565 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0011E3 BC 30 00         [24] 3566 	cjne	r4,#0x30,01385$
      0011E6                       3567 01385$:
      0011E6 92 01            [24] 3568 	mov	_main_sloc0_1_0,c
      0011E8 40 3D            [24] 3569 	jc	00135$
      0011EA EC               [12] 3570 	mov	a,r4
      0011EB 24 C6            [12] 3571 	add	a,#0xff - 0x39
      0011ED 92 01            [24] 3572 	mov	_main_sloc0_1_0,c
      0011EF 40 36            [24] 3573 	jc	00135$
                                   3574 ;	optimized_main.c:676: if(isdigit(buffer[7]) && isdigit(buffer[8]) && isdigit(buffer[9]) && bufferIndex >= 9)
      0011F1 78 83            [12] 3575 	mov	r0,#(_main_buffer_10001_179 + 0x0009)
      0011F3 E2               [24] 3576 	movx	a,@r0
      0011F4 FC               [12] 3577 	mov	r4,a
                                   3578 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0011F5 BC 30 00         [24] 3579 	cjne	r4,#0x30,01388$
      0011F8                       3580 01388$:
      0011F8 92 01            [24] 3581 	mov	_main_sloc0_1_0,c
      0011FA 40 2B            [24] 3582 	jc	00135$
      0011FC EC               [12] 3583 	mov	a,r4
      0011FD 24 C6            [12] 3584 	add	a,#0xff - 0x39
      0011FF 92 01            [24] 3585 	mov	_main_sloc0_1_0,c
      001201 40 24            [24] 3586 	jc	00135$
                                   3587 ;	optimized_main.c:676: if(isdigit(buffer[7]) && isdigit(buffer[8]) && isdigit(buffer[9]) && bufferIndex >= 9)
      001203 BE 09 00         [24] 3588 	cjne	r6,#0x09,01391$
      001206                       3589 01391$:
      001206 40 1F            [24] 3590 	jc	00135$
                                   3591 ;	optimized_main.c:679: ip[1] =  ((buffer[7] - '0') * 100) + ((buffer[8] - '0') * 10) + ((buffer[9] - '0'));
      001208 78 81            [12] 3592 	mov	r0,#(_main_buffer_10001_179 + 0x0007)
      00120A E2               [24] 3593 	movx	a,@r0
      00120B 24 D0            [12] 3594 	add	a,#0xd0
      00120D 75 F0 64         [24] 3595 	mov	b,#0x64
      001210 A4               [48] 3596 	mul	ab
      001211 FC               [12] 3597 	mov	r4,a
      001212 78 82            [12] 3598 	mov	r0,#(_main_buffer_10001_179 + 0x0008)
      001214 E2               [24] 3599 	movx	a,@r0
      001215 24 D0            [12] 3600 	add	a,#0xd0
      001217 75 F0 0A         [24] 3601 	mov	b,#0x0a
      00121A A4               [48] 3602 	mul	ab
      00121B 2C               [12] 3603 	add	a, r4
      00121C FC               [12] 3604 	mov	r4,a
      00121D 78 83            [12] 3605 	mov	r0,#(_main_buffer_10001_179 + 0x0009)
      00121F E2               [24] 3606 	movx	a,@r0
      001220 24 D0            [12] 3607 	add	a,#0xd0
      001222 2C               [12] 3608 	add	a, r4
      001223 90 00 92         [24] 3609 	mov	dptr,#(_main_ip_10000_178 + 0x0001)
      001226 F0               [24] 3610 	movx	@dptr,a
      001227                       3611 00135$:
                                   3612 ;	optimized_main.c:682: if(isdigit(buffer[11]) && isdigit(buffer[12]) && isdigit(buffer[13]) && bufferIndex >= 13)
      001227 78 85            [12] 3613 	mov	r0,#(_main_buffer_10001_179 + 0x000b)
      001229 E2               [24] 3614 	movx	a,@r0
      00122A FC               [12] 3615 	mov	r4,a
                                   3616 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00122B BC 30 00         [24] 3617 	cjne	r4,#0x30,01393$
      00122E                       3618 01393$:
      00122E 92 01            [24] 3619 	mov	_main_sloc0_1_0,c
      001230 40 4F            [24] 3620 	jc	00140$
      001232 EC               [12] 3621 	mov	a,r4
      001233 24 C6            [12] 3622 	add	a,#0xff - 0x39
      001235 92 01            [24] 3623 	mov	_main_sloc0_1_0,c
      001237 40 48            [24] 3624 	jc	00140$
                                   3625 ;	optimized_main.c:682: if(isdigit(buffer[11]) && isdigit(buffer[12]) && isdigit(buffer[13]) && bufferIndex >= 13)
      001239 78 86            [12] 3626 	mov	r0,#(_main_buffer_10001_179 + 0x000c)
      00123B E2               [24] 3627 	movx	a,@r0
      00123C FC               [12] 3628 	mov	r4,a
                                   3629 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00123D BC 30 00         [24] 3630 	cjne	r4,#0x30,01396$
      001240                       3631 01396$:
      001240 92 01            [24] 3632 	mov	_main_sloc0_1_0,c
      001242 40 3D            [24] 3633 	jc	00140$
      001244 EC               [12] 3634 	mov	a,r4
      001245 24 C6            [12] 3635 	add	a,#0xff - 0x39
      001247 92 01            [24] 3636 	mov	_main_sloc0_1_0,c
      001249 40 36            [24] 3637 	jc	00140$
                                   3638 ;	optimized_main.c:682: if(isdigit(buffer[11]) && isdigit(buffer[12]) && isdigit(buffer[13]) && bufferIndex >= 13)
      00124B 78 87            [12] 3639 	mov	r0,#(_main_buffer_10001_179 + 0x000d)
      00124D E2               [24] 3640 	movx	a,@r0
      00124E FC               [12] 3641 	mov	r4,a
                                   3642 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00124F BC 30 00         [24] 3643 	cjne	r4,#0x30,01399$
      001252                       3644 01399$:
      001252 92 01            [24] 3645 	mov	_main_sloc0_1_0,c
      001254 40 2B            [24] 3646 	jc	00140$
      001256 EC               [12] 3647 	mov	a,r4
      001257 24 C6            [12] 3648 	add	a,#0xff - 0x39
      001259 92 01            [24] 3649 	mov	_main_sloc0_1_0,c
      00125B 40 24            [24] 3650 	jc	00140$
                                   3651 ;	optimized_main.c:682: if(isdigit(buffer[11]) && isdigit(buffer[12]) && isdigit(buffer[13]) && bufferIndex >= 13)
      00125D BE 0D 00         [24] 3652 	cjne	r6,#0x0d,01402$
      001260                       3653 01402$:
      001260 40 1F            [24] 3654 	jc	00140$
                                   3655 ;	optimized_main.c:685: ip[2] =  ((buffer[11] - '0') * 100) + ((buffer[12] - '0') * 10) + ((buffer[13] - '0'));
      001262 78 85            [12] 3656 	mov	r0,#(_main_buffer_10001_179 + 0x000b)
      001264 E2               [24] 3657 	movx	a,@r0
      001265 24 D0            [12] 3658 	add	a,#0xd0
      001267 75 F0 64         [24] 3659 	mov	b,#0x64
      00126A A4               [48] 3660 	mul	ab
      00126B FC               [12] 3661 	mov	r4,a
      00126C 78 86            [12] 3662 	mov	r0,#(_main_buffer_10001_179 + 0x000c)
      00126E E2               [24] 3663 	movx	a,@r0
      00126F 24 D0            [12] 3664 	add	a,#0xd0
      001271 75 F0 0A         [24] 3665 	mov	b,#0x0a
      001274 A4               [48] 3666 	mul	ab
      001275 2C               [12] 3667 	add	a, r4
      001276 FC               [12] 3668 	mov	r4,a
      001277 78 87            [12] 3669 	mov	r0,#(_main_buffer_10001_179 + 0x000d)
      001279 E2               [24] 3670 	movx	a,@r0
      00127A 24 D0            [12] 3671 	add	a,#0xd0
      00127C 2C               [12] 3672 	add	a, r4
      00127D 90 00 93         [24] 3673 	mov	dptr,#(_main_ip_10000_178 + 0x0002)
      001280 F0               [24] 3674 	movx	@dptr,a
      001281                       3675 00140$:
                                   3676 ;	optimized_main.c:688: if(isdigit(buffer[15]) && isdigit(buffer[16]) && isdigit(buffer[17]) && bufferIndex >= 17)
      001281 78 89            [12] 3677 	mov	r0,#(_main_buffer_10001_179 + 0x000f)
      001283 E2               [24] 3678 	movx	a,@r0
      001284 FC               [12] 3679 	mov	r4,a
                                   3680 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001285 BC 30 00         [24] 3681 	cjne	r4,#0x30,01404$
      001288                       3682 01404$:
      001288 92 01            [24] 3683 	mov	_main_sloc0_1_0,c
      00128A 40 64            [24] 3684 	jc	00145$
      00128C EC               [12] 3685 	mov	a,r4
      00128D 24 C6            [12] 3686 	add	a,#0xff - 0x39
      00128F 92 01            [24] 3687 	mov	_main_sloc0_1_0,c
      001291 40 5D            [24] 3688 	jc	00145$
                                   3689 ;	optimized_main.c:688: if(isdigit(buffer[15]) && isdigit(buffer[16]) && isdigit(buffer[17]) && bufferIndex >= 17)
      001293 78 8A            [12] 3690 	mov	r0,#(_main_buffer_10001_179 + 0x0010)
      001295 E2               [24] 3691 	movx	a,@r0
      001296 FC               [12] 3692 	mov	r4,a
                                   3693 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001297 BC 30 00         [24] 3694 	cjne	r4,#0x30,01407$
      00129A                       3695 01407$:
      00129A 92 01            [24] 3696 	mov	_main_sloc0_1_0,c
      00129C 40 52            [24] 3697 	jc	00145$
      00129E EC               [12] 3698 	mov	a,r4
      00129F 24 C6            [12] 3699 	add	a,#0xff - 0x39
      0012A1 92 01            [24] 3700 	mov	_main_sloc0_1_0,c
      0012A3 40 4B            [24] 3701 	jc	00145$
                                   3702 ;	optimized_main.c:688: if(isdigit(buffer[15]) && isdigit(buffer[16]) && isdigit(buffer[17]) && bufferIndex >= 17)
      0012A5 78 8B            [12] 3703 	mov	r0,#(_main_buffer_10001_179 + 0x0011)
      0012A7 E2               [24] 3704 	movx	a,@r0
      0012A8 FC               [12] 3705 	mov	r4,a
                                   3706 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0012A9 BC 30 00         [24] 3707 	cjne	r4,#0x30,01410$
      0012AC                       3708 01410$:
      0012AC 92 01            [24] 3709 	mov	_main_sloc0_1_0,c
      0012AE 40 40            [24] 3710 	jc	00145$
      0012B0 EC               [12] 3711 	mov	a,r4
      0012B1 24 C6            [12] 3712 	add	a,#0xff - 0x39
      0012B3 92 01            [24] 3713 	mov	_main_sloc0_1_0,c
      0012B5 40 39            [24] 3714 	jc	00145$
                                   3715 ;	optimized_main.c:688: if(isdigit(buffer[15]) && isdigit(buffer[16]) && isdigit(buffer[17]) && bufferIndex >= 17)
      0012B7 BE 11 00         [24] 3716 	cjne	r6,#0x11,01413$
      0012BA                       3717 01413$:
      0012BA 40 34            [24] 3718 	jc	00145$
                                   3719 ;	optimized_main.c:691: ip[3] =  ((buffer[15] - '0') * 100) + ((buffer[16] - '0') * 10) + ((buffer[17] - '0'));
      0012BC 78 89            [12] 3720 	mov	r0,#(_main_buffer_10001_179 + 0x000f)
      0012BE E2               [24] 3721 	movx	a,@r0
      0012BF 24 D0            [12] 3722 	add	a,#0xd0
      0012C1 75 F0 64         [24] 3723 	mov	b,#0x64
      0012C4 A4               [48] 3724 	mul	ab
      0012C5 FC               [12] 3725 	mov	r4,a
      0012C6 78 8A            [12] 3726 	mov	r0,#(_main_buffer_10001_179 + 0x0010)
      0012C8 E2               [24] 3727 	movx	a,@r0
      0012C9 24 D0            [12] 3728 	add	a,#0xd0
      0012CB 75 F0 0A         [24] 3729 	mov	b,#0x0a
      0012CE A4               [48] 3730 	mul	ab
      0012CF 2C               [12] 3731 	add	a, r4
      0012D0 FC               [12] 3732 	mov	r4,a
      0012D1 78 8B            [12] 3733 	mov	r0,#(_main_buffer_10001_179 + 0x0011)
      0012D3 E2               [24] 3734 	movx	a,@r0
      0012D4 24 D0            [12] 3735 	add	a,#0xd0
      0012D6 2C               [12] 3736 	add	a, r4
      0012D7 90 00 94         [24] 3737 	mov	dptr,#(_main_ip_10000_178 + 0x0003)
      0012DA F0               [24] 3738 	movx	@dptr,a
                                   3739 ;	optimized_main.c:692: WIZnet_SetIP(ip);
      0012DB 90 00 91         [24] 3740 	mov	dptr,#_main_ip_10000_178
      0012DE 75 F0 00         [24] 3741 	mov	b, #0x00
      0012E1 C0 07            [24] 3742 	push	ar7
      0012E3 C0 06            [24] 3743 	push	ar6
      0012E5 C0 05            [24] 3744 	push	ar5
      0012E7 12 01 5B         [24] 3745 	lcall	_WIZnet_SetIP
      0012EA D0 05            [24] 3746 	pop	ar5
      0012EC D0 06            [24] 3747 	pop	ar6
      0012EE D0 07            [24] 3748 	pop	ar7
      0012F0                       3749 00145$:
                                   3750 ;	optimized_main.c:694: if(bufferIndex>17)
      0012F0 EE               [12] 3751 	mov	a,r6
      0012F1 24 EE            [12] 3752 	add	a,#0xff - 0x11
      0012F3 40 03            [24] 3753 	jc	01415$
      0012F5 02 17 84         [24] 3754 	ljmp	00244$
      0012F8                       3755 01415$:
                                   3756 ;	optimized_main.c:696: bufferIndex=0;
      0012F8 7E 00            [12] 3757 	mov	r6,#0x00
      0012FA 02 17 84         [24] 3758 	ljmp	00244$
      0012FD                       3759 00243$:
                                   3760 ;	optimized_main.c:700: else if(serialInputMode == 2) //SUB address input mode
      0012FD BD 02 02         [24] 3761 	cjne	r5,#0x02,01416$
      001300 80 03            [24] 3762 	sjmp	01417$
      001302                       3763 01416$:
      001302 02 14 8F         [24] 3764 	ljmp	00240$
      001305                       3765 01417$:
                                   3766 ;	optimized_main.c:703: if(isdigit(buffer[4]) && isdigit(buffer[5]) && isdigit(buffer[6]) && bufferIndex >= 6)
      001305 78 7E            [12] 3767 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      001307 E2               [24] 3768 	movx	a,@r0
      001308 FC               [12] 3769 	mov	r4,a
                                   3770 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001309 BC 30 00         [24] 3771 	cjne	r4,#0x30,01418$
      00130C                       3772 01418$:
      00130C 92 01            [24] 3773 	mov	_main_sloc0_1_0,c
      00130E 40 4F            [24] 3774 	jc	00152$
      001310 EC               [12] 3775 	mov	a,r4
      001311 24 C6            [12] 3776 	add	a,#0xff - 0x39
      001313 92 01            [24] 3777 	mov	_main_sloc0_1_0,c
      001315 40 48            [24] 3778 	jc	00152$
                                   3779 ;	optimized_main.c:703: if(isdigit(buffer[4]) && isdigit(buffer[5]) && isdigit(buffer[6]) && bufferIndex >= 6)
      001317 78 7F            [12] 3780 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      001319 E2               [24] 3781 	movx	a,@r0
      00131A FC               [12] 3782 	mov	r4,a
                                   3783 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00131B BC 30 00         [24] 3784 	cjne	r4,#0x30,01421$
      00131E                       3785 01421$:
      00131E 92 01            [24] 3786 	mov	_main_sloc0_1_0,c
      001320 40 3D            [24] 3787 	jc	00152$
      001322 EC               [12] 3788 	mov	a,r4
      001323 24 C6            [12] 3789 	add	a,#0xff - 0x39
      001325 92 01            [24] 3790 	mov	_main_sloc0_1_0,c
      001327 40 36            [24] 3791 	jc	00152$
                                   3792 ;	optimized_main.c:703: if(isdigit(buffer[4]) && isdigit(buffer[5]) && isdigit(buffer[6]) && bufferIndex >= 6)
      001329 78 80            [12] 3793 	mov	r0,#(_main_buffer_10001_179 + 0x0006)
      00132B E2               [24] 3794 	movx	a,@r0
      00132C FC               [12] 3795 	mov	r4,a
                                   3796 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00132D BC 30 00         [24] 3797 	cjne	r4,#0x30,01424$
      001330                       3798 01424$:
      001330 92 01            [24] 3799 	mov	_main_sloc0_1_0,c
      001332 40 2B            [24] 3800 	jc	00152$
      001334 EC               [12] 3801 	mov	a,r4
      001335 24 C6            [12] 3802 	add	a,#0xff - 0x39
      001337 92 01            [24] 3803 	mov	_main_sloc0_1_0,c
      001339 40 24            [24] 3804 	jc	00152$
                                   3805 ;	optimized_main.c:703: if(isdigit(buffer[4]) && isdigit(buffer[5]) && isdigit(buffer[6]) && bufferIndex >= 6)
      00133B BE 06 00         [24] 3806 	cjne	r6,#0x06,01427$
      00133E                       3807 01427$:
      00133E 40 1F            [24] 3808 	jc	00152$
                                   3809 ;	optimized_main.c:706: subnet[0] =  ((buffer[4] - '0') * 100) + ((buffer[5] - '0') * 10) + ((buffer[6] - '0'));
      001340 78 7E            [12] 3810 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      001342 E2               [24] 3811 	movx	a,@r0
      001343 24 D0            [12] 3812 	add	a,#0xd0
      001345 75 F0 64         [24] 3813 	mov	b,#0x64
      001348 A4               [48] 3814 	mul	ab
      001349 FC               [12] 3815 	mov	r4,a
      00134A 78 7F            [12] 3816 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      00134C E2               [24] 3817 	movx	a,@r0
      00134D 24 D0            [12] 3818 	add	a,#0xd0
      00134F 75 F0 0A         [24] 3819 	mov	b,#0x0a
      001352 A4               [48] 3820 	mul	ab
      001353 2C               [12] 3821 	add	a, r4
      001354 FC               [12] 3822 	mov	r4,a
      001355 78 80            [12] 3823 	mov	r0,#(_main_buffer_10001_179 + 0x0006)
      001357 E2               [24] 3824 	movx	a,@r0
      001358 24 D0            [12] 3825 	add	a,#0xd0
      00135A 2C               [12] 3826 	add	a, r4
      00135B 90 00 9B         [24] 3827 	mov	dptr,#_main_subnet_10000_178
      00135E F0               [24] 3828 	movx	@dptr,a
      00135F                       3829 00152$:
                                   3830 ;	optimized_main.c:709: if(isdigit(buffer[8]) && isdigit(buffer[9]) && isdigit(buffer[10]) && bufferIndex >= 10)
      00135F 78 82            [12] 3831 	mov	r0,#(_main_buffer_10001_179 + 0x0008)
      001361 E2               [24] 3832 	movx	a,@r0
      001362 FC               [12] 3833 	mov	r4,a
                                   3834 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001363 BC 30 00         [24] 3835 	cjne	r4,#0x30,01429$
      001366                       3836 01429$:
      001366 92 01            [24] 3837 	mov	_main_sloc0_1_0,c
      001368 40 4F            [24] 3838 	jc	00157$
      00136A EC               [12] 3839 	mov	a,r4
      00136B 24 C6            [12] 3840 	add	a,#0xff - 0x39
      00136D 92 01            [24] 3841 	mov	_main_sloc0_1_0,c
      00136F 40 48            [24] 3842 	jc	00157$
                                   3843 ;	optimized_main.c:709: if(isdigit(buffer[8]) && isdigit(buffer[9]) && isdigit(buffer[10]) && bufferIndex >= 10)
      001371 78 83            [12] 3844 	mov	r0,#(_main_buffer_10001_179 + 0x0009)
      001373 E2               [24] 3845 	movx	a,@r0
      001374 FC               [12] 3846 	mov	r4,a
                                   3847 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001375 BC 30 00         [24] 3848 	cjne	r4,#0x30,01432$
      001378                       3849 01432$:
      001378 92 01            [24] 3850 	mov	_main_sloc0_1_0,c
      00137A 40 3D            [24] 3851 	jc	00157$
      00137C EC               [12] 3852 	mov	a,r4
      00137D 24 C6            [12] 3853 	add	a,#0xff - 0x39
      00137F 92 01            [24] 3854 	mov	_main_sloc0_1_0,c
      001381 40 36            [24] 3855 	jc	00157$
                                   3856 ;	optimized_main.c:709: if(isdigit(buffer[8]) && isdigit(buffer[9]) && isdigit(buffer[10]) && bufferIndex >= 10)
      001383 78 84            [12] 3857 	mov	r0,#(_main_buffer_10001_179 + 0x000a)
      001385 E2               [24] 3858 	movx	a,@r0
      001386 FC               [12] 3859 	mov	r4,a
                                   3860 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001387 BC 30 00         [24] 3861 	cjne	r4,#0x30,01435$
      00138A                       3862 01435$:
      00138A 92 01            [24] 3863 	mov	_main_sloc0_1_0,c
      00138C 40 2B            [24] 3864 	jc	00157$
      00138E EC               [12] 3865 	mov	a,r4
      00138F 24 C6            [12] 3866 	add	a,#0xff - 0x39
      001391 92 01            [24] 3867 	mov	_main_sloc0_1_0,c
      001393 40 24            [24] 3868 	jc	00157$
                                   3869 ;	optimized_main.c:709: if(isdigit(buffer[8]) && isdigit(buffer[9]) && isdigit(buffer[10]) && bufferIndex >= 10)
      001395 BE 0A 00         [24] 3870 	cjne	r6,#0x0a,01438$
      001398                       3871 01438$:
      001398 40 1F            [24] 3872 	jc	00157$
                                   3873 ;	optimized_main.c:712: subnet[1] =  ((buffer[8] - '0') * 100) + ((buffer[9] - '0') * 10) + ((buffer[10] - '0'));
      00139A 78 82            [12] 3874 	mov	r0,#(_main_buffer_10001_179 + 0x0008)
      00139C E2               [24] 3875 	movx	a,@r0
      00139D 24 D0            [12] 3876 	add	a,#0xd0
      00139F 75 F0 64         [24] 3877 	mov	b,#0x64
      0013A2 A4               [48] 3878 	mul	ab
      0013A3 FC               [12] 3879 	mov	r4,a
      0013A4 78 83            [12] 3880 	mov	r0,#(_main_buffer_10001_179 + 0x0009)
      0013A6 E2               [24] 3881 	movx	a,@r0
      0013A7 24 D0            [12] 3882 	add	a,#0xd0
      0013A9 75 F0 0A         [24] 3883 	mov	b,#0x0a
      0013AC A4               [48] 3884 	mul	ab
      0013AD 2C               [12] 3885 	add	a, r4
      0013AE FC               [12] 3886 	mov	r4,a
      0013AF 78 84            [12] 3887 	mov	r0,#(_main_buffer_10001_179 + 0x000a)
      0013B1 E2               [24] 3888 	movx	a,@r0
      0013B2 24 D0            [12] 3889 	add	a,#0xd0
      0013B4 2C               [12] 3890 	add	a, r4
      0013B5 90 00 9C         [24] 3891 	mov	dptr,#(_main_subnet_10000_178 + 0x0001)
      0013B8 F0               [24] 3892 	movx	@dptr,a
      0013B9                       3893 00157$:
                                   3894 ;	optimized_main.c:715: if(isdigit(buffer[12]) && isdigit(buffer[13]) && isdigit(buffer[14]) && bufferIndex >= 14)
      0013B9 78 86            [12] 3895 	mov	r0,#(_main_buffer_10001_179 + 0x000c)
      0013BB E2               [24] 3896 	movx	a,@r0
      0013BC FC               [12] 3897 	mov	r4,a
                                   3898 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0013BD BC 30 00         [24] 3899 	cjne	r4,#0x30,01440$
      0013C0                       3900 01440$:
      0013C0 92 01            [24] 3901 	mov	_main_sloc0_1_0,c
      0013C2 40 4F            [24] 3902 	jc	00162$
      0013C4 EC               [12] 3903 	mov	a,r4
      0013C5 24 C6            [12] 3904 	add	a,#0xff - 0x39
      0013C7 92 01            [24] 3905 	mov	_main_sloc0_1_0,c
      0013C9 40 48            [24] 3906 	jc	00162$
                                   3907 ;	optimized_main.c:715: if(isdigit(buffer[12]) && isdigit(buffer[13]) && isdigit(buffer[14]) && bufferIndex >= 14)
      0013CB 78 87            [12] 3908 	mov	r0,#(_main_buffer_10001_179 + 0x000d)
      0013CD E2               [24] 3909 	movx	a,@r0
      0013CE FC               [12] 3910 	mov	r4,a
                                   3911 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0013CF BC 30 00         [24] 3912 	cjne	r4,#0x30,01443$
      0013D2                       3913 01443$:
      0013D2 92 01            [24] 3914 	mov	_main_sloc0_1_0,c
      0013D4 40 3D            [24] 3915 	jc	00162$
      0013D6 EC               [12] 3916 	mov	a,r4
      0013D7 24 C6            [12] 3917 	add	a,#0xff - 0x39
      0013D9 92 01            [24] 3918 	mov	_main_sloc0_1_0,c
      0013DB 40 36            [24] 3919 	jc	00162$
                                   3920 ;	optimized_main.c:715: if(isdigit(buffer[12]) && isdigit(buffer[13]) && isdigit(buffer[14]) && bufferIndex >= 14)
      0013DD 78 88            [12] 3921 	mov	r0,#(_main_buffer_10001_179 + 0x000e)
      0013DF E2               [24] 3922 	movx	a,@r0
      0013E0 FC               [12] 3923 	mov	r4,a
                                   3924 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0013E1 BC 30 00         [24] 3925 	cjne	r4,#0x30,01446$
      0013E4                       3926 01446$:
      0013E4 92 01            [24] 3927 	mov	_main_sloc0_1_0,c
      0013E6 40 2B            [24] 3928 	jc	00162$
      0013E8 EC               [12] 3929 	mov	a,r4
      0013E9 24 C6            [12] 3930 	add	a,#0xff - 0x39
      0013EB 92 01            [24] 3931 	mov	_main_sloc0_1_0,c
      0013ED 40 24            [24] 3932 	jc	00162$
                                   3933 ;	optimized_main.c:715: if(isdigit(buffer[12]) && isdigit(buffer[13]) && isdigit(buffer[14]) && bufferIndex >= 14)
      0013EF BE 0E 00         [24] 3934 	cjne	r6,#0x0e,01449$
      0013F2                       3935 01449$:
      0013F2 40 1F            [24] 3936 	jc	00162$
                                   3937 ;	optimized_main.c:718: subnet[2] =  ((buffer[12] - '0') * 100) + ((buffer[13] - '0') * 10) + ((buffer[14] - '0'));
      0013F4 78 86            [12] 3938 	mov	r0,#(_main_buffer_10001_179 + 0x000c)
      0013F6 E2               [24] 3939 	movx	a,@r0
      0013F7 24 D0            [12] 3940 	add	a,#0xd0
      0013F9 75 F0 64         [24] 3941 	mov	b,#0x64
      0013FC A4               [48] 3942 	mul	ab
      0013FD FC               [12] 3943 	mov	r4,a
      0013FE 78 87            [12] 3944 	mov	r0,#(_main_buffer_10001_179 + 0x000d)
      001400 E2               [24] 3945 	movx	a,@r0
      001401 24 D0            [12] 3946 	add	a,#0xd0
      001403 75 F0 0A         [24] 3947 	mov	b,#0x0a
      001406 A4               [48] 3948 	mul	ab
      001407 2C               [12] 3949 	add	a, r4
      001408 FC               [12] 3950 	mov	r4,a
      001409 78 88            [12] 3951 	mov	r0,#(_main_buffer_10001_179 + 0x000e)
      00140B E2               [24] 3952 	movx	a,@r0
      00140C 24 D0            [12] 3953 	add	a,#0xd0
      00140E 2C               [12] 3954 	add	a, r4
      00140F 90 00 9D         [24] 3955 	mov	dptr,#(_main_subnet_10000_178 + 0x0002)
      001412 F0               [24] 3956 	movx	@dptr,a
      001413                       3957 00162$:
                                   3958 ;	optimized_main.c:721: if(isdigit(buffer[16]) && isdigit(buffer[17]) && isdigit(buffer[18]) && bufferIndex >= 18)
      001413 78 8A            [12] 3959 	mov	r0,#(_main_buffer_10001_179 + 0x0010)
      001415 E2               [24] 3960 	movx	a,@r0
      001416 FC               [12] 3961 	mov	r4,a
                                   3962 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001417 BC 30 00         [24] 3963 	cjne	r4,#0x30,01451$
      00141A                       3964 01451$:
      00141A 92 01            [24] 3965 	mov	_main_sloc0_1_0,c
      00141C 40 64            [24] 3966 	jc	00167$
      00141E EC               [12] 3967 	mov	a,r4
      00141F 24 C6            [12] 3968 	add	a,#0xff - 0x39
      001421 92 01            [24] 3969 	mov	_main_sloc0_1_0,c
      001423 40 5D            [24] 3970 	jc	00167$
                                   3971 ;	optimized_main.c:721: if(isdigit(buffer[16]) && isdigit(buffer[17]) && isdigit(buffer[18]) && bufferIndex >= 18)
      001425 78 8B            [12] 3972 	mov	r0,#(_main_buffer_10001_179 + 0x0011)
      001427 E2               [24] 3973 	movx	a,@r0
      001428 FC               [12] 3974 	mov	r4,a
                                   3975 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001429 BC 30 00         [24] 3976 	cjne	r4,#0x30,01454$
      00142C                       3977 01454$:
      00142C 92 01            [24] 3978 	mov	_main_sloc0_1_0,c
      00142E 40 52            [24] 3979 	jc	00167$
      001430 EC               [12] 3980 	mov	a,r4
      001431 24 C6            [12] 3981 	add	a,#0xff - 0x39
      001433 92 01            [24] 3982 	mov	_main_sloc0_1_0,c
      001435 40 4B            [24] 3983 	jc	00167$
                                   3984 ;	optimized_main.c:721: if(isdigit(buffer[16]) && isdigit(buffer[17]) && isdigit(buffer[18]) && bufferIndex >= 18)
      001437 78 8C            [12] 3985 	mov	r0,#(_main_buffer_10001_179 + 0x0012)
      001439 E2               [24] 3986 	movx	a,@r0
      00143A FC               [12] 3987 	mov	r4,a
                                   3988 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00143B BC 30 00         [24] 3989 	cjne	r4,#0x30,01457$
      00143E                       3990 01457$:
      00143E 92 01            [24] 3991 	mov	_main_sloc0_1_0,c
      001440 40 40            [24] 3992 	jc	00167$
      001442 EC               [12] 3993 	mov	a,r4
      001443 24 C6            [12] 3994 	add	a,#0xff - 0x39
      001445 92 01            [24] 3995 	mov	_main_sloc0_1_0,c
      001447 40 39            [24] 3996 	jc	00167$
                                   3997 ;	optimized_main.c:721: if(isdigit(buffer[16]) && isdigit(buffer[17]) && isdigit(buffer[18]) && bufferIndex >= 18)
      001449 BE 12 00         [24] 3998 	cjne	r6,#0x12,01460$
      00144C                       3999 01460$:
      00144C 40 34            [24] 4000 	jc	00167$
                                   4001 ;	optimized_main.c:724: subnet[3] =  ((buffer[16] - '0') * 100) + ((buffer[17] - '0') * 10) + ((buffer[18] - '0'));
      00144E 78 8A            [12] 4002 	mov	r0,#(_main_buffer_10001_179 + 0x0010)
      001450 E2               [24] 4003 	movx	a,@r0
      001451 24 D0            [12] 4004 	add	a,#0xd0
      001453 75 F0 64         [24] 4005 	mov	b,#0x64
      001456 A4               [48] 4006 	mul	ab
      001457 FC               [12] 4007 	mov	r4,a
      001458 78 8B            [12] 4008 	mov	r0,#(_main_buffer_10001_179 + 0x0011)
      00145A E2               [24] 4009 	movx	a,@r0
      00145B 24 D0            [12] 4010 	add	a,#0xd0
      00145D 75 F0 0A         [24] 4011 	mov	b,#0x0a
      001460 A4               [48] 4012 	mul	ab
      001461 2C               [12] 4013 	add	a, r4
      001462 FC               [12] 4014 	mov	r4,a
      001463 78 8C            [12] 4015 	mov	r0,#(_main_buffer_10001_179 + 0x0012)
      001465 E2               [24] 4016 	movx	a,@r0
      001466 24 D0            [12] 4017 	add	a,#0xd0
      001468 2C               [12] 4018 	add	a, r4
      001469 90 00 9E         [24] 4019 	mov	dptr,#(_main_subnet_10000_178 + 0x0003)
      00146C F0               [24] 4020 	movx	@dptr,a
                                   4021 ;	optimized_main.c:725: WIZnet_SetSubnetMask(subnet);    
      00146D 90 00 9B         [24] 4022 	mov	dptr,#_main_subnet_10000_178
      001470 75 F0 00         [24] 4023 	mov	b, #0x00
      001473 C0 07            [24] 4024 	push	ar7
      001475 C0 06            [24] 4025 	push	ar6
      001477 C0 05            [24] 4026 	push	ar5
      001479 12 01 EF         [24] 4027 	lcall	_WIZnet_SetSubnetMask
      00147C D0 05            [24] 4028 	pop	ar5
      00147E D0 06            [24] 4029 	pop	ar6
      001480 D0 07            [24] 4030 	pop	ar7
      001482                       4031 00167$:
                                   4032 ;	optimized_main.c:728: if(bufferIndex>18)
      001482 EE               [12] 4033 	mov	a,r6
      001483 24 ED            [12] 4034 	add	a,#0xff - 0x12
      001485 40 03            [24] 4035 	jc	01462$
      001487 02 17 84         [24] 4036 	ljmp	00244$
      00148A                       4037 01462$:
                                   4038 ;	optimized_main.c:730: bufferIndex=0;
      00148A 7E 00            [12] 4039 	mov	r6,#0x00
      00148C 02 17 84         [24] 4040 	ljmp	00244$
      00148F                       4041 00240$:
                                   4042 ;	optimized_main.c:733: else if(serialInputMode == 3) //GATE address input mode
      00148F BD 03 02         [24] 4043 	cjne	r5,#0x03,01463$
      001492 80 03            [24] 4044 	sjmp	01464$
      001494                       4045 01463$:
      001494 02 16 21         [24] 4046 	ljmp	00237$
      001497                       4047 01464$:
                                   4048 ;	optimized_main.c:736: if(isdigit(buffer[5]) && isdigit(buffer[6]) && isdigit(buffer[7]) && bufferIndex >= 7)
      001497 78 7F            [12] 4049 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      001499 E2               [24] 4050 	movx	a,@r0
      00149A FC               [12] 4051 	mov	r4,a
                                   4052 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00149B BC 30 00         [24] 4053 	cjne	r4,#0x30,01465$
      00149E                       4054 01465$:
      00149E 92 01            [24] 4055 	mov	_main_sloc0_1_0,c
      0014A0 40 4F            [24] 4056 	jc	00174$
      0014A2 EC               [12] 4057 	mov	a,r4
      0014A3 24 C6            [12] 4058 	add	a,#0xff - 0x39
      0014A5 92 01            [24] 4059 	mov	_main_sloc0_1_0,c
      0014A7 40 48            [24] 4060 	jc	00174$
                                   4061 ;	optimized_main.c:736: if(isdigit(buffer[5]) && isdigit(buffer[6]) && isdigit(buffer[7]) && bufferIndex >= 7)
      0014A9 78 80            [12] 4062 	mov	r0,#(_main_buffer_10001_179 + 0x0006)
      0014AB E2               [24] 4063 	movx	a,@r0
      0014AC FC               [12] 4064 	mov	r4,a
                                   4065 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0014AD BC 30 00         [24] 4066 	cjne	r4,#0x30,01468$
      0014B0                       4067 01468$:
      0014B0 92 01            [24] 4068 	mov	_main_sloc0_1_0,c
      0014B2 40 3D            [24] 4069 	jc	00174$
      0014B4 EC               [12] 4070 	mov	a,r4
      0014B5 24 C6            [12] 4071 	add	a,#0xff - 0x39
      0014B7 92 01            [24] 4072 	mov	_main_sloc0_1_0,c
      0014B9 40 36            [24] 4073 	jc	00174$
                                   4074 ;	optimized_main.c:736: if(isdigit(buffer[5]) && isdigit(buffer[6]) && isdigit(buffer[7]) && bufferIndex >= 7)
      0014BB 78 81            [12] 4075 	mov	r0,#(_main_buffer_10001_179 + 0x0007)
      0014BD E2               [24] 4076 	movx	a,@r0
      0014BE FC               [12] 4077 	mov	r4,a
                                   4078 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0014BF BC 30 00         [24] 4079 	cjne	r4,#0x30,01471$
      0014C2                       4080 01471$:
      0014C2 92 01            [24] 4081 	mov	_main_sloc0_1_0,c
      0014C4 40 2B            [24] 4082 	jc	00174$
      0014C6 EC               [12] 4083 	mov	a,r4
      0014C7 24 C6            [12] 4084 	add	a,#0xff - 0x39
      0014C9 92 01            [24] 4085 	mov	_main_sloc0_1_0,c
      0014CB 40 24            [24] 4086 	jc	00174$
                                   4087 ;	optimized_main.c:736: if(isdigit(buffer[5]) && isdigit(buffer[6]) && isdigit(buffer[7]) && bufferIndex >= 7)
      0014CD BE 07 00         [24] 4088 	cjne	r6,#0x07,01474$
      0014D0                       4089 01474$:
      0014D0 40 1F            [24] 4090 	jc	00174$
                                   4091 ;	optimized_main.c:739: gateway[0] =  ((buffer[5] - '0') * 100) + ((buffer[6] - '0') * 10) + ((buffer[7] - '0'));
      0014D2 78 7F            [12] 4092 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      0014D4 E2               [24] 4093 	movx	a,@r0
      0014D5 24 D0            [12] 4094 	add	a,#0xd0
      0014D7 75 F0 64         [24] 4095 	mov	b,#0x64
      0014DA A4               [48] 4096 	mul	ab
      0014DB FC               [12] 4097 	mov	r4,a
      0014DC 78 80            [12] 4098 	mov	r0,#(_main_buffer_10001_179 + 0x0006)
      0014DE E2               [24] 4099 	movx	a,@r0
      0014DF 24 D0            [12] 4100 	add	a,#0xd0
      0014E1 75 F0 0A         [24] 4101 	mov	b,#0x0a
      0014E4 A4               [48] 4102 	mul	ab
      0014E5 2C               [12] 4103 	add	a, r4
      0014E6 FC               [12] 4104 	mov	r4,a
      0014E7 78 81            [12] 4105 	mov	r0,#(_main_buffer_10001_179 + 0x0007)
      0014E9 E2               [24] 4106 	movx	a,@r0
      0014EA 24 D0            [12] 4107 	add	a,#0xd0
      0014EC 2C               [12] 4108 	add	a, r4
      0014ED 90 00 9F         [24] 4109 	mov	dptr,#_main_gateway_10000_178
      0014F0 F0               [24] 4110 	movx	@dptr,a
      0014F1                       4111 00174$:
                                   4112 ;	optimized_main.c:742: if(isdigit(buffer[9]) && isdigit(buffer[10]) && isdigit(buffer[11]) && bufferIndex >= 11)
      0014F1 78 83            [12] 4113 	mov	r0,#(_main_buffer_10001_179 + 0x0009)
      0014F3 E2               [24] 4114 	movx	a,@r0
      0014F4 FC               [12] 4115 	mov	r4,a
                                   4116 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0014F5 BC 30 00         [24] 4117 	cjne	r4,#0x30,01476$
      0014F8                       4118 01476$:
      0014F8 92 01            [24] 4119 	mov	_main_sloc0_1_0,c
      0014FA 40 4F            [24] 4120 	jc	00179$
      0014FC EC               [12] 4121 	mov	a,r4
      0014FD 24 C6            [12] 4122 	add	a,#0xff - 0x39
      0014FF 92 01            [24] 4123 	mov	_main_sloc0_1_0,c
      001501 40 48            [24] 4124 	jc	00179$
                                   4125 ;	optimized_main.c:742: if(isdigit(buffer[9]) && isdigit(buffer[10]) && isdigit(buffer[11]) && bufferIndex >= 11)
      001503 78 84            [12] 4126 	mov	r0,#(_main_buffer_10001_179 + 0x000a)
      001505 E2               [24] 4127 	movx	a,@r0
      001506 FC               [12] 4128 	mov	r4,a
                                   4129 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001507 BC 30 00         [24] 4130 	cjne	r4,#0x30,01479$
      00150A                       4131 01479$:
      00150A 92 01            [24] 4132 	mov	_main_sloc0_1_0,c
      00150C 40 3D            [24] 4133 	jc	00179$
      00150E EC               [12] 4134 	mov	a,r4
      00150F 24 C6            [12] 4135 	add	a,#0xff - 0x39
      001511 92 01            [24] 4136 	mov	_main_sloc0_1_0,c
      001513 40 36            [24] 4137 	jc	00179$
                                   4138 ;	optimized_main.c:742: if(isdigit(buffer[9]) && isdigit(buffer[10]) && isdigit(buffer[11]) && bufferIndex >= 11)
      001515 78 85            [12] 4139 	mov	r0,#(_main_buffer_10001_179 + 0x000b)
      001517 E2               [24] 4140 	movx	a,@r0
      001518 FC               [12] 4141 	mov	r4,a
                                   4142 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001519 BC 30 00         [24] 4143 	cjne	r4,#0x30,01482$
      00151C                       4144 01482$:
      00151C 92 01            [24] 4145 	mov	_main_sloc0_1_0,c
      00151E 40 2B            [24] 4146 	jc	00179$
      001520 EC               [12] 4147 	mov	a,r4
      001521 24 C6            [12] 4148 	add	a,#0xff - 0x39
      001523 92 01            [24] 4149 	mov	_main_sloc0_1_0,c
      001525 40 24            [24] 4150 	jc	00179$
                                   4151 ;	optimized_main.c:742: if(isdigit(buffer[9]) && isdigit(buffer[10]) && isdigit(buffer[11]) && bufferIndex >= 11)
      001527 BE 0B 00         [24] 4152 	cjne	r6,#0x0b,01485$
      00152A                       4153 01485$:
      00152A 40 1F            [24] 4154 	jc	00179$
                                   4155 ;	optimized_main.c:745: gateway[1] =  ((buffer[9] - '0') * 100) + ((buffer[10] - '0') * 10) + ((buffer[11] - '0'));
      00152C 78 83            [12] 4156 	mov	r0,#(_main_buffer_10001_179 + 0x0009)
      00152E E2               [24] 4157 	movx	a,@r0
      00152F 24 D0            [12] 4158 	add	a,#0xd0
      001531 75 F0 64         [24] 4159 	mov	b,#0x64
      001534 A4               [48] 4160 	mul	ab
      001535 FC               [12] 4161 	mov	r4,a
      001536 78 84            [12] 4162 	mov	r0,#(_main_buffer_10001_179 + 0x000a)
      001538 E2               [24] 4163 	movx	a,@r0
      001539 24 D0            [12] 4164 	add	a,#0xd0
      00153B 75 F0 0A         [24] 4165 	mov	b,#0x0a
      00153E A4               [48] 4166 	mul	ab
      00153F 2C               [12] 4167 	add	a, r4
      001540 FC               [12] 4168 	mov	r4,a
      001541 78 85            [12] 4169 	mov	r0,#(_main_buffer_10001_179 + 0x000b)
      001543 E2               [24] 4170 	movx	a,@r0
      001544 24 D0            [12] 4171 	add	a,#0xd0
      001546 2C               [12] 4172 	add	a, r4
      001547 90 00 A0         [24] 4173 	mov	dptr,#(_main_gateway_10000_178 + 0x0001)
      00154A F0               [24] 4174 	movx	@dptr,a
      00154B                       4175 00179$:
                                   4176 ;	optimized_main.c:748: if(isdigit(buffer[13]) && isdigit(buffer[14]) && isdigit(buffer[15]) && bufferIndex >= 15)
      00154B 78 87            [12] 4177 	mov	r0,#(_main_buffer_10001_179 + 0x000d)
      00154D E2               [24] 4178 	movx	a,@r0
      00154E FC               [12] 4179 	mov	r4,a
                                   4180 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      00154F BC 30 00         [24] 4181 	cjne	r4,#0x30,01487$
      001552                       4182 01487$:
      001552 92 01            [24] 4183 	mov	_main_sloc0_1_0,c
      001554 40 4F            [24] 4184 	jc	00184$
      001556 EC               [12] 4185 	mov	a,r4
      001557 24 C6            [12] 4186 	add	a,#0xff - 0x39
      001559 92 01            [24] 4187 	mov	_main_sloc0_1_0,c
      00155B 40 48            [24] 4188 	jc	00184$
                                   4189 ;	optimized_main.c:748: if(isdigit(buffer[13]) && isdigit(buffer[14]) && isdigit(buffer[15]) && bufferIndex >= 15)
      00155D 78 88            [12] 4190 	mov	r0,#(_main_buffer_10001_179 + 0x000e)
      00155F E2               [24] 4191 	movx	a,@r0
      001560 FC               [12] 4192 	mov	r4,a
                                   4193 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001561 BC 30 00         [24] 4194 	cjne	r4,#0x30,01490$
      001564                       4195 01490$:
      001564 92 01            [24] 4196 	mov	_main_sloc0_1_0,c
      001566 40 3D            [24] 4197 	jc	00184$
      001568 EC               [12] 4198 	mov	a,r4
      001569 24 C6            [12] 4199 	add	a,#0xff - 0x39
      00156B 92 01            [24] 4200 	mov	_main_sloc0_1_0,c
      00156D 40 36            [24] 4201 	jc	00184$
                                   4202 ;	optimized_main.c:748: if(isdigit(buffer[13]) && isdigit(buffer[14]) && isdigit(buffer[15]) && bufferIndex >= 15)
      00156F 78 89            [12] 4203 	mov	r0,#(_main_buffer_10001_179 + 0x000f)
      001571 E2               [24] 4204 	movx	a,@r0
      001572 FC               [12] 4205 	mov	r4,a
                                   4206 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      001573 BC 30 00         [24] 4207 	cjne	r4,#0x30,01493$
      001576                       4208 01493$:
      001576 92 01            [24] 4209 	mov	_main_sloc0_1_0,c
      001578 40 2B            [24] 4210 	jc	00184$
      00157A EC               [12] 4211 	mov	a,r4
      00157B 24 C6            [12] 4212 	add	a,#0xff - 0x39
      00157D 92 01            [24] 4213 	mov	_main_sloc0_1_0,c
      00157F 40 24            [24] 4214 	jc	00184$
                                   4215 ;	optimized_main.c:748: if(isdigit(buffer[13]) && isdigit(buffer[14]) && isdigit(buffer[15]) && bufferIndex >= 15)
      001581 BE 0F 00         [24] 4216 	cjne	r6,#0x0f,01496$
      001584                       4217 01496$:
      001584 40 1F            [24] 4218 	jc	00184$
                                   4219 ;	optimized_main.c:751: gateway[2] =  ((buffer[13] - '0') * 100) + ((buffer[14] - '0') * 10) + ((buffer[15] - '0'));
      001586 78 87            [12] 4220 	mov	r0,#(_main_buffer_10001_179 + 0x000d)
      001588 E2               [24] 4221 	movx	a,@r0
      001589 24 D0            [12] 4222 	add	a,#0xd0
      00158B 75 F0 64         [24] 4223 	mov	b,#0x64
      00158E A4               [48] 4224 	mul	ab
      00158F FC               [12] 4225 	mov	r4,a
      001590 78 88            [12] 4226 	mov	r0,#(_main_buffer_10001_179 + 0x000e)
      001592 E2               [24] 4227 	movx	a,@r0
      001593 24 D0            [12] 4228 	add	a,#0xd0
      001595 75 F0 0A         [24] 4229 	mov	b,#0x0a
      001598 A4               [48] 4230 	mul	ab
      001599 2C               [12] 4231 	add	a, r4
      00159A FC               [12] 4232 	mov	r4,a
      00159B 78 89            [12] 4233 	mov	r0,#(_main_buffer_10001_179 + 0x000f)
      00159D E2               [24] 4234 	movx	a,@r0
      00159E 24 D0            [12] 4235 	add	a,#0xd0
      0015A0 2C               [12] 4236 	add	a, r4
      0015A1 90 00 A1         [24] 4237 	mov	dptr,#(_main_gateway_10000_178 + 0x0002)
      0015A4 F0               [24] 4238 	movx	@dptr,a
      0015A5                       4239 00184$:
                                   4240 ;	optimized_main.c:754: if(isdigit(buffer[17]) && isdigit(buffer[18]) && isdigit(buffer[19]) && bufferIndex >= 19)
      0015A5 78 8B            [12] 4241 	mov	r0,#(_main_buffer_10001_179 + 0x0011)
      0015A7 E2               [24] 4242 	movx	a,@r0
      0015A8 FC               [12] 4243 	mov	r4,a
                                   4244 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0015A9 BC 30 00         [24] 4245 	cjne	r4,#0x30,01498$
      0015AC                       4246 01498$:
      0015AC 92 01            [24] 4247 	mov	_main_sloc0_1_0,c
      0015AE 40 64            [24] 4248 	jc	00189$
      0015B0 EC               [12] 4249 	mov	a,r4
      0015B1 24 C6            [12] 4250 	add	a,#0xff - 0x39
      0015B3 92 01            [24] 4251 	mov	_main_sloc0_1_0,c
      0015B5 40 5D            [24] 4252 	jc	00189$
                                   4253 ;	optimized_main.c:754: if(isdigit(buffer[17]) && isdigit(buffer[18]) && isdigit(buffer[19]) && bufferIndex >= 19)
      0015B7 78 8C            [12] 4254 	mov	r0,#(_main_buffer_10001_179 + 0x0012)
      0015B9 E2               [24] 4255 	movx	a,@r0
      0015BA FC               [12] 4256 	mov	r4,a
                                   4257 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0015BB BC 30 00         [24] 4258 	cjne	r4,#0x30,01501$
      0015BE                       4259 01501$:
      0015BE 92 01            [24] 4260 	mov	_main_sloc0_1_0,c
      0015C0 40 52            [24] 4261 	jc	00189$
      0015C2 EC               [12] 4262 	mov	a,r4
      0015C3 24 C6            [12] 4263 	add	a,#0xff - 0x39
      0015C5 92 01            [24] 4264 	mov	_main_sloc0_1_0,c
      0015C7 40 4B            [24] 4265 	jc	00189$
                                   4266 ;	optimized_main.c:754: if(isdigit(buffer[17]) && isdigit(buffer[18]) && isdigit(buffer[19]) && bufferIndex >= 19)
      0015C9 78 8D            [12] 4267 	mov	r0,#(_main_buffer_10001_179 + 0x0013)
      0015CB E2               [24] 4268 	movx	a,@r0
      0015CC FC               [12] 4269 	mov	r4,a
                                   4270 ;	c:\program files\sdcc\include\ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
      0015CD BC 30 00         [24] 4271 	cjne	r4,#0x30,01504$
      0015D0                       4272 01504$:
      0015D0 92 01            [24] 4273 	mov	_main_sloc0_1_0,c
      0015D2 40 40            [24] 4274 	jc	00189$
      0015D4 EC               [12] 4275 	mov	a,r4
      0015D5 24 C6            [12] 4276 	add	a,#0xff - 0x39
      0015D7 92 01            [24] 4277 	mov	_main_sloc0_1_0,c
      0015D9 40 39            [24] 4278 	jc	00189$
                                   4279 ;	optimized_main.c:754: if(isdigit(buffer[17]) && isdigit(buffer[18]) && isdigit(buffer[19]) && bufferIndex >= 19)
      0015DB BE 13 00         [24] 4280 	cjne	r6,#0x13,01507$
      0015DE                       4281 01507$:
      0015DE 40 34            [24] 4282 	jc	00189$
                                   4283 ;	optimized_main.c:757: gateway[3] =  ((buffer[17] - '0') * 100) + ((buffer[18] - '0') * 10) + ((buffer[19] - '0'));
      0015E0 78 8B            [12] 4284 	mov	r0,#(_main_buffer_10001_179 + 0x0011)
      0015E2 E2               [24] 4285 	movx	a,@r0
      0015E3 24 D0            [12] 4286 	add	a,#0xd0
      0015E5 75 F0 64         [24] 4287 	mov	b,#0x64
      0015E8 A4               [48] 4288 	mul	ab
      0015E9 FC               [12] 4289 	mov	r4,a
      0015EA 78 8C            [12] 4290 	mov	r0,#(_main_buffer_10001_179 + 0x0012)
      0015EC E2               [24] 4291 	movx	a,@r0
      0015ED 24 D0            [12] 4292 	add	a,#0xd0
      0015EF 75 F0 0A         [24] 4293 	mov	b,#0x0a
      0015F2 A4               [48] 4294 	mul	ab
      0015F3 2C               [12] 4295 	add	a, r4
      0015F4 FC               [12] 4296 	mov	r4,a
      0015F5 78 8D            [12] 4297 	mov	r0,#(_main_buffer_10001_179 + 0x0013)
      0015F7 E2               [24] 4298 	movx	a,@r0
      0015F8 24 D0            [12] 4299 	add	a,#0xd0
      0015FA 2C               [12] 4300 	add	a, r4
      0015FB 90 00 A2         [24] 4301 	mov	dptr,#(_main_gateway_10000_178 + 0x0003)
      0015FE F0               [24] 4302 	movx	@dptr,a
                                   4303 ;	optimized_main.c:758: WIZnet_SetGateway(gateway); 
      0015FF 90 00 9F         [24] 4304 	mov	dptr,#_main_gateway_10000_178
      001602 75 F0 00         [24] 4305 	mov	b, #0x00
      001605 C0 07            [24] 4306 	push	ar7
      001607 C0 06            [24] 4307 	push	ar6
      001609 C0 05            [24] 4308 	push	ar5
      00160B 12 02 39         [24] 4309 	lcall	_WIZnet_SetGateway
      00160E D0 05            [24] 4310 	pop	ar5
      001610 D0 06            [24] 4311 	pop	ar6
      001612 D0 07            [24] 4312 	pop	ar7
      001614                       4313 00189$:
                                   4314 ;	optimized_main.c:761: if(bufferIndex>19)
      001614 EE               [12] 4315 	mov	a,r6
      001615 24 EC            [12] 4316 	add	a,#0xff - 0x13
      001617 40 03            [24] 4317 	jc	01509$
      001619 02 17 84         [24] 4318 	ljmp	00244$
      00161C                       4319 01509$:
                                   4320 ;	optimized_main.c:763: bufferIndex=0;
      00161C 7E 00            [12] 4321 	mov	r6,#0x00
      00161E 02 17 84         [24] 4322 	ljmp	00244$
      001621                       4323 00237$:
                                   4324 ;	optimized_main.c:766: else if(serialInputMode == 4) //MAC address input mode
      001621 BD 04 02         [24] 4325 	cjne	r5,#0x04,01510$
      001624 80 03            [24] 4326 	sjmp	01511$
      001626                       4327 01510$:
      001626 02 17 49         [24] 4328 	ljmp	00234$
      001629                       4329 01511$:
                                   4330 ;	optimized_main.c:769: if(buffer[4] != NULL && buffer[5] != NULL && bufferIndex >= 5) 
      001629 78 7E            [12] 4331 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      00162B E2               [24] 4332 	movx	a,@r0
      00162C FC               [12] 4333 	mov	r4,a
      00162D 60 27            [24] 4334 	jz	00196$
      00162F 78 7F            [12] 4335 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      001631 E2               [24] 4336 	movx	a,@r0
      001632 FB               [12] 4337 	mov	r3,a
      001633 60 21            [24] 4338 	jz	00196$
      001635 BE 05 00         [24] 4339 	cjne	r6,#0x05,01514$
      001638                       4340 01514$:
      001638 40 1C            [24] 4341 	jc	00196$
                                   4342 ;	optimized_main.c:773: mac[0] = combineHexChars(buffer[4],buffer[5]); 
      00163A 78 18            [12] 4343 	mov	r0,#_combineHexChars_PARM_2
      00163C EB               [12] 4344 	mov	a,r3
      00163D F2               [24] 4345 	movx	@r0,a
      00163E 8C 82            [24] 4346 	mov	dpl, r4
      001640 C0 07            [24] 4347 	push	ar7
      001642 C0 06            [24] 4348 	push	ar6
      001644 C0 05            [24] 4349 	push	ar5
      001646 12 00 AC         [24] 4350 	lcall	_combineHexChars
      001649 AC 82            [24] 4351 	mov	r4, dpl
      00164B D0 05            [24] 4352 	pop	ar5
      00164D D0 06            [24] 4353 	pop	ar6
      00164F D0 07            [24] 4354 	pop	ar7
      001651 90 00 95         [24] 4355 	mov	dptr,#_main_mac_10000_178
      001654 EC               [12] 4356 	mov	a,r4
      001655 F0               [24] 4357 	movx	@dptr,a
      001656                       4358 00196$:
                                   4359 ;	optimized_main.c:776: if(buffer[6] != NULL && buffer[7] != NULL && bufferIndex >= 7) 
      001656 78 80            [12] 4360 	mov	r0,#(_main_buffer_10001_179 + 0x0006)
      001658 E2               [24] 4361 	movx	a,@r0
      001659 FC               [12] 4362 	mov	r4,a
      00165A 60 27            [24] 4363 	jz	00200$
      00165C 78 81            [12] 4364 	mov	r0,#(_main_buffer_10001_179 + 0x0007)
      00165E E2               [24] 4365 	movx	a,@r0
      00165F FB               [12] 4366 	mov	r3,a
      001660 60 21            [24] 4367 	jz	00200$
      001662 BE 07 00         [24] 4368 	cjne	r6,#0x07,01518$
      001665                       4369 01518$:
      001665 40 1C            [24] 4370 	jc	00200$
                                   4371 ;	optimized_main.c:780: mac[1] = combineHexChars(buffer[6],buffer[7]); 
      001667 78 18            [12] 4372 	mov	r0,#_combineHexChars_PARM_2
      001669 EB               [12] 4373 	mov	a,r3
      00166A F2               [24] 4374 	movx	@r0,a
      00166B 8C 82            [24] 4375 	mov	dpl, r4
      00166D C0 07            [24] 4376 	push	ar7
      00166F C0 06            [24] 4377 	push	ar6
      001671 C0 05            [24] 4378 	push	ar5
      001673 12 00 AC         [24] 4379 	lcall	_combineHexChars
      001676 AC 82            [24] 4380 	mov	r4, dpl
      001678 D0 05            [24] 4381 	pop	ar5
      00167A D0 06            [24] 4382 	pop	ar6
      00167C D0 07            [24] 4383 	pop	ar7
      00167E 90 00 96         [24] 4384 	mov	dptr,#(_main_mac_10000_178 + 0x0001)
      001681 EC               [12] 4385 	mov	a,r4
      001682 F0               [24] 4386 	movx	@dptr,a
      001683                       4387 00200$:
                                   4388 ;	optimized_main.c:784: if(buffer[8] != NULL && buffer[9] != NULL && bufferIndex >= 9) 
      001683 78 82            [12] 4389 	mov	r0,#(_main_buffer_10001_179 + 0x0008)
      001685 E2               [24] 4390 	movx	a,@r0
      001686 FC               [12] 4391 	mov	r4,a
      001687 60 27            [24] 4392 	jz	00204$
      001689 78 83            [12] 4393 	mov	r0,#(_main_buffer_10001_179 + 0x0009)
      00168B E2               [24] 4394 	movx	a,@r0
      00168C FB               [12] 4395 	mov	r3,a
      00168D 60 21            [24] 4396 	jz	00204$
      00168F BE 09 00         [24] 4397 	cjne	r6,#0x09,01522$
      001692                       4398 01522$:
      001692 40 1C            [24] 4399 	jc	00204$
                                   4400 ;	optimized_main.c:788: mac[2] = combineHexChars(buffer[8],buffer[9]); 
      001694 78 18            [12] 4401 	mov	r0,#_combineHexChars_PARM_2
      001696 EB               [12] 4402 	mov	a,r3
      001697 F2               [24] 4403 	movx	@r0,a
      001698 8C 82            [24] 4404 	mov	dpl, r4
      00169A C0 07            [24] 4405 	push	ar7
      00169C C0 06            [24] 4406 	push	ar6
      00169E C0 05            [24] 4407 	push	ar5
      0016A0 12 00 AC         [24] 4408 	lcall	_combineHexChars
      0016A3 AC 82            [24] 4409 	mov	r4, dpl
      0016A5 D0 05            [24] 4410 	pop	ar5
      0016A7 D0 06            [24] 4411 	pop	ar6
      0016A9 D0 07            [24] 4412 	pop	ar7
      0016AB 90 00 97         [24] 4413 	mov	dptr,#(_main_mac_10000_178 + 0x0002)
      0016AE EC               [12] 4414 	mov	a,r4
      0016AF F0               [24] 4415 	movx	@dptr,a
      0016B0                       4416 00204$:
                                   4417 ;	optimized_main.c:792: if(buffer[10] != NULL && buffer[11] != NULL && bufferIndex >= 11) 
      0016B0 78 84            [12] 4418 	mov	r0,#(_main_buffer_10001_179 + 0x000a)
      0016B2 E2               [24] 4419 	movx	a,@r0
      0016B3 FC               [12] 4420 	mov	r4,a
      0016B4 60 27            [24] 4421 	jz	00208$
      0016B6 78 85            [12] 4422 	mov	r0,#(_main_buffer_10001_179 + 0x000b)
      0016B8 E2               [24] 4423 	movx	a,@r0
      0016B9 FB               [12] 4424 	mov	r3,a
      0016BA 60 21            [24] 4425 	jz	00208$
      0016BC BE 0B 00         [24] 4426 	cjne	r6,#0x0b,01526$
      0016BF                       4427 01526$:
      0016BF 40 1C            [24] 4428 	jc	00208$
                                   4429 ;	optimized_main.c:796: mac[3] = combineHexChars(buffer[10],buffer[11]); 
      0016C1 78 18            [12] 4430 	mov	r0,#_combineHexChars_PARM_2
      0016C3 EB               [12] 4431 	mov	a,r3
      0016C4 F2               [24] 4432 	movx	@r0,a
      0016C5 8C 82            [24] 4433 	mov	dpl, r4
      0016C7 C0 07            [24] 4434 	push	ar7
      0016C9 C0 06            [24] 4435 	push	ar6
      0016CB C0 05            [24] 4436 	push	ar5
      0016CD 12 00 AC         [24] 4437 	lcall	_combineHexChars
      0016D0 AC 82            [24] 4438 	mov	r4, dpl
      0016D2 D0 05            [24] 4439 	pop	ar5
      0016D4 D0 06            [24] 4440 	pop	ar6
      0016D6 D0 07            [24] 4441 	pop	ar7
      0016D8 90 00 98         [24] 4442 	mov	dptr,#(_main_mac_10000_178 + 0x0003)
      0016DB EC               [12] 4443 	mov	a,r4
      0016DC F0               [24] 4444 	movx	@dptr,a
      0016DD                       4445 00208$:
                                   4446 ;	optimized_main.c:800: if(buffer[12] != NULL && buffer[13] != NULL && bufferIndex >= 13) 
      0016DD 78 86            [12] 4447 	mov	r0,#(_main_buffer_10001_179 + 0x000c)
      0016DF E2               [24] 4448 	movx	a,@r0
      0016E0 FC               [12] 4449 	mov	r4,a
      0016E1 60 27            [24] 4450 	jz	00212$
      0016E3 78 87            [12] 4451 	mov	r0,#(_main_buffer_10001_179 + 0x000d)
      0016E5 E2               [24] 4452 	movx	a,@r0
      0016E6 FB               [12] 4453 	mov	r3,a
      0016E7 60 21            [24] 4454 	jz	00212$
      0016E9 BE 0D 00         [24] 4455 	cjne	r6,#0x0d,01530$
      0016EC                       4456 01530$:
      0016EC 40 1C            [24] 4457 	jc	00212$
                                   4458 ;	optimized_main.c:803: mac[4] = combineHexChars(buffer[12],buffer[13]); 
      0016EE 78 18            [12] 4459 	mov	r0,#_combineHexChars_PARM_2
      0016F0 EB               [12] 4460 	mov	a,r3
      0016F1 F2               [24] 4461 	movx	@r0,a
      0016F2 8C 82            [24] 4462 	mov	dpl, r4
      0016F4 C0 07            [24] 4463 	push	ar7
      0016F6 C0 06            [24] 4464 	push	ar6
      0016F8 C0 05            [24] 4465 	push	ar5
      0016FA 12 00 AC         [24] 4466 	lcall	_combineHexChars
      0016FD AC 82            [24] 4467 	mov	r4, dpl
      0016FF D0 05            [24] 4468 	pop	ar5
      001701 D0 06            [24] 4469 	pop	ar6
      001703 D0 07            [24] 4470 	pop	ar7
      001705 90 00 99         [24] 4471 	mov	dptr,#(_main_mac_10000_178 + 0x0004)
      001708 EC               [12] 4472 	mov	a,r4
      001709 F0               [24] 4473 	movx	@dptr,a
      00170A                       4474 00212$:
                                   4475 ;	optimized_main.c:807: if(buffer[14] != NULL && buffer[15] != NULL && bufferIndex >= 15) 
      00170A 78 88            [12] 4476 	mov	r0,#(_main_buffer_10001_179 + 0x000e)
      00170C E2               [24] 4477 	movx	a,@r0
      00170D FC               [12] 4478 	mov	r4,a
      00170E 60 30            [24] 4479 	jz	00216$
      001710 78 89            [12] 4480 	mov	r0,#(_main_buffer_10001_179 + 0x000f)
      001712 E2               [24] 4481 	movx	a,@r0
      001713 FB               [12] 4482 	mov	r3,a
      001714 60 2A            [24] 4483 	jz	00216$
      001716 BE 0F 00         [24] 4484 	cjne	r6,#0x0f,01534$
      001719                       4485 01534$:
      001719 40 25            [24] 4486 	jc	00216$
                                   4487 ;	optimized_main.c:810: mac[5] = combineHexChars(buffer[14],buffer[15]); 
      00171B 78 18            [12] 4488 	mov	r0,#_combineHexChars_PARM_2
      00171D EB               [12] 4489 	mov	a,r3
      00171E F2               [24] 4490 	movx	@r0,a
      00171F 8C 82            [24] 4491 	mov	dpl, r4
      001721 C0 07            [24] 4492 	push	ar7
      001723 C0 06            [24] 4493 	push	ar6
      001725 C0 05            [24] 4494 	push	ar5
      001727 12 00 AC         [24] 4495 	lcall	_combineHexChars
      00172A AC 82            [24] 4496 	mov	r4, dpl
      00172C 90 00 9A         [24] 4497 	mov	dptr,#(_main_mac_10000_178 + 0x0005)
      00172F EC               [12] 4498 	mov	a,r4
      001730 F0               [24] 4499 	movx	@dptr,a
                                   4500 ;	optimized_main.c:811: WIZnet_SetMAC(mac);
      001731 90 00 95         [24] 4501 	mov	dptr,#_main_mac_10000_178
      001734 75 F0 00         [24] 4502 	mov	b, #0x00
      001737 12 01 A5         [24] 4503 	lcall	_WIZnet_SetMAC
      00173A D0 05            [24] 4504 	pop	ar5
      00173C D0 06            [24] 4505 	pop	ar6
      00173E D0 07            [24] 4506 	pop	ar7
      001740                       4507 00216$:
                                   4508 ;	optimized_main.c:815: if(bufferIndex>15)
      001740 EE               [12] 4509 	mov	a,r6
      001741 24 F0            [12] 4510 	add	a,#0xff - 0x0f
      001743 50 3F            [24] 4511 	jnc	00244$
                                   4512 ;	optimized_main.c:817: bufferIndex=0;
      001745 7E 00            [12] 4513 	mov	r6,#0x00
      001747 80 3B            [24] 4514 	sjmp	00244$
      001749                       4515 00234$:
                                   4516 ;	optimized_main.c:821: else if(serialInputMode == 5) //MODE address input mode
      001749 BD 05 38         [24] 4517 	cjne	r5,#0x05,00244$
                                   4518 ;	optimized_main.c:824: if(buffer[5] == 'U' && buffer[6] == 'D' && buffer[7] == 'P' && bufferIndex >= 7)
      00174C 78 7F            [12] 4519 	mov	r0,#(_main_buffer_10001_179 + 0x0005)
      00174E E2               [24] 4520 	movx	a,@r0
      00174F FC               [12] 4521 	mov	r4,a
      001750 BC 55 17         [24] 4522 	cjne	r4,#0x55,00222$
      001753 78 80            [12] 4523 	mov	r0,#(_main_buffer_10001_179 + 0x0006)
      001755 E2               [24] 4524 	movx	a,@r0
      001756 FB               [12] 4525 	mov	r3,a
      001757 BB 44 10         [24] 4526 	cjne	r3,#0x44,00222$
      00175A 78 81            [12] 4527 	mov	r0,#(_main_buffer_10001_179 + 0x0007)
      00175C E2               [24] 4528 	movx	a,@r0
      00175D FB               [12] 4529 	mov	r3,a
      00175E BB 50 09         [24] 4530 	cjne	r3,#0x50,00222$
      001761 BE 07 00         [24] 4531 	cjne	r6,#0x07,01545$
      001764                       4532 01545$:
      001764 40 04            [24] 4533 	jc	00222$
                                   4534 ;	optimized_main.c:827: mode = 0;
      001766 7F 00            [12] 4535 	mov	r7,#0x00
                                   4536 ;	optimized_main.c:828: bufferIndex = 0; // Reset the buffer index
      001768 7E 00            [12] 4537 	mov	r6,#0x00
      00176A                       4538 00222$:
                                   4539 ;	optimized_main.c:832: if(buffer[5] == 'T' && buffer[6] == 'C' && buffer[7] == 'P' && bufferIndex >= 7) 
      00176A BC 54 17         [24] 4540 	cjne	r4,#0x54,00244$
      00176D 78 80            [12] 4541 	mov	r0,#(_main_buffer_10001_179 + 0x0006)
      00176F E2               [24] 4542 	movx	a,@r0
      001770 FC               [12] 4543 	mov	r4,a
      001771 BC 43 10         [24] 4544 	cjne	r4,#0x43,00244$
      001774 78 81            [12] 4545 	mov	r0,#(_main_buffer_10001_179 + 0x0007)
      001776 E2               [24] 4546 	movx	a,@r0
      001777 FC               [12] 4547 	mov	r4,a
      001778 BC 50 09         [24] 4548 	cjne	r4,#0x50,00244$
      00177B BE 07 00         [24] 4549 	cjne	r6,#0x07,01553$
      00177E                       4550 01553$:
      00177E 40 04            [24] 4551 	jc	00244$
                                   4552 ;	optimized_main.c:835: mode = 1;
      001780 7F 01            [12] 4553 	mov	r7,#0x01
                                   4554 ;	optimized_main.c:836: bufferIndex = 0; // Reset the buffer index
      001782 7E 00            [12] 4555 	mov	r6,#0x00
      001784                       4556 00244$:
                                   4557 ;	optimized_main.c:843: if(buffer[0] == 'R' && buffer[1] == 'T' && buffer[2] == 'U' && buffer[3] == '=' && buffer[4] != NULL) 
      001784 78 7A            [12] 4558 	mov	r0,#_main_buffer_10001_179
      001786 E2               [24] 4559 	movx	a,@r0
      001787 FC               [12] 4560 	mov	r4,a
      001788 BC 52 24         [24] 4561 	cjne	r4,#0x52,00276$
      00178B 78 7B            [12] 4562 	mov	r0,#(_main_buffer_10001_179 + 0x0001)
      00178D E2               [24] 4563 	movx	a,@r0
      00178E FC               [12] 4564 	mov	r4,a
      00178F BC 54 1D         [24] 4565 	cjne	r4,#0x54,00276$
      001792 78 7C            [12] 4566 	mov	r0,#(_main_buffer_10001_179 + 0x0002)
      001794 E2               [24] 4567 	movx	a,@r0
      001795 FC               [12] 4568 	mov	r4,a
      001796 BC 55 16         [24] 4569 	cjne	r4,#0x55,00276$
      001799 78 7D            [12] 4570 	mov	r0,#(_main_buffer_10001_179 + 0x0003)
      00179B E2               [24] 4571 	movx	a,@r0
      00179C FC               [12] 4572 	mov	r4,a
      00179D BC 3D 0F         [24] 4573 	cjne	r4,#0x3d,00276$
      0017A0 78 7E            [12] 4574 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      0017A2 E2               [24] 4575 	movx	a,@r0
      0017A3 FC               [12] 4576 	mov	r4,a
      0017A4 60 09            [24] 4577 	jz	00276$
                                   4578 ;	optimized_main.c:846: rtu = buffer[4]-'0';
      0017A6 78 17            [12] 4579 	mov	r0,#_rtu
      0017A8 EC               [12] 4580 	mov	a,r4
      0017A9 24 D0            [12] 4581 	add	a,#0xd0
      0017AB F2               [24] 4582 	movx	@r0,a
      0017AC 02 0D E9         [24] 4583 	ljmp	00283$
      0017AF                       4584 00276$:
                                   4585 ;	optimized_main.c:849: else if(buffer[0] == 'I' && buffer[1] == 'P' && buffer[2] == '=') 
      0017AF 78 7A            [12] 4586 	mov	r0,#_main_buffer_10001_179
      0017B1 E2               [24] 4587 	movx	a,@r0
      0017B2 FC               [12] 4588 	mov	r4,a
      0017B3 BC 49 13         [24] 4589 	cjne	r4,#0x49,00271$
      0017B6 78 7B            [12] 4590 	mov	r0,#(_main_buffer_10001_179 + 0x0001)
      0017B8 E2               [24] 4591 	movx	a,@r0
      0017B9 FB               [12] 4592 	mov	r3,a
      0017BA BB 50 0C         [24] 4593 	cjne	r3,#0x50,00271$
      0017BD 78 7C            [12] 4594 	mov	r0,#(_main_buffer_10001_179 + 0x0002)
      0017BF E2               [24] 4595 	movx	a,@r0
      0017C0 FB               [12] 4596 	mov	r3,a
      0017C1 BB 3D 05         [24] 4597 	cjne	r3,#0x3d,00271$
                                   4598 ;	optimized_main.c:852: serialInputMode = 1; // Set the mode to IP address input
      0017C4 7D 01            [12] 4599 	mov	r5,#0x01
      0017C6 02 0D E9         [24] 4600 	ljmp	00283$
      0017C9                       4601 00271$:
                                   4602 ;	optimized_main.c:855: else if(buffer[0] == 'S' && buffer[1] == 'U' && buffer[2] == 'B' && buffer[3] == '=') 
      0017C9 BC 53 1A         [24] 4603 	cjne	r4,#0x53,00265$
      0017CC 78 7B            [12] 4604 	mov	r0,#(_main_buffer_10001_179 + 0x0001)
      0017CE E2               [24] 4605 	movx	a,@r0
      0017CF FB               [12] 4606 	mov	r3,a
      0017D0 BB 55 13         [24] 4607 	cjne	r3,#0x55,00265$
      0017D3 78 7C            [12] 4608 	mov	r0,#(_main_buffer_10001_179 + 0x0002)
      0017D5 E2               [24] 4609 	movx	a,@r0
      0017D6 FB               [12] 4610 	mov	r3,a
      0017D7 BB 42 0C         [24] 4611 	cjne	r3,#0x42,00265$
      0017DA 78 7D            [12] 4612 	mov	r0,#(_main_buffer_10001_179 + 0x0003)
      0017DC E2               [24] 4613 	movx	a,@r0
      0017DD FB               [12] 4614 	mov	r3,a
      0017DE BB 3D 05         [24] 4615 	cjne	r3,#0x3d,00265$
                                   4616 ;	optimized_main.c:858: serialInputMode = 2; // Set the mode to subnet mask input
      0017E1 7D 02            [12] 4617 	mov	r5,#0x02
      0017E3 02 0D E9         [24] 4618 	ljmp	00283$
      0017E6                       4619 00265$:
                                   4620 ;	optimized_main.c:861: else if(buffer[0] == 'G' && buffer[1] == 'A' && buffer[2] == 'T' && buffer[3] == 'E' && buffer[4] == '=') 
      0017E6 BC 47 21         [24] 4621 	cjne	r4,#0x47,00258$
      0017E9 78 7B            [12] 4622 	mov	r0,#(_main_buffer_10001_179 + 0x0001)
      0017EB E2               [24] 4623 	movx	a,@r0
      0017EC FB               [12] 4624 	mov	r3,a
      0017ED BB 41 1A         [24] 4625 	cjne	r3,#0x41,00258$
      0017F0 78 7C            [12] 4626 	mov	r0,#(_main_buffer_10001_179 + 0x0002)
      0017F2 E2               [24] 4627 	movx	a,@r0
      0017F3 FB               [12] 4628 	mov	r3,a
      0017F4 BB 54 13         [24] 4629 	cjne	r3,#0x54,00258$
      0017F7 78 7D            [12] 4630 	mov	r0,#(_main_buffer_10001_179 + 0x0003)
      0017F9 E2               [24] 4631 	movx	a,@r0
      0017FA FB               [12] 4632 	mov	r3,a
      0017FB BB 45 0C         [24] 4633 	cjne	r3,#0x45,00258$
      0017FE 78 7E            [12] 4634 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      001800 E2               [24] 4635 	movx	a,@r0
      001801 FB               [12] 4636 	mov	r3,a
      001802 BB 3D 05         [24] 4637 	cjne	r3,#0x3d,00258$
                                   4638 ;	optimized_main.c:864: serialInputMode = 3; // Set the mode to subnet mask input
      001805 7D 03            [12] 4639 	mov	r5,#0x03
      001807 02 0D E9         [24] 4640 	ljmp	00283$
      00180A                       4641 00258$:
                                   4642 ;	optimized_main.c:867: else if(buffer[0] == 'M' && buffer[1] == 'A' && buffer[2] == 'C' && buffer[3] == '=') 
      00180A E4               [12] 4643 	clr	a
      00180B BC 4D 01         [24] 4644 	cjne	r4,#0x4d,01588$
      00180E 04               [12] 4645 	inc	a
      00180F                       4646 01588$:
      00180F FC               [12] 4647 	mov	r4,a
      001810 60 1A            [24] 4648 	jz	00252$
      001812 78 7B            [12] 4649 	mov	r0,#(_main_buffer_10001_179 + 0x0001)
      001814 E2               [24] 4650 	movx	a,@r0
      001815 FB               [12] 4651 	mov	r3,a
      001816 BB 41 13         [24] 4652 	cjne	r3,#0x41,00252$
      001819 78 7C            [12] 4653 	mov	r0,#(_main_buffer_10001_179 + 0x0002)
      00181B E2               [24] 4654 	movx	a,@r0
      00181C FB               [12] 4655 	mov	r3,a
      00181D BB 43 0C         [24] 4656 	cjne	r3,#0x43,00252$
      001820 78 7D            [12] 4657 	mov	r0,#(_main_buffer_10001_179 + 0x0003)
      001822 E2               [24] 4658 	movx	a,@r0
      001823 FB               [12] 4659 	mov	r3,a
      001824 BB 3D 05         [24] 4660 	cjne	r3,#0x3d,00252$
                                   4661 ;	optimized_main.c:870: serialInputMode = 4; // Set the mode to subnet mask input
      001827 7D 04            [12] 4662 	mov	r5,#0x04
      001829 02 0D E9         [24] 4663 	ljmp	00283$
      00182C                       4664 00252$:
                                   4665 ;	optimized_main.c:873: else if(buffer[0] == 'M' && buffer[1] == 'O' && buffer[2] == 'D' && buffer[3] == 'E' && buffer[4] == '=') 
      00182C EC               [12] 4666 	mov	a,r4
      00182D 70 03            [24] 4667 	jnz	01597$
      00182F 02 0D E9         [24] 4668 	ljmp	00283$
      001832                       4669 01597$:
      001832 78 7B            [12] 4670 	mov	r0,#(_main_buffer_10001_179 + 0x0001)
      001834 E2               [24] 4671 	movx	a,@r0
      001835 FC               [12] 4672 	mov	r4,a
      001836 BC 4F 02         [24] 4673 	cjne	r4,#0x4f,01598$
      001839 80 03            [24] 4674 	sjmp	01599$
      00183B                       4675 01598$:
      00183B 02 0D E9         [24] 4676 	ljmp	00283$
      00183E                       4677 01599$:
      00183E 78 7C            [12] 4678 	mov	r0,#(_main_buffer_10001_179 + 0x0002)
      001840 E2               [24] 4679 	movx	a,@r0
      001841 FC               [12] 4680 	mov	r4,a
      001842 BC 44 02         [24] 4681 	cjne	r4,#0x44,01600$
      001845 80 03            [24] 4682 	sjmp	01601$
      001847                       4683 01600$:
      001847 02 0D E9         [24] 4684 	ljmp	00283$
      00184A                       4685 01601$:
      00184A 78 7D            [12] 4686 	mov	r0,#(_main_buffer_10001_179 + 0x0003)
      00184C E2               [24] 4687 	movx	a,@r0
      00184D FC               [12] 4688 	mov	r4,a
      00184E BC 45 02         [24] 4689 	cjne	r4,#0x45,01602$
      001851 80 03            [24] 4690 	sjmp	01603$
      001853                       4691 01602$:
      001853 02 0D E9         [24] 4692 	ljmp	00283$
      001856                       4693 01603$:
      001856 78 7E            [12] 4694 	mov	r0,#(_main_buffer_10001_179 + 0x0004)
      001858 E2               [24] 4695 	movx	a,@r0
      001859 FC               [12] 4696 	mov	r4,a
      00185A BC 3D 02         [24] 4697 	cjne	r4,#0x3d,01604$
      00185D 80 03            [24] 4698 	sjmp	01605$
      00185F                       4699 01604$:
      00185F 02 0D E9         [24] 4700 	ljmp	00283$
      001862                       4701 01605$:
                                   4702 ;	optimized_main.c:876: serialInputMode = 5; // Set the mode to subnet mask input
      001862 7D 05            [12] 4703 	mov	r5,#0x05
                                   4704 ;	optimized_main.c:884: }
      001864 02 0D E9         [24] 4705 	ljmp	00283$
                                   4706 ;------------------------------------------------------------
                                   4707 ;Allocation info for local variables in function 'delay'
                                   4708 ;------------------------------------------------------------
                                   4709 ;	optimized_main.c:886: void delay(unsigned int milliseconds)
                                   4710 ;	-----------------------------------------
                                   4711 ;	 function delay
                                   4712 ;	-----------------------------------------
      001867                       4713 _delay:
      001867 AE 82            [24] 4714 	mov	r6, dpl
      001869 AF 83            [24] 4715 	mov	r7, dph
                                   4716 ;	optimized_main.c:889: while (milliseconds > 0) {
      00186B                       4717 00104$:
      00186B EE               [12] 4718 	mov	a,r6
      00186C 4F               [12] 4719 	orl	a,r7
      00186D 60 16            [24] 4720 	jz	00107$
                                   4721 ;	optimized_main.c:891: while (count > 0) {
      00186F 7C E8            [12] 4722 	mov	r4,#0xe8
      001871 7D 03            [12] 4723 	mov	r5,#0x03
      001873                       4724 00101$:
      001873 EC               [12] 4725 	mov	a,r4
      001874 4D               [12] 4726 	orl	a,r5
      001875 60 07            [24] 4727 	jz	00103$
                                   4728 ;	optimized_main.c:892: count--;
      001877 1C               [12] 4729 	dec	r4
      001878 BC FF 01         [24] 4730 	cjne	r4,#0xff,00137$
      00187B 1D               [12] 4731 	dec	r5
      00187C                       4732 00137$:
      00187C 80 F5            [24] 4733 	sjmp	00101$
      00187E                       4734 00103$:
                                   4735 ;	optimized_main.c:894: milliseconds--;
      00187E 1E               [12] 4736 	dec	r6
      00187F BE FF 01         [24] 4737 	cjne	r6,#0xff,00138$
      001882 1F               [12] 4738 	dec	r7
      001883                       4739 00138$:
      001883 80 E6            [24] 4740 	sjmp	00104$
      001885                       4741 00107$:
                                   4742 ;	optimized_main.c:896: }
      001885 22               [24] 4743 	ret
                                   4744 	.area CSEG    (CODE)
                                   4745 	.area CONST   (CODE)
                                   4746 	.area CONST   (CODE)
      001B32                       4747 _main_STR_CURRENT_CONFIG_10000_178:
      001B32 43 55 52 52 45 4E 54  4748 	.ascii "CURRENT CONFIG: "
             20 43 4F 4E 46 49 47
             3A 20
      001B42 00                    4749 	.db 0x00
                                   4750 	.area CSEG    (CODE)
                                   4751 	.area CONST   (CODE)
      001B43                       4752 _main_STR_RTU_10000_178:
      001B43 52 54 55 20 41 64 64  4753 	.ascii "RTU Addr (0-9): "
             72 20 28 30 2D 39 29
             3A 20
      001B53 00                    4754 	.db 0x00
                                   4755 	.area CSEG    (CODE)
                                   4756 	.area CONST   (CODE)
      001B54                       4757 _main_STR_IP_10000_178:
      001B54 49 50 20 41 64 64 72  4758 	.ascii "IP Addr: "
             3A 20
      001B5D 00                    4759 	.db 0x00
                                   4760 	.area CSEG    (CODE)
                                   4761 	.area CONST   (CODE)
      001B5E                       4762 _main_STR_SUBNET_10000_178:
      001B5E 53 75 62 6E 65 74 20  4763 	.ascii "Subnet Mask: "
             4D 61 73 6B 3A 20
      001B6B 00                    4764 	.db 0x00
                                   4765 	.area CSEG    (CODE)
                                   4766 	.area CONST   (CODE)
      001B6C                       4767 _main_STR_GATE_10000_178:
      001B6C 47 61 74 65 77 61 79  4768 	.ascii "Gateway: "
             3A 20
      001B75 00                    4769 	.db 0x00
                                   4770 	.area CSEG    (CODE)
                                   4771 	.area CONST   (CODE)
      001B76                       4772 _main_STR_MAC_10000_178:
      001B76 4D 41 43 20 41 64 64  4773 	.ascii "MAC Addr: "
             72 3A 20
      001B80 00                    4774 	.db 0x00
                                   4775 	.area CSEG    (CODE)
                                   4776 	.area CONST   (CODE)
      001B81                       4777 _main_STR_MODE_10000_178:
      001B81 4D 6F 64 65 3A 20     4778 	.ascii "Mode: "
      001B87 00                    4779 	.db 0x00
                                   4780 	.area CSEG    (CODE)
                                   4781 	.area CONST   (CODE)
      001B88                       4782 _main_STR_UDP_10000_178:
      001B88 55 44 50              4783 	.ascii "UDP"
      001B8B 00                    4784 	.db 0x00
                                   4785 	.area CSEG    (CODE)
                                   4786 	.area CONST   (CODE)
      001B8C                       4787 _main_STR_TCP_10000_178:
      001B8C 54 43 50              4788 	.ascii "TCP"
      001B8F 00                    4789 	.db 0x00
                                   4790 	.area CSEG    (CODE)
                                   4791 	.area CONST   (CODE)
      001B90                       4792 _main_STR_CMD_10000_178:
      001B90 43 48 41 4E 47 45 20  4793 	.ascii "CHANGE CMD:"
             43 4D 44 3A
      001B9B 00                    4794 	.db 0x00
                                   4795 	.area CSEG    (CODE)
                                   4796 	.area CONST   (CODE)
      001B9C                       4797 _main_STR_RTU_FORMAT_10000_178:
      001B9C 52 54 55 3D 23        4798 	.ascii "RTU=#"
      001BA1 00                    4799 	.db 0x00
                                   4800 	.area CSEG    (CODE)
                                   4801 	.area CONST   (CODE)
      001BA2                       4802 _main_STR_IP_FORMAT_10000_178:
      001BA2 49 50 3D 23 23 23 2E  4803 	.ascii "IP=###.###.###.###"
             23 23 23 2E 23 23 23
             2E 23 23 23
      001BB4 00                    4804 	.db 0x00
                                   4805 	.area CSEG    (CODE)
                                   4806 	.area CONST   (CODE)
      001BB5                       4807 _main_STR_SUB_FORMAT_10000_178:
      001BB5 53 55 42 3D 23 23 23  4808 	.ascii "SUB=###.###.###.###"
             2E 23 23 23 2E 23 23
             23 2E 23 23 23
      001BC8 00                    4809 	.db 0x00
                                   4810 	.area CSEG    (CODE)
                                   4811 	.area CONST   (CODE)
      001BC9                       4812 _main_STR_GATE_FORMAT_10000_178:
      001BC9 47 41 54 45 3D 23 23  4813 	.ascii "GATE=###.###.###.###"
             23 2E 23 23 23 2E 23
             23 23 2E 23 23 23
      001BDD 00                    4814 	.db 0x00
                                   4815 	.area CSEG    (CODE)
                                   4816 	.area CONST   (CODE)
      001BDE                       4817 _main_STR_MAC_FORMAT_10000_178:
      001BDE 4D 41 43 3D 46 46 20  4818 	.ascii "MAC=FF FF FF FF FF FF"
             46 46 20 46 46 20 46
             46 20 46 46 20 46 46
      001BF3 00                    4819 	.db 0x00
                                   4820 	.area CSEG    (CODE)
                                   4821 	.area CONST   (CODE)
      001BF4                       4822 _main_STR_MODE_FORMAT_10000_178:
      001BF4 4D 4F 44 45 3D 55 44  4823 	.ascii "MODE=UDP/TCP"
             50 2F 54 43 50
      001C00 00                    4824 	.db 0x00
                                   4825 	.area CSEG    (CODE)
                                   4826 	.area XINIT   (CODE)
                                   4827 	.area CABS    (ABS,CODE)
