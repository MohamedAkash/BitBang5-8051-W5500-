#include <8051.h>
#include "optimized_main.h"

// SPI OPTImIZED FUNCTIONS - Nothing else to do

/**
 * @brief Initialize SPI pins
 * @details Sets MOSI and SCK as outputs, MISO as input, and SS as output (active low)
 * @author MohamedAkash
 * @date 2025-05-07 15:24:15
 */
void SPI_Init(void) {
    MOSI = 0;    // MOSI: output, initial low
    MISO = 1;    // MISO: input
    SCK = 0;     // SCK: output, initial low
    SS = 1;      // SS: output, inactive high
}

/**
 * @brief Write a byte via SPI
 * @param data Byte to transmit
 */
void SPI_Write(unsigned char data) {
    register unsigned char i = 8;    // Use register to reduce memory usage
    
    do {
        MOSI = (data & 0x80) ? 1 : 0;  // Send MSB first
        data <<= 1;                     // Shift data left
        SCK = 1;                        // Generate clock pulse
        SCK = 0;
    } while (--i);                      // More efficient than for loop
}

/**
 * @brief Write a 16-bit value via SPI
 * @param data 16-bit value to transmit
 */
void SPI_WriteShort(unsigned short data) {
    // Split into two byte writes to reuse code and save memory
    SPI_Write(data >> 8);     // Send high byte
    SPI_Write(data & 0xFF);   // Send low byte
}

/**
 * @brief Read a byte via SPI
 * @return Byte received via SPI
 */
unsigned char SPI_Read(void) {
    register unsigned char i = 8;    // Use register for counter
    register unsigned char data = 0;  // Use register for data
    
    do {
        data <<= 1;           // Shift data left
        SCK = 1;             // Generate clock pulse
        if (MISO) {          // Read MISO
            data |= 1;       // Set LSB if MISO is high
        }
        SCK = 0;
    } while (--i);           // More efficient than for loop
    
    return data;
}