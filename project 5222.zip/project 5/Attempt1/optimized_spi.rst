                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module optimized_spi
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-medium
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _CY
                                     12 	.globl _AC
                                     13 	.globl _F0
                                     14 	.globl _RS1
                                     15 	.globl _RS0
                                     16 	.globl _OV
                                     17 	.globl _F1
                                     18 	.globl _P
                                     19 	.globl _PS
                                     20 	.globl _PT1
                                     21 	.globl _PX1
                                     22 	.globl _PT0
                                     23 	.globl _PX0
                                     24 	.globl _RD
                                     25 	.globl _WR
                                     26 	.globl _T1
                                     27 	.globl _T0
                                     28 	.globl _INT1
                                     29 	.globl _INT0
                                     30 	.globl _TXD
                                     31 	.globl _RXD
                                     32 	.globl _P3_7
                                     33 	.globl _P3_6
                                     34 	.globl _P3_5
                                     35 	.globl _P3_4
                                     36 	.globl _P3_3
                                     37 	.globl _P3_2
                                     38 	.globl _P3_1
                                     39 	.globl _P3_0
                                     40 	.globl _EA
                                     41 	.globl _ES
                                     42 	.globl _ET1
                                     43 	.globl _EX1
                                     44 	.globl _ET0
                                     45 	.globl _EX0
                                     46 	.globl _P2_7
                                     47 	.globl _P2_6
                                     48 	.globl _P2_5
                                     49 	.globl _P2_4
                                     50 	.globl _P2_3
                                     51 	.globl _P2_2
                                     52 	.globl _P2_1
                                     53 	.globl _P2_0
                                     54 	.globl _SM0
                                     55 	.globl _SM1
                                     56 	.globl _SM2
                                     57 	.globl _REN
                                     58 	.globl _TB8
                                     59 	.globl _RB8
                                     60 	.globl _TI
                                     61 	.globl _RI
                                     62 	.globl _P1_7
                                     63 	.globl _P1_6
                                     64 	.globl _P1_5
                                     65 	.globl _P1_4
                                     66 	.globl _P1_3
                                     67 	.globl _P1_2
                                     68 	.globl _P1_1
                                     69 	.globl _P1_0
                                     70 	.globl _TF1
                                     71 	.globl _TR1
                                     72 	.globl _TF0
                                     73 	.globl _TR0
                                     74 	.globl _IE1
                                     75 	.globl _IT1
                                     76 	.globl _IE0
                                     77 	.globl _IT0
                                     78 	.globl _P0_7
                                     79 	.globl _P0_6
                                     80 	.globl _P0_5
                                     81 	.globl _P0_4
                                     82 	.globl _P0_3
                                     83 	.globl _P0_2
                                     84 	.globl _P0_1
                                     85 	.globl _P0_0
                                     86 	.globl _B
                                     87 	.globl _ACC
                                     88 	.globl _PSW
                                     89 	.globl _IP
                                     90 	.globl _P3
                                     91 	.globl _IE
                                     92 	.globl _P2
                                     93 	.globl _SBUF
                                     94 	.globl _SCON
                                     95 	.globl _P1
                                     96 	.globl _TH1
                                     97 	.globl _TH0
                                     98 	.globl _TL1
                                     99 	.globl _TL0
                                    100 	.globl _TMOD
                                    101 	.globl _TCON
                                    102 	.globl _PCON
                                    103 	.globl _DPH
                                    104 	.globl _DPL
                                    105 	.globl _SP
                                    106 	.globl _P0
                                    107 	.globl _SPI_Init
                                    108 	.globl _SPI_Write
                                    109 	.globl _SPI_WriteShort
                                    110 	.globl _SPI_Read
                                    111 ;--------------------------------------------------------
                                    112 ; special function registers
                                    113 ;--------------------------------------------------------
                                    114 	.area RSEG    (ABS,DATA)
      000000                        115 	.org 0x0000
                           000080   116 _P0	=	0x0080
                           000081   117 _SP	=	0x0081
                           000082   118 _DPL	=	0x0082
                           000083   119 _DPH	=	0x0083
                           000087   120 _PCON	=	0x0087
                           000088   121 _TCON	=	0x0088
                           000089   122 _TMOD	=	0x0089
                           00008A   123 _TL0	=	0x008a
                           00008B   124 _TL1	=	0x008b
                           00008C   125 _TH0	=	0x008c
                           00008D   126 _TH1	=	0x008d
                           000090   127 _P1	=	0x0090
                           000098   128 _SCON	=	0x0098
                           000099   129 _SBUF	=	0x0099
                           0000A0   130 _P2	=	0x00a0
                           0000A8   131 _IE	=	0x00a8
                           0000B0   132 _P3	=	0x00b0
                           0000B8   133 _IP	=	0x00b8
                           0000D0   134 _PSW	=	0x00d0
                           0000E0   135 _ACC	=	0x00e0
                           0000F0   136 _B	=	0x00f0
                                    137 ;--------------------------------------------------------
                                    138 ; special function bits
                                    139 ;--------------------------------------------------------
                                    140 	.area RSEG    (ABS,DATA)
      000000                        141 	.org 0x0000
                           000080   142 _P0_0	=	0x0080
                           000081   143 _P0_1	=	0x0081
                           000082   144 _P0_2	=	0x0082
                           000083   145 _P0_3	=	0x0083
                           000084   146 _P0_4	=	0x0084
                           000085   147 _P0_5	=	0x0085
                           000086   148 _P0_6	=	0x0086
                           000087   149 _P0_7	=	0x0087
                           000088   150 _IT0	=	0x0088
                           000089   151 _IE0	=	0x0089
                           00008A   152 _IT1	=	0x008a
                           00008B   153 _IE1	=	0x008b
                           00008C   154 _TR0	=	0x008c
                           00008D   155 _TF0	=	0x008d
                           00008E   156 _TR1	=	0x008e
                           00008F   157 _TF1	=	0x008f
                           000090   158 _P1_0	=	0x0090
                           000091   159 _P1_1	=	0x0091
                           000092   160 _P1_2	=	0x0092
                           000093   161 _P1_3	=	0x0093
                           000094   162 _P1_4	=	0x0094
                           000095   163 _P1_5	=	0x0095
                           000096   164 _P1_6	=	0x0096
                           000097   165 _P1_7	=	0x0097
                           000098   166 _RI	=	0x0098
                           000099   167 _TI	=	0x0099
                           00009A   168 _RB8	=	0x009a
                           00009B   169 _TB8	=	0x009b
                           00009C   170 _REN	=	0x009c
                           00009D   171 _SM2	=	0x009d
                           00009E   172 _SM1	=	0x009e
                           00009F   173 _SM0	=	0x009f
                           0000A0   174 _P2_0	=	0x00a0
                           0000A1   175 _P2_1	=	0x00a1
                           0000A2   176 _P2_2	=	0x00a2
                           0000A3   177 _P2_3	=	0x00a3
                           0000A4   178 _P2_4	=	0x00a4
                           0000A5   179 _P2_5	=	0x00a5
                           0000A6   180 _P2_6	=	0x00a6
                           0000A7   181 _P2_7	=	0x00a7
                           0000A8   182 _EX0	=	0x00a8
                           0000A9   183 _ET0	=	0x00a9
                           0000AA   184 _EX1	=	0x00aa
                           0000AB   185 _ET1	=	0x00ab
                           0000AC   186 _ES	=	0x00ac
                           0000AF   187 _EA	=	0x00af
                           0000B0   188 _P3_0	=	0x00b0
                           0000B1   189 _P3_1	=	0x00b1
                           0000B2   190 _P3_2	=	0x00b2
                           0000B3   191 _P3_3	=	0x00b3
                           0000B4   192 _P3_4	=	0x00b4
                           0000B5   193 _P3_5	=	0x00b5
                           0000B6   194 _P3_6	=	0x00b6
                           0000B7   195 _P3_7	=	0x00b7
                           0000B0   196 _RXD	=	0x00b0
                           0000B1   197 _TXD	=	0x00b1
                           0000B2   198 _INT0	=	0x00b2
                           0000B3   199 _INT1	=	0x00b3
                           0000B4   200 _T0	=	0x00b4
                           0000B5   201 _T1	=	0x00b5
                           0000B6   202 _WR	=	0x00b6
                           0000B7   203 _RD	=	0x00b7
                           0000B8   204 _PX0	=	0x00b8
                           0000B9   205 _PT0	=	0x00b9
                           0000BA   206 _PX1	=	0x00ba
                           0000BB   207 _PT1	=	0x00bb
                           0000BC   208 _PS	=	0x00bc
                           0000D0   209 _P	=	0x00d0
                           0000D1   210 _F1	=	0x00d1
                           0000D2   211 _OV	=	0x00d2
                           0000D3   212 _RS0	=	0x00d3
                           0000D4   213 _RS1	=	0x00d4
                           0000D5   214 _F0	=	0x00d5
                           0000D6   215 _AC	=	0x00d6
                           0000D7   216 _CY	=	0x00d7
                                    217 ;--------------------------------------------------------
                                    218 ; overlayable register banks
                                    219 ;--------------------------------------------------------
                                    220 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        221 	.ds 8
                                    222 ;--------------------------------------------------------
                                    223 ; internal ram data
                                    224 ;--------------------------------------------------------
                                    225 	.area DSEG    (DATA)
                                    226 ;--------------------------------------------------------
                                    227 ; overlayable items in internal ram
                                    228 ;--------------------------------------------------------
                                    229 	.area	OSEG    (OVR,DATA)
                                    230 	.area	OSEG    (OVR,DATA)
                                    231 ;--------------------------------------------------------
                                    232 ; indirectly addressable internal ram data
                                    233 ;--------------------------------------------------------
                                    234 	.area ISEG    (DATA)
                                    235 ;--------------------------------------------------------
                                    236 ; absolute internal ram data
                                    237 ;--------------------------------------------------------
                                    238 	.area IABS    (ABS,DATA)
                                    239 	.area IABS    (ABS,DATA)
                                    240 ;--------------------------------------------------------
                                    241 ; bit data
                                    242 ;--------------------------------------------------------
                                    243 	.area BSEG    (BIT)
                                    244 ;--------------------------------------------------------
                                    245 ; paged external ram data
                                    246 ;--------------------------------------------------------
                                    247 	.area PSEG    (PAG,XDATA)
                                    248 ;--------------------------------------------------------
                                    249 ; uninitialized external ram data
                                    250 ;--------------------------------------------------------
                                    251 	.area XSEG    (XDATA)
                                    252 ;--------------------------------------------------------
                                    253 ; absolute external ram data
                                    254 ;--------------------------------------------------------
                                    255 	.area XABS    (ABS,XDATA)
                                    256 ;--------------------------------------------------------
                                    257 ; initialized external ram data
                                    258 ;--------------------------------------------------------
                                    259 	.area XISEG   (XDATA)
                                    260 	.area HOME    (CODE)
                                    261 	.area GSINIT0 (CODE)
                                    262 	.area GSINIT1 (CODE)
                                    263 	.area GSINIT2 (CODE)
                                    264 	.area GSINIT3 (CODE)
                                    265 	.area GSINIT4 (CODE)
                                    266 	.area GSINIT5 (CODE)
                                    267 	.area GSINIT  (CODE)
                                    268 	.area GSFINAL (CODE)
                                    269 	.area CSEG    (CODE)
                                    270 ;--------------------------------------------------------
                                    271 ; global & static initialisations
                                    272 ;--------------------------------------------------------
                                    273 	.area HOME    (CODE)
                                    274 	.area GSINIT  (CODE)
                                    275 	.area GSFINAL (CODE)
                                    276 	.area GSINIT  (CODE)
                                    277 ;--------------------------------------------------------
                                    278 ; Home
                                    279 ;--------------------------------------------------------
                                    280 	.area HOME    (CODE)
                                    281 	.area HOME    (CODE)
                                    282 ;--------------------------------------------------------
                                    283 ; code
                                    284 ;--------------------------------------------------------
                                    285 	.area CSEG    (CODE)
                                    286 ;------------------------------------------------------------
                                    287 ;Allocation info for local variables in function 'SPI_Init'
                                    288 ;------------------------------------------------------------
                                    289 ;	optimized_spi.c:12: void SPI_Init(void) {
                                    290 ;	-----------------------------------------
                                    291 ;	 function SPI_Init
                                    292 ;	-----------------------------------------
      001A0D                        293 _SPI_Init:
                           000007   294 	ar7 = 0x07
                           000006   295 	ar6 = 0x06
                           000005   296 	ar5 = 0x05
                           000004   297 	ar4 = 0x04
                           000003   298 	ar3 = 0x03
                           000002   299 	ar2 = 0x02
                           000001   300 	ar1 = 0x01
                           000000   301 	ar0 = 0x00
                                    302 ;	optimized_spi.c:13: MOSI = 0;    // MOSI: output, initial low
                                    303 ;	assignBit
      001A0D C2 90            [12]  304 	clr	_P1_0
                                    305 ;	optimized_spi.c:14: MISO = 1;    // MISO: input
                                    306 ;	assignBit
      001A0F D2 91            [12]  307 	setb	_P1_1
                                    308 ;	optimized_spi.c:15: SCK = 0;     // SCK: output, initial low
                                    309 ;	assignBit
      001A11 C2 92            [12]  310 	clr	_P1_2
                                    311 ;	optimized_spi.c:16: SS = 1;      // SS: output, inactive high
                                    312 ;	assignBit
      001A13 D2 93            [12]  313 	setb	_P1_3
                                    314 ;	optimized_spi.c:17: }
      001A15 22               [24]  315 	ret
                                    316 ;------------------------------------------------------------
                                    317 ;Allocation info for local variables in function 'SPI_Write'
                                    318 ;------------------------------------------------------------
                                    319 ;i             Allocated to registers r6 
                                    320 ;------------------------------------------------------------
                                    321 ;	optimized_spi.c:23: void SPI_Write(unsigned char data) {
                                    322 ;	-----------------------------------------
                                    323 ;	 function SPI_Write
                                    324 ;	-----------------------------------------
      001A16                        325 _SPI_Write:
      001A16 AF 82            [24]  326 	mov	r7, dpl
                                    327 ;	optimized_spi.c:26: do {
      001A18 7E 08            [12]  328 	mov	r6,#0x08
      001A1A                        329 00101$:
                                    330 ;	optimized_spi.c:27: MOSI = (data & 0x80) ? 1 : 0;  // Send MSB first
      001A1A 8F 05            [24]  331 	mov	ar5,r7
      001A1C 53 05 80         [24]  332 	anl	ar5,#0x80
                                    333 ;	assignBit
      001A1F ED               [12]  334 	mov	a,r5
      001A20 24 FF            [12]  335 	add	a,#0xff
      001A22 92 90            [24]  336 	mov	_P1_0,c
                                    337 ;	optimized_spi.c:28: data <<= 1;                     // Shift data left
      001A24 EF               [12]  338 	mov	a,r7
      001A25 2F               [12]  339 	add	a,r7
      001A26 FF               [12]  340 	mov	r7,a
                                    341 ;	optimized_spi.c:29: SCK = 1;                        // Generate clock pulse
                                    342 ;	assignBit
      001A27 D2 92            [12]  343 	setb	_P1_2
                                    344 ;	optimized_spi.c:30: SCK = 0;
                                    345 ;	assignBit
      001A29 C2 92            [12]  346 	clr	_P1_2
                                    347 ;	optimized_spi.c:31: } while (--i);                      // More efficient than for loop
      001A2B DE ED            [24]  348 	djnz	r6,00101$
                                    349 ;	optimized_spi.c:32: }
      001A2D 22               [24]  350 	ret
                                    351 ;------------------------------------------------------------
                                    352 ;Allocation info for local variables in function 'SPI_WriteShort'
                                    353 ;------------------------------------------------------------
                                    354 ;	optimized_spi.c:38: void SPI_WriteShort(unsigned short data) {
                                    355 ;	-----------------------------------------
                                    356 ;	 function SPI_WriteShort
                                    357 ;	-----------------------------------------
      001A2E                        358 _SPI_WriteShort:
      001A2E AE 82            [24]  359 	mov	r6, dpl
      001A30 AF 83            [24]  360 	mov	r7, dph
                                    361 ;	optimized_spi.c:40: SPI_Write(data >> 8);     // Send high byte
      001A32 8F 82            [24]  362 	mov	dpl,r7
      001A34 C0 07            [24]  363 	push	ar7
      001A36 C0 06            [24]  364 	push	ar6
      001A38 12 1A 16         [24]  365 	lcall	_SPI_Write
      001A3B D0 06            [24]  366 	pop	ar6
      001A3D D0 07            [24]  367 	pop	ar7
                                    368 ;	optimized_spi.c:41: SPI_Write(data & 0xFF);   // Send low byte
      001A3F 8E 82            [24]  369 	mov	dpl,r6
                                    370 ;	optimized_spi.c:42: }
      001A41 02 1A 16         [24]  371 	ljmp	_SPI_Write
                                    372 ;------------------------------------------------------------
                                    373 ;Allocation info for local variables in function 'SPI_Read'
                                    374 ;------------------------------------------------------------
                                    375 ;i             Allocated to registers r6 
                                    376 ;data          Allocated to registers r7 
                                    377 ;------------------------------------------------------------
                                    378 ;	optimized_spi.c:48: unsigned char SPI_Read(void) {
                                    379 ;	-----------------------------------------
                                    380 ;	 function SPI_Read
                                    381 ;	-----------------------------------------
      001A44                        382 _SPI_Read:
                                    383 ;	optimized_spi.c:50: register unsigned char data = 0;  // Use register for data
      001A44 7F 00            [12]  384 	mov	r7,#0x00
                                    385 ;	optimized_spi.c:52: do {
      001A46 7E 08            [12]  386 	mov	r6,#0x08
      001A48                        387 00103$:
                                    388 ;	optimized_spi.c:53: data <<= 1;           // Shift data left
      001A48 EF               [12]  389 	mov	a,r7
      001A49 2F               [12]  390 	add	a,r7
      001A4A FF               [12]  391 	mov	r7,a
                                    392 ;	optimized_spi.c:54: SCK = 1;             // Generate clock pulse
                                    393 ;	assignBit
      001A4B D2 92            [12]  394 	setb	_P1_2
                                    395 ;	optimized_spi.c:55: if (MISO) {          // Read MISO
      001A4D 30 91 03         [24]  396 	jnb	_P1_1,00102$
                                    397 ;	optimized_spi.c:56: data |= 1;       // Set LSB if MISO is high
      001A50 43 07 01         [24]  398 	orl	ar7,#0x01
      001A53                        399 00102$:
                                    400 ;	optimized_spi.c:58: SCK = 0;
                                    401 ;	assignBit
      001A53 C2 92            [12]  402 	clr	_P1_2
                                    403 ;	optimized_spi.c:59: } while (--i);           // More efficient than for loop
      001A55 DE F1            [24]  404 	djnz	r6,00103$
                                    405 ;	optimized_spi.c:61: return data;
      001A57 8F 82            [24]  406 	mov	dpl, r7
                                    407 ;	optimized_spi.c:62: }
      001A59 22               [24]  408 	ret
                                    409 	.area CSEG    (CODE)
                                    410 	.area CONST   (CODE)
                                    411 	.area XINIT   (CODE)
                                    412 	.area CABS    (ABS,CODE)
