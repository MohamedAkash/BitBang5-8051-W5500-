                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.5.0 #15242 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module optimized_uart
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-medium
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _hexChars
                                     12 	.globl _CY
                                     13 	.globl _AC
                                     14 	.globl _F0
                                     15 	.globl _RS1
                                     16 	.globl _RS0
                                     17 	.globl _OV
                                     18 	.globl _F1
                                     19 	.globl _P
                                     20 	.globl _PS
                                     21 	.globl _PT1
                                     22 	.globl _PX1
                                     23 	.globl _PT0
                                     24 	.globl _PX0
                                     25 	.globl _RD
                                     26 	.globl _WR
                                     27 	.globl _T1
                                     28 	.globl _T0
                                     29 	.globl _INT1
                                     30 	.globl _INT0
                                     31 	.globl _TXD
                                     32 	.globl _RXD
                                     33 	.globl _P3_7
                                     34 	.globl _P3_6
                                     35 	.globl _P3_5
                                     36 	.globl _P3_4
                                     37 	.globl _P3_3
                                     38 	.globl _P3_2
                                     39 	.globl _P3_1
                                     40 	.globl _P3_0
                                     41 	.globl _EA
                                     42 	.globl _ES
                                     43 	.globl _ET1
                                     44 	.globl _EX1
                                     45 	.globl _ET0
                                     46 	.globl _EX0
                                     47 	.globl _P2_7
                                     48 	.globl _P2_6
                                     49 	.globl _P2_5
                                     50 	.globl _P2_4
                                     51 	.globl _P2_3
                                     52 	.globl _P2_2
                                     53 	.globl _P2_1
                                     54 	.globl _P2_0
                                     55 	.globl _SM0
                                     56 	.globl _SM1
                                     57 	.globl _SM2
                                     58 	.globl _REN
                                     59 	.globl _TB8
                                     60 	.globl _RB8
                                     61 	.globl _TI
                                     62 	.globl _RI
                                     63 	.globl _P1_7
                                     64 	.globl _P1_6
                                     65 	.globl _P1_5
                                     66 	.globl _P1_4
                                     67 	.globl _P1_3
                                     68 	.globl _P1_2
                                     69 	.globl _P1_1
                                     70 	.globl _P1_0
                                     71 	.globl _TF1
                                     72 	.globl _TR1
                                     73 	.globl _TF0
                                     74 	.globl _TR0
                                     75 	.globl _IE1
                                     76 	.globl _IT1
                                     77 	.globl _IE0
                                     78 	.globl _IT0
                                     79 	.globl _P0_7
                                     80 	.globl _P0_6
                                     81 	.globl _P0_5
                                     82 	.globl _P0_4
                                     83 	.globl _P0_3
                                     84 	.globl _P0_2
                                     85 	.globl _P0_1
                                     86 	.globl _P0_0
                                     87 	.globl _B
                                     88 	.globl _ACC
                                     89 	.globl _PSW
                                     90 	.globl _IP
                                     91 	.globl _P3
                                     92 	.globl _IE
                                     93 	.globl _P2
                                     94 	.globl _SBUF
                                     95 	.globl _SCON
                                     96 	.globl _P1
                                     97 	.globl _TH1
                                     98 	.globl _TH0
                                     99 	.globl _TL1
                                    100 	.globl _TL0
                                    101 	.globl _TMOD
                                    102 	.globl _TCON
                                    103 	.globl _PCON
                                    104 	.globl _DPH
                                    105 	.globl _DPL
                                    106 	.globl _SP
                                    107 	.globl _P0
                                    108 	.globl _UART_Init
                                    109 	.globl _UART_TxChar
                                    110 	.globl _UART_RxChar
                                    111 	.globl _UART_PrintString
                                    112 	.globl _UART_PrintHex
                                    113 	.globl _UART_PrintNumber
                                    114 	.globl _UART_PrintIP
                                    115 	.globl _UART_PrintMAC
                                    116 ;--------------------------------------------------------
                                    117 ; special function registers
                                    118 ;--------------------------------------------------------
                                    119 	.area RSEG    (ABS,DATA)
      000000                        120 	.org 0x0000
                           000080   121 _P0	=	0x0080
                           000081   122 _SP	=	0x0081
                           000082   123 _DPL	=	0x0082
                           000083   124 _DPH	=	0x0083
                           000087   125 _PCON	=	0x0087
                           000088   126 _TCON	=	0x0088
                           000089   127 _TMOD	=	0x0089
                           00008A   128 _TL0	=	0x008a
                           00008B   129 _TL1	=	0x008b
                           00008C   130 _TH0	=	0x008c
                           00008D   131 _TH1	=	0x008d
                           000090   132 _P1	=	0x0090
                           000098   133 _SCON	=	0x0098
                           000099   134 _SBUF	=	0x0099
                           0000A0   135 _P2	=	0x00a0
                           0000A8   136 _IE	=	0x00a8
                           0000B0   137 _P3	=	0x00b0
                           0000B8   138 _IP	=	0x00b8
                           0000D0   139 _PSW	=	0x00d0
                           0000E0   140 _ACC	=	0x00e0
                           0000F0   141 _B	=	0x00f0
                                    142 ;--------------------------------------------------------
                                    143 ; special function bits
                                    144 ;--------------------------------------------------------
                                    145 	.area RSEG    (ABS,DATA)
      000000                        146 	.org 0x0000
                           000080   147 _P0_0	=	0x0080
                           000081   148 _P0_1	=	0x0081
                           000082   149 _P0_2	=	0x0082
                           000083   150 _P0_3	=	0x0083
                           000084   151 _P0_4	=	0x0084
                           000085   152 _P0_5	=	0x0085
                           000086   153 _P0_6	=	0x0086
                           000087   154 _P0_7	=	0x0087
                           000088   155 _IT0	=	0x0088
                           000089   156 _IE0	=	0x0089
                           00008A   157 _IT1	=	0x008a
                           00008B   158 _IE1	=	0x008b
                           00008C   159 _TR0	=	0x008c
                           00008D   160 _TF0	=	0x008d
                           00008E   161 _TR1	=	0x008e
                           00008F   162 _TF1	=	0x008f
                           000090   163 _P1_0	=	0x0090
                           000091   164 _P1_1	=	0x0091
                           000092   165 _P1_2	=	0x0092
                           000093   166 _P1_3	=	0x0093
                           000094   167 _P1_4	=	0x0094
                           000095   168 _P1_5	=	0x0095
                           000096   169 _P1_6	=	0x0096
                           000097   170 _P1_7	=	0x0097
                           000098   171 _RI	=	0x0098
                           000099   172 _TI	=	0x0099
                           00009A   173 _RB8	=	0x009a
                           00009B   174 _TB8	=	0x009b
                           00009C   175 _REN	=	0x009c
                           00009D   176 _SM2	=	0x009d
                           00009E   177 _SM1	=	0x009e
                           00009F   178 _SM0	=	0x009f
                           0000A0   179 _P2_0	=	0x00a0
                           0000A1   180 _P2_1	=	0x00a1
                           0000A2   181 _P2_2	=	0x00a2
                           0000A3   182 _P2_3	=	0x00a3
                           0000A4   183 _P2_4	=	0x00a4
                           0000A5   184 _P2_5	=	0x00a5
                           0000A6   185 _P2_6	=	0x00a6
                           0000A7   186 _P2_7	=	0x00a7
                           0000A8   187 _EX0	=	0x00a8
                           0000A9   188 _ET0	=	0x00a9
                           0000AA   189 _EX1	=	0x00aa
                           0000AB   190 _ET1	=	0x00ab
                           0000AC   191 _ES	=	0x00ac
                           0000AF   192 _EA	=	0x00af
                           0000B0   193 _P3_0	=	0x00b0
                           0000B1   194 _P3_1	=	0x00b1
                           0000B2   195 _P3_2	=	0x00b2
                           0000B3   196 _P3_3	=	0x00b3
                           0000B4   197 _P3_4	=	0x00b4
                           0000B5   198 _P3_5	=	0x00b5
                           0000B6   199 _P3_6	=	0x00b6
                           0000B7   200 _P3_7	=	0x00b7
                           0000B0   201 _RXD	=	0x00b0
                           0000B1   202 _TXD	=	0x00b1
                           0000B2   203 _INT0	=	0x00b2
                           0000B3   204 _INT1	=	0x00b3
                           0000B4   205 _T0	=	0x00b4
                           0000B5   206 _T1	=	0x00b5
                           0000B6   207 _WR	=	0x00b6
                           0000B7   208 _RD	=	0x00b7
                           0000B8   209 _PX0	=	0x00b8
                           0000B9   210 _PT0	=	0x00b9
                           0000BA   211 _PX1	=	0x00ba
                           0000BB   212 _PT1	=	0x00bb
                           0000BC   213 _PS	=	0x00bc
                           0000D0   214 _P	=	0x00d0
                           0000D1   215 _F1	=	0x00d1
                           0000D2   216 _OV	=	0x00d2
                           0000D3   217 _RS0	=	0x00d3
                           0000D4   218 _RS1	=	0x00d4
                           0000D5   219 _F0	=	0x00d5
                           0000D6   220 _AC	=	0x00d6
                           0000D7   221 _CY	=	0x00d7
                                    222 ;--------------------------------------------------------
                                    223 ; overlayable register banks
                                    224 ;--------------------------------------------------------
                                    225 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        226 	.ds 8
                                    227 ;--------------------------------------------------------
                                    228 ; internal ram data
                                    229 ;--------------------------------------------------------
                                    230 	.area DSEG    (DATA)
                                    231 ;--------------------------------------------------------
                                    232 ; overlayable items in internal ram
                                    233 ;--------------------------------------------------------
                                    234 ;--------------------------------------------------------
                                    235 ; indirectly addressable internal ram data
                                    236 ;--------------------------------------------------------
                                    237 	.area ISEG    (DATA)
                                    238 ;--------------------------------------------------------
                                    239 ; absolute internal ram data
                                    240 ;--------------------------------------------------------
                                    241 	.area IABS    (ABS,DATA)
                                    242 	.area IABS    (ABS,DATA)
                                    243 ;--------------------------------------------------------
                                    244 ; bit data
                                    245 ;--------------------------------------------------------
                                    246 	.area BSEG    (BIT)
                                    247 ;--------------------------------------------------------
                                    248 ; paged external ram data
                                    249 ;--------------------------------------------------------
                                    250 	.area PSEG    (PAG,XDATA)
                                    251 ;--------------------------------------------------------
                                    252 ; uninitialized external ram data
                                    253 ;--------------------------------------------------------
                                    254 	.area XSEG    (XDATA)
                                    255 ;--------------------------------------------------------
                                    256 ; absolute external ram data
                                    257 ;--------------------------------------------------------
                                    258 	.area XABS    (ABS,XDATA)
                                    259 ;--------------------------------------------------------
                                    260 ; initialized external ram data
                                    261 ;--------------------------------------------------------
                                    262 	.area XISEG   (XDATA)
                                    263 	.area HOME    (CODE)
                                    264 	.area GSINIT0 (CODE)
                                    265 	.area GSINIT1 (CODE)
                                    266 	.area GSINIT2 (CODE)
                                    267 	.area GSINIT3 (CODE)
                                    268 	.area GSINIT4 (CODE)
                                    269 	.area GSINIT5 (CODE)
                                    270 	.area GSINIT  (CODE)
                                    271 	.area GSFINAL (CODE)
                                    272 	.area CSEG    (CODE)
                                    273 ;--------------------------------------------------------
                                    274 ; global & static initialisations
                                    275 ;--------------------------------------------------------
                                    276 	.area HOME    (CODE)
                                    277 	.area GSINIT  (CODE)
                                    278 	.area GSFINAL (CODE)
                                    279 	.area GSINIT  (CODE)
                                    280 ;--------------------------------------------------------
                                    281 ; Home
                                    282 ;--------------------------------------------------------
                                    283 	.area HOME    (CODE)
                                    284 	.area HOME    (CODE)
                                    285 ;--------------------------------------------------------
                                    286 ; code
                                    287 ;--------------------------------------------------------
                                    288 	.area CSEG    (CODE)
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'UART_Init'
                                    291 ;------------------------------------------------------------
                                    292 ;	optimized_uart.c:6: void UART_Init(void) {
                                    293 ;	-----------------------------------------
                                    294 ;	 function UART_Init
                                    295 ;	-----------------------------------------
      001886                        296 _UART_Init:
                           000007   297 	ar7 = 0x07
                           000006   298 	ar6 = 0x06
                           000005   299 	ar5 = 0x05
                           000004   300 	ar4 = 0x04
                           000003   301 	ar3 = 0x03
                           000002   302 	ar2 = 0x02
                           000001   303 	ar1 = 0x01
                           000000   304 	ar0 = 0x00
                                    305 ;	optimized_uart.c:7: TMOD = 0x20;  // Timer 1, mode 2
      001886 75 89 20         [24]  306 	mov	_TMOD,#0x20
                                    307 ;	optimized_uart.c:8: TH1 = 0xFA;   // 9600 baud
      001889 75 8D FA         [24]  308 	mov	_TH1,#0xfa
                                    309 ;	optimized_uart.c:9: SCON = 0x50;  // Mode 1, enable receiver
      00188C 75 98 50         [24]  310 	mov	_SCON,#0x50
                                    311 ;	optimized_uart.c:10: TR1 = 1;      // Start Timer 1
                                    312 ;	assignBit
      00188F D2 8E            [12]  313 	setb	_TR1
                                    314 ;	optimized_uart.c:11: }
      001891 22               [24]  315 	ret
                                    316 ;------------------------------------------------------------
                                    317 ;Allocation info for local variables in function 'UART_TxChar'
                                    318 ;------------------------------------------------------------
                                    319 ;	optimized_uart.c:13: void UART_TxChar(char c) {
                                    320 ;	-----------------------------------------
                                    321 ;	 function UART_TxChar
                                    322 ;	-----------------------------------------
      001892                        323 _UART_TxChar:
      001892 85 82 99         [24]  324 	mov	_SBUF,dpl
                                    325 ;	optimized_uart.c:15: while (!TI);
      001895                        326 00101$:
                                    327 ;	optimized_uart.c:16: TI = 0;
                                    328 ;	assignBit
      001895 10 99 02         [24]  329 	jbc	_TI,00118$
      001898 80 FB            [24]  330 	sjmp	00101$
      00189A                        331 00118$:
                                    332 ;	optimized_uart.c:17: }
      00189A 22               [24]  333 	ret
                                    334 ;------------------------------------------------------------
                                    335 ;Allocation info for local variables in function 'UART_RxChar'
                                    336 ;------------------------------------------------------------
                                    337 ;	optimized_uart.c:19: char UART_RxChar(void) {
                                    338 ;	-----------------------------------------
                                    339 ;	 function UART_RxChar
                                    340 ;	-----------------------------------------
      00189B                        341 _UART_RxChar:
                                    342 ;	optimized_uart.c:20: char c = '\0';
      00189B 7F 00            [12]  343 	mov	r7,#0x00
                                    344 ;	optimized_uart.c:21: if (RI) {
      00189D 30 98 04         [24]  345 	jnb	_RI,00102$
                                    346 ;	optimized_uart.c:22: c = SBUF;
      0018A0 AF 99            [24]  347 	mov	r7,_SBUF
                                    348 ;	optimized_uart.c:23: RI = 0;
                                    349 ;	assignBit
      0018A2 C2 98            [12]  350 	clr	_RI
      0018A4                        351 00102$:
                                    352 ;	optimized_uart.c:25: return c;
      0018A4 8F 82            [24]  353 	mov	dpl, r7
                                    354 ;	optimized_uart.c:26: }
      0018A6 22               [24]  355 	ret
                                    356 ;------------------------------------------------------------
                                    357 ;Allocation info for local variables in function 'UART_PrintString'
                                    358 ;------------------------------------------------------------
                                    359 ;	optimized_uart.c:29: void UART_PrintString(char *str) {  // Removed 'const' to match header
                                    360 ;	-----------------------------------------
                                    361 ;	 function UART_PrintString
                                    362 ;	-----------------------------------------
      0018A7                        363 _UART_PrintString:
      0018A7 AD 82            [24]  364 	mov	r5, dpl
      0018A9 AE 83            [24]  365 	mov	r6, dph
      0018AB AF F0            [24]  366 	mov	r7, b
                                    367 ;	optimized_uart.c:30: while (*str) UART_TxChar(*str++);
      0018AD                        368 00101$:
      0018AD 8D 82            [24]  369 	mov	dpl,r5
      0018AF 8E 83            [24]  370 	mov	dph,r6
      0018B1 8F F0            [24]  371 	mov	b,r7
      0018B3 12 1B 12         [24]  372 	lcall	__gptrget
      0018B6 FC               [12]  373 	mov	r4,a
      0018B7 60 18            [24]  374 	jz	00104$
      0018B9 8C 82            [24]  375 	mov	dpl,r4
      0018BB 0D               [12]  376 	inc	r5
      0018BC BD 00 01         [24]  377 	cjne	r5,#0x00,00120$
      0018BF 0E               [12]  378 	inc	r6
      0018C0                        379 00120$:
      0018C0 C0 07            [24]  380 	push	ar7
      0018C2 C0 06            [24]  381 	push	ar6
      0018C4 C0 05            [24]  382 	push	ar5
      0018C6 12 18 92         [24]  383 	lcall	_UART_TxChar
      0018C9 D0 05            [24]  384 	pop	ar5
      0018CB D0 06            [24]  385 	pop	ar6
      0018CD D0 07            [24]  386 	pop	ar7
      0018CF 80 DC            [24]  387 	sjmp	00101$
      0018D1                        388 00104$:
                                    389 ;	optimized_uart.c:31: }
      0018D1 22               [24]  390 	ret
                                    391 ;------------------------------------------------------------
                                    392 ;Allocation info for local variables in function 'UART_PrintHex'
                                    393 ;------------------------------------------------------------
                                    394 ;	optimized_uart.c:39: void UART_PrintHex(unsigned char num) {
                                    395 ;	-----------------------------------------
                                    396 ;	 function UART_PrintHex
                                    397 ;	-----------------------------------------
      0018D2                        398 _UART_PrintHex:
                                    399 ;	optimized_uart.c:40: UART_TxChar(hexChars[(num >> 4) & 0x0F]);
      0018D2 E5 82            [12]  400 	mov	a,dpl
      0018D4 FF               [12]  401 	mov	r7,a
      0018D5 C4               [12]  402 	swap	a
      0018D6 54 0F            [12]  403 	anl	a,#0x0f
      0018D8 90 1C 01         [24]  404 	mov	dptr,#_hexChars
      0018DB 93               [24]  405 	movc	a,@a+dptr
      0018DC F5 82            [12]  406 	mov	dpl,a
      0018DE C0 07            [24]  407 	push	ar7
      0018E0 12 18 92         [24]  408 	lcall	_UART_TxChar
      0018E3 D0 07            [24]  409 	pop	ar7
                                    410 ;	optimized_uart.c:41: UART_TxChar(hexChars[num & 0x0F]);
      0018E5 74 0F            [12]  411 	mov	a,#0x0f
      0018E7 5F               [12]  412 	anl	a,r7
      0018E8 90 1C 01         [24]  413 	mov	dptr,#_hexChars
      0018EB 93               [24]  414 	movc	a,@a+dptr
      0018EC F5 82            [12]  415 	mov	dpl,a
                                    416 ;	optimized_uart.c:42: }
      0018EE 02 18 92         [24]  417 	ljmp	_UART_TxChar
                                    418 ;------------------------------------------------------------
                                    419 ;Allocation info for local variables in function 'UART_PrintNumber'
                                    420 ;------------------------------------------------------------
                                    421 ;	optimized_uart.c:68: void UART_PrintNumber(unsigned char num) {
                                    422 ;	-----------------------------------------
                                    423 ;	 function UART_PrintNumber
                                    424 ;	-----------------------------------------
      0018F1                        425 _UART_PrintNumber:
                                    426 ;	optimized_uart.c:69: if (num == 0) {
      0018F1 E5 82            [12]  427 	mov	a,dpl
      0018F3 FF               [12]  428 	mov	r7,a
      0018F4 70 06            [24]  429 	jnz	00102$
                                    430 ;	optimized_uart.c:70: UART_TxChar('0');
      0018F6 75 82 30         [24]  431 	mov	dpl, #0x30
                                    432 ;	optimized_uart.c:71: return;
      0018F9 02 18 92         [24]  433 	ljmp	_UART_TxChar
      0018FC                        434 00102$:
                                    435 ;	optimized_uart.c:74: if (num >= 100) {
      0018FC BF 64 00         [24]  436 	cjne	r7,#0x64,00133$
      0018FF                        437 00133$:
      0018FF 40 3C            [24]  438 	jc	00107$
                                    439 ;	optimized_uart.c:75: UART_TxChar((num/100) + '0');
      001901 8F 06            [24]  440 	mov	ar6,r7
      001903 8E 05            [24]  441 	mov	ar5,r6
      001905 75 F0 64         [24]  442 	mov	b,#0x64
      001908 ED               [12]  443 	mov	a,r5
      001909 84               [48]  444 	div	ab
      00190A 24 30            [12]  445 	add	a,#0x30
      00190C F5 82            [12]  446 	mov	dpl,a
      00190E C0 06            [24]  447 	push	ar6
      001910 12 18 92         [24]  448 	lcall	_UART_TxChar
      001913 D0 06            [24]  449 	pop	ar6
                                    450 ;	optimized_uart.c:76: num = num % 100;
      001915 75 F0 64         [24]  451 	mov	b,#0x64
      001918 EE               [12]  452 	mov	a,r6
      001919 84               [48]  453 	div	ab
      00191A AE F0            [24]  454 	mov	r6,b
                                    455 ;	optimized_uart.c:77: UART_TxChar((num/10) + '0');
      00191C 8E 05            [24]  456 	mov	ar5,r6
      00191E 75 F0 0A         [24]  457 	mov	b,#0x0a
      001921 ED               [12]  458 	mov	a,r5
      001922 84               [48]  459 	div	ab
      001923 24 30            [12]  460 	add	a,#0x30
      001925 F5 82            [12]  461 	mov	dpl,a
      001927 C0 06            [24]  462 	push	ar6
      001929 12 18 92         [24]  463 	lcall	_UART_TxChar
      00192C D0 06            [24]  464 	pop	ar6
                                    465 ;	optimized_uart.c:78: UART_TxChar((num%10) + '0');
      00192E 75 F0 0A         [24]  466 	mov	b,#0x0a
      001931 EE               [12]  467 	mov	a,r6
      001932 84               [48]  468 	div	ab
      001933 AE F0            [24]  469 	mov	r6,b
      001935 74 30            [12]  470 	mov	a,#0x30
      001937 2E               [12]  471 	add	a, r6
      001938 F5 82            [12]  472 	mov	dpl,a
      00193A 02 18 92         [24]  473 	ljmp	_UART_TxChar
      00193D                        474 00107$:
                                    475 ;	optimized_uart.c:80: else if (num >= 10) {
      00193D BF 0A 00         [24]  476 	cjne	r7,#0x0a,00135$
      001940                        477 00135$:
      001940 40 23            [24]  478 	jc	00104$
                                    479 ;	optimized_uart.c:81: UART_TxChar((num/10) + '0');
      001942 8F 06            [24]  480 	mov	ar6,r7
      001944 8E 05            [24]  481 	mov	ar5,r6
      001946 75 F0 0A         [24]  482 	mov	b,#0x0a
      001949 ED               [12]  483 	mov	a,r5
      00194A 84               [48]  484 	div	ab
      00194B 24 30            [12]  485 	add	a,#0x30
      00194D F5 82            [12]  486 	mov	dpl,a
      00194F C0 06            [24]  487 	push	ar6
      001951 12 18 92         [24]  488 	lcall	_UART_TxChar
      001954 D0 06            [24]  489 	pop	ar6
                                    490 ;	optimized_uart.c:82: UART_TxChar((num%10) + '0');
      001956 75 F0 0A         [24]  491 	mov	b,#0x0a
      001959 EE               [12]  492 	mov	a,r6
      00195A 84               [48]  493 	div	ab
      00195B AE F0            [24]  494 	mov	r6,b
      00195D 74 30            [12]  495 	mov	a,#0x30
      00195F 2E               [12]  496 	add	a, r6
      001960 F5 82            [12]  497 	mov	dpl,a
      001962 02 18 92         [24]  498 	ljmp	_UART_TxChar
      001965                        499 00104$:
                                    500 ;	optimized_uart.c:85: UART_TxChar(num + '0');
      001965 74 30            [12]  501 	mov	a,#0x30
      001967 2F               [12]  502 	add	a, r7
      001968 F5 82            [12]  503 	mov	dpl,a
                                    504 ;	optimized_uart.c:87: }
      00196A 02 18 92         [24]  505 	ljmp	_UART_TxChar
                                    506 ;------------------------------------------------------------
                                    507 ;Allocation info for local variables in function 'UART_PrintIP'
                                    508 ;------------------------------------------------------------
                                    509 ;	optimized_uart.c:89: void UART_PrintIP(unsigned char *ip) {  // Removed 'const' to match header
                                    510 ;	-----------------------------------------
                                    511 ;	 function UART_PrintIP
                                    512 ;	-----------------------------------------
      00196D                        513 _UART_PrintIP:
      00196D AD 82            [24]  514 	mov	r5, dpl
      00196F AE 83            [24]  515 	mov	r6, dph
      001971 AF F0            [24]  516 	mov	r7, b
                                    517 ;	optimized_uart.c:91: for (i = 0; i < 4; i++) {
      001973 7C 00            [12]  518 	mov	r4,#0x00
      001975                        519 00104$:
                                    520 ;	optimized_uart.c:92: UART_PrintNumber(ip[i]);
      001975 EC               [12]  521 	mov	a,r4
      001976 2D               [12]  522 	add	a, r5
      001977 F9               [12]  523 	mov	r1,a
      001978 E4               [12]  524 	clr	a
      001979 3E               [12]  525 	addc	a, r6
      00197A FA               [12]  526 	mov	r2,a
      00197B 8F 03            [24]  527 	mov	ar3,r7
      00197D 89 82            [24]  528 	mov	dpl,r1
      00197F 8A 83            [24]  529 	mov	dph,r2
      001981 8B F0            [24]  530 	mov	b,r3
      001983 12 1B 12         [24]  531 	lcall	__gptrget
      001986 F5 82            [12]  532 	mov	dpl,a
      001988 C0 07            [24]  533 	push	ar7
      00198A C0 06            [24]  534 	push	ar6
      00198C C0 05            [24]  535 	push	ar5
      00198E C0 04            [24]  536 	push	ar4
      001990 12 18 F1         [24]  537 	lcall	_UART_PrintNumber
      001993 D0 04            [24]  538 	pop	ar4
      001995 D0 05            [24]  539 	pop	ar5
      001997 D0 06            [24]  540 	pop	ar6
      001999 D0 07            [24]  541 	pop	ar7
                                    542 ;	optimized_uart.c:93: if (i < 3) UART_TxChar('.');
      00199B BC 03 00         [24]  543 	cjne	r4,#0x03,00121$
      00199E                        544 00121$:
      00199E 50 16            [24]  545 	jnc	00105$
      0019A0 75 82 2E         [24]  546 	mov	dpl, #0x2e
      0019A3 C0 07            [24]  547 	push	ar7
      0019A5 C0 06            [24]  548 	push	ar6
      0019A7 C0 05            [24]  549 	push	ar5
      0019A9 C0 04            [24]  550 	push	ar4
      0019AB 12 18 92         [24]  551 	lcall	_UART_TxChar
      0019AE D0 04            [24]  552 	pop	ar4
      0019B0 D0 05            [24]  553 	pop	ar5
      0019B2 D0 06            [24]  554 	pop	ar6
      0019B4 D0 07            [24]  555 	pop	ar7
      0019B6                        556 00105$:
                                    557 ;	optimized_uart.c:91: for (i = 0; i < 4; i++) {
      0019B6 0C               [12]  558 	inc	r4
      0019B7 BC 04 00         [24]  559 	cjne	r4,#0x04,00123$
      0019BA                        560 00123$:
      0019BA 40 B9            [24]  561 	jc	00104$
                                    562 ;	optimized_uart.c:95: }
      0019BC 22               [24]  563 	ret
                                    564 ;------------------------------------------------------------
                                    565 ;Allocation info for local variables in function 'UART_PrintMAC'
                                    566 ;------------------------------------------------------------
                                    567 ;	optimized_uart.c:97: void UART_PrintMAC(unsigned char *mac) {  // Removed 'const' to match header
                                    568 ;	-----------------------------------------
                                    569 ;	 function UART_PrintMAC
                                    570 ;	-----------------------------------------
      0019BD                        571 _UART_PrintMAC:
      0019BD AD 82            [24]  572 	mov	r5, dpl
      0019BF AE 83            [24]  573 	mov	r6, dph
      0019C1 AF F0            [24]  574 	mov	r7, b
                                    575 ;	optimized_uart.c:99: for (i = 0; i < 6; i++) {
      0019C3 7C 00            [12]  576 	mov	r4,#0x00
      0019C5                        577 00104$:
                                    578 ;	optimized_uart.c:100: UART_PrintHex(mac[i]);
      0019C5 EC               [12]  579 	mov	a,r4
      0019C6 2D               [12]  580 	add	a, r5
      0019C7 F9               [12]  581 	mov	r1,a
      0019C8 E4               [12]  582 	clr	a
      0019C9 3E               [12]  583 	addc	a, r6
      0019CA FA               [12]  584 	mov	r2,a
      0019CB 8F 03            [24]  585 	mov	ar3,r7
      0019CD 89 82            [24]  586 	mov	dpl,r1
      0019CF 8A 83            [24]  587 	mov	dph,r2
      0019D1 8B F0            [24]  588 	mov	b,r3
      0019D3 12 1B 12         [24]  589 	lcall	__gptrget
      0019D6 F5 82            [12]  590 	mov	dpl,a
      0019D8 C0 07            [24]  591 	push	ar7
      0019DA C0 06            [24]  592 	push	ar6
      0019DC C0 05            [24]  593 	push	ar5
      0019DE C0 04            [24]  594 	push	ar4
      0019E0 12 18 D2         [24]  595 	lcall	_UART_PrintHex
      0019E3 D0 04            [24]  596 	pop	ar4
      0019E5 D0 05            [24]  597 	pop	ar5
      0019E7 D0 06            [24]  598 	pop	ar6
      0019E9 D0 07            [24]  599 	pop	ar7
                                    600 ;	optimized_uart.c:101: if (i < 5) UART_TxChar(' ');
      0019EB BC 05 00         [24]  601 	cjne	r4,#0x05,00121$
      0019EE                        602 00121$:
      0019EE 50 16            [24]  603 	jnc	00105$
      0019F0 75 82 20         [24]  604 	mov	dpl, #0x20
      0019F3 C0 07            [24]  605 	push	ar7
      0019F5 C0 06            [24]  606 	push	ar6
      0019F7 C0 05            [24]  607 	push	ar5
      0019F9 C0 04            [24]  608 	push	ar4
      0019FB 12 18 92         [24]  609 	lcall	_UART_TxChar
      0019FE D0 04            [24]  610 	pop	ar4
      001A00 D0 05            [24]  611 	pop	ar5
      001A02 D0 06            [24]  612 	pop	ar6
      001A04 D0 07            [24]  613 	pop	ar7
      001A06                        614 00105$:
                                    615 ;	optimized_uart.c:99: for (i = 0; i < 6; i++) {
      001A06 0C               [12]  616 	inc	r4
      001A07 BC 06 00         [24]  617 	cjne	r4,#0x06,00123$
      001A0A                        618 00123$:
      001A0A 40 B9            [24]  619 	jc	00104$
                                    620 ;	optimized_uart.c:103: }
      001A0C 22               [24]  621 	ret
                                    622 	.area CSEG    (CODE)
                                    623 	.area CONST   (CODE)
                                    624 	.area CONST   (CODE)
      001C01                        625 _hexChars:
      001C01 30 31 32 33 34 35 36   626 	.ascii "0123456789ABCDEF"
             37 38 39 41 42 43 44
             45 46
      001C11 00                     627 	.db 0x00
                                    628 	.area CSEG    (CODE)
                                    629 	.area XINIT   (CODE)
                                    630 	.area CABS    (ABS,CODE)
