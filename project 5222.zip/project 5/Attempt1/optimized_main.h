#ifndef PROJECT5HEADER_H
#define PROJECT5HEADER_H

// Pin Definitions
#define MOSI P1_0
#define MISO P1_1
#define SCK  P1_2
#define SS   P1_3

#define RXD  P3_0
#define TXD  P3_1

// #define OUT  P1_4
// #define PININT P1_5

// WizNet Operation Codes
#define WIZNET_WRITE_OPCODE 0xF0
#define WIZNET_READ_OPCODE  0x0F

// Socket Selection - Simplified using bit manipulation
#define SOCK_BASE(n)    ((n) << 5)        // Base offset for socket n
#define S0_R  SOCK_BASE(0) | 0x08         // Socket 0 register
#define S0_TX SOCK_BASE(0) | 0x10         // Socket 0 TX buffer
#define S0_RX SOCK_BASE(0) | 0x18         // Socket 0 RX buffer
#define S1_R  SOCK_BASE(1) | 0x08         // Socket 1 register
#define S1_TX SOCK_BASE(1) | 0x10         // Socket 1 TX buffer
#define S1_RX SOCK_BASE(1) | 0x18         // Socket 1 RX buffer

// Socket Protocols
typedef enum {
    Sn_PC   = 0x00,    // Protocol closed
    Sn_PTCP = 0x01,    // TCP protocol
    Sn_PUDP = 0x02     // UDP protocol
} SocketProtocol;

// Register Addresses - Grouped by functionality
#define REG_MODE     0x0000    // Mode register
#define REG_NETWORK  0x0001    // Network registers start
#define REG_SOCKET   0x0004    // Socket registers start
#define REG_INT      0x0016    // Interrupt registers start

// Network Configuration Registers
#define GAR     (REG_NETWORK + 0x00)    // Gateway address
#define SUBR    (REG_NETWORK + 0x04)    // Subnet mask
#define SHAR    (REG_NETWORK + 0x08)    // Source MAC address
#define SIPR    (REG_NETWORK + 0x0E)    // Source IP address

#define CR     0x00    // Common register

// Socket Registers - Using offsets from base
#define Sn_MR       0x0000    // Mode
#define Sn_CR       0x0001    // Command
#define Sn_IR       0x0002    // Interrupt
#define Sn_SR       0x0003    // Status
#define Sn_PORT     0x0004    // Port (2 bytes)
#define Sn_DPORT    0x0010    // Destination port (2 bytes)
#define Sn_BUF_SIZE 0x001E    // Buffer size
#define Sn_TX_PTR   0x0022    // TX pointer (4 bytes)
#define Sn_RX_PTR   0x0026    // RX pointer (4 bytes)
#define Sn_IMR      0x002C    // Interrupt mask

// Constants
#define MAX_IP_LENGTH  16
#define MAX_MAC_LENGTH 18

// Function Declarations
// SPI Functions
void SPI_Init(void);
void SPI_Write(unsigned char data);
void SPI_WriteShort(unsigned short data);
unsigned char SPI_Read(void);

// WizNet Functions
void WIZnet_Write(unsigned short address, unsigned char modeRegister, unsigned char data);
unsigned char WIZnet_Read(unsigned short address, unsigned char modeRegister);
void WIZnet_Init(void);

// Network Configuration Functions
void WIZnet_SetIP(unsigned char *ip);
void WIZnet_SetMAC(unsigned char *mac);
void WIZnet_SetSubnetMask(unsigned char *subnet);
void WIZnet_SetGateway(unsigned char *gateway);

// Socket Management Functions
void WIZnet_SetSocketMode(unsigned char mode, unsigned char sock);
void WIZnet_SetSocketPort(unsigned char sock, int port);
void WIZnet_OpenSocket(unsigned char sock);
void WIZnet_CloseSocket(unsigned char sock);
void WIZnet_SetDestinationPort(unsigned char sock, int destPort);
void WIZnet_SetDestinationIP(unsigned char *ip, unsigned char sock);

// Data Transfer Functions
void Wiznet_SendPacket(unsigned char sock);
void writeToTXBufferUDP(unsigned char sock, unsigned char socktx);
void readFromRXBufferUDP(unsigned char sock, unsigned char sockrx);
void readFromRXBufferTCP(unsigned char sock, unsigned char sockrx);
void writeToTxBufferTCP(unsigned char sock, unsigned char socktx);

// TCP Specific Functions
void tcpListen(unsigned char sock);
void tcpConnect(unsigned char sock, unsigned char ip[], int destPort);

// UART Functions
void UART_Init(void);
void UART_TxChar(char c);
char UART_RxChar(void);
void UART_PrintString(char* str);
void UART_PrintIP(unsigned char* ip);
void UART_PrintNumber(unsigned char num);
void UART_PrintMAC(unsigned char* mac);
void UART_PrintHex(unsigned char num);
#define UART_PrintCharArr UART_PrintString    // Use macro instead of duplicate function

// Utility Functions
void delay(unsigned int milliseconds);
unsigned char combineHexChars(char high, char low);

#endif // MAINHEADER_H