# BitBangProject5

## Name
Bit Bang Project 5

## Description
The goal of this project is the design of a simple UDP/TCP responder. An STC89/STC12 on a
demo board will handle SPI transmissions between itself and a WIZNET LAN development
board; it will also be connected via serial terminal to a laptop that will be used to configure 
parameters such as port and IP

## Required Components
- WIZnet board (W5500)
- STC89/STC12 Demo Board or 8051 based chipset
- Wires/Transmission support equipment
- 2 LED diodes

## Usage
This project is the code to setup a WIZNET LAN developement board. The IP and configurations 
can be set using serial communication menu. Brought up by using the "?" Key. Then the server
can be send packets by the python script to check for speed and reliability. The Python script
can be set to UDP or TCP mode. Optimized SPI transmissions by creating assembly library to increase
response time by over 50%.

## Compile
- sdcc --model-medium -c uartLibrary.c  
- sdas8051 -losg -c spiASMLibraryE2.asm 
- sdcc --model-medium -o project5.hex project5.c uartLibrary.rel spiASMLibraryE2.asm 
- stcgal -p COM6 -b 9600 project5.hex


- sdcc --model-medium -c uart.c
- sdcc --model-medium -c spi.c
- sdcc --model-medium -o main.hex main.c uart.rel spi.rel
- stcgal -p COM6 -b 9600 main.hex


## Libraries
Wrote and linked two libraries to this project for serial communication and SPI. As well as header file

## More Info
Implementing making the server non-pingable using Wiznet. Used interrupts to notify when a message has been recieved
and needs to be proccessed. Logged all errors in python script to debug lost packets.

## Assembly improvements
Started using inline assembly in c file. Then transitioned to making a seperate c library using inline assembly.
Then wrote fully in assembly a new library. Used sdas8051 to generate .rel file and linked to main c program.
Main improvements are using RL A to rotate through bits during read and write and DJNZ instead of INC and CJNE. 

## Efficiency
Using the ASM code UDP got an average fastest time of 9s
Using the C code UDP got an average fastest time of 23s
Over 50% reduction in response time.

Using the ASM code TCP got an average fastest time of 7s
Using the C code TCP got an average fastest time of 17s
Again over 50% reduction in response time

![Spi in C](Images/SPI_C.png)

![Spi in ASM](Images/SPI_ASM.png)

## Graphs

![UPD Spi in C](Images/UDP_SPI_C.png)

![TCP Spi in C](Images/UDP_SPI_C.png)

![UPD Spi in ASM](Images/UDP_SPI_ASM.png)

![TCP Spi in ASM](Images/UDP_SPI_ASM.png)

## Roadmap
Continue development. Improve packet speed and integrity. More stress testing and catching edge cases.

## Project status
This project has been completed


