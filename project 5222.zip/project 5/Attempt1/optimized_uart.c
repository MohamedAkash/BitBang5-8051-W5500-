#include <8051.h>
#include "optimized_main.h"

// OPTIMIZED UART FUNCTIONS - Nothing else to do

void UART_Init(void) {
    TMOD = 0x20;  // Timer 1, mode 2
    TH1 = 0xFA;   // 9600 baud
    SCON = 0x50;  // Mode 1, enable receiver
    TR1 = 1;      // Start Timer 1
}

void UART_TxChar(char c) {
    SBUF = c;
    while (!TI);
    TI = 0;
}

char UART_RxChar(void) {
    char c = '\0';
    if (RI) {
        c = SBUF;
        RI = 0;
    }
    return c;
}

// Combined string printing function to save code space
void UART_PrintString(char *str) {  // Removed 'const' to match header
    while (*str) UART_TxChar(*str++);
}

// Optimize by removing UART_PrintCharArr as it's identical to UART_PrintString
#define UART_PrintCharArr UART_PrintString

// Store hex chars in code memory - corrected SDCC syntax
__code const char hexChars[] = "0123456789ABCDEF";

void UART_PrintHex(unsigned char num) {
    UART_TxChar(hexChars[(num >> 4) & 0x0F]);
    UART_TxChar(hexChars[num & 0x0F]);
}

// void UART_PrintNumber(unsigned char num) {
//     unsigned char digit;
//     unsigned char started = 0;  // Flag to track if we've started printing digits
    
//     // Handle hundreds place
//     digit = num / 100;
//     if (digit > 0) {
//         UART_TxChar(digit + '0');
//         started = 1;
//         num %= 100;
//     }
    
//     // Handle tens place
//     digit = num / 10;
//     if (digit > 0 || started) {  // Print if not zero or if we've already printed a digit
//         UART_TxChar(digit + '0');
//         started = 1;
//         num %= 10;
//     }
    
//     // Handle ones place
//     UART_TxChar((num % 10) + '0');  // Always print ones digit
// }

void UART_PrintNumber(unsigned char num) {
    if (num == 0) {
        UART_TxChar('0');
        return;
    }
    
    if (num >= 100) {
        UART_TxChar((num/100) + '0');
        num = num % 100;
        UART_TxChar((num/10) + '0');
        UART_TxChar((num%10) + '0');
    }
    else if (num >= 10) {
        UART_TxChar((num/10) + '0');
        UART_TxChar((num%10) + '0');
    }
    else {
        UART_TxChar(num + '0');
    }
}

void UART_PrintIP(unsigned char *ip) {  // Removed 'const' to match header
    unsigned char i;
    for (i = 0; i < 4; i++) {
        UART_PrintNumber(ip[i]);
        if (i < 3) UART_TxChar('.');
    }
}

void UART_PrintMAC(unsigned char *mac) {  // Removed 'const' to match header
    unsigned char i;
    for (i = 0; i < 6; i++) {
        UART_PrintHex(mac[i]);
        if (i < 5) UART_TxChar(' ');
    }
}