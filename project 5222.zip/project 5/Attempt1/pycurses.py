import socket
import time
import curses
import random
import string
import logging

UDP_IP = "192.168.32.27"
UDP_PORT = 5000
MESSAGE = "<0ad2dfdrfe>"
TCP_IP = "192.168.32.27"
TCP_PORT = 5001
DELAY_SECONDS = 0.01  # Delay in seconds
SENT_PACKET_COUNT = 0  # Counter for sent packets2
RECEIVED_PACKET_COUNT = 0  # Counter for received packets



def generate_random_message():
    length = random.randint(8, 8)  # Random length between 8 and 16
    return '<' +'0' +''.join(random.choices(string.ascii_lowercase + string.digits, k=length)) + '>' # Generate random string

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,  # Set the logging level to DEBUG
    filename="debug.log",  # Log messages will be written to this file
    filemode="w",  # Overwrite the log file each time the program runs
    format="%(asctime)s - %(levelname)s - %(message)s"  # Log format
)

def main(stdscr):
    global SENT_PACKET_COUNT, RECEIVED_PACKET_COUNT

    # Initialize curses
    curses.curs_set(0)  # Hide the cursor
    curses.start_color()
    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)  # Create a color pair (foreground: green, background: black)
    curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)  # Create a color pair (foreground: green, background: black)
    curses.init_pair(3, curses.COLOR_BLUE, curses.COLOR_BLACK)  # Create a color pair (foreground: green, background: black)
    stdscr.clear()
    stdscr.refresh()

    # Prompt for mode
    stdscr.addstr(0, 0, "Press 1 for UDP and 2 for TCP: ")
    stdscr.refresh()
    mode = stdscr.getkey()

    last_message_received = ""
    current_mode = "UDP" if mode == '1' else "TCP"

    stdscr.nodelay(True)  # Set to non-blocking mode

    FASTEST_RESPONSE = 100
    SLOWEST_RESPONSE = 0

    while True:

        # Listen for key presses
        key = stdscr.getch()
        if key == ord('M') or key == ord('m'):  # 'M' key to toggle mode
            if mode == '1':
                mode = '2'
                current_mode = "TCP"
            else:
                mode = '1'
                current_mode = "UDP"
        elif key == 10:  # Enter key to stop pinging
            break

        if mode == '1':  # UDP Mode
                elapsed_time_ms = 0
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP
                sock.bind(("192.168.32.113", UDP_PORT))
                sock.settimeout(0.5)
                MESSAGE = generate_random_message()  # Generate random message
                try:
                    sock.sendto(MESSAGE.encode(), (UDP_IP, UDP_PORT))  # Send message
                except socket.error as e:
                    logging.debug("Connection has failed")
                
                start_time = time.time()
                SENT_PACKET_COUNT += 1

                try:
                    data, addr = sock.recvfrom(1024)  # Buffer size is 1024 bytes
                    if data:
                        RECEIVED_PACKET_COUNT += 1
                        last_message_received = data.decode()
                        end_time = time.time()
                        elapsed_time_ms = (end_time - start_time) * 1000
                except UnicodeDecodeError:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Error decoding message"
                except ConnectionResetError as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Error"
                except TimeoutError as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Timeout occurred"
                    logging.error(f"TimeoutError: {e}")


                error_rate = (SENT_PACKET_COUNT - RECEIVED_PACKET_COUNT) / SENT_PACKET_COUNT * 100

                # Update the curses UI
                stdscr.clear()
                stdscr.addstr(0, 0, f"Mode: {current_mode}")
                stdscr.addstr(1, 0, f"Packets Sent: {SENT_PACKET_COUNT}")
                stdscr.addstr(2, 0, f"Packets Received: {RECEIVED_PACKET_COUNT}")
                stdscr.addstr(3, 0, f"Error Rate: {error_rate:.2f}%",curses.color_pair(2))
                stdscr.addstr(4, 0, f"Last Message Sent: {MESSAGE}")
                stdscr.addstr(5, 0, f"Last Message Received: {last_message_received}")
                if elapsed_time_ms > 0:
                    stdscr.addstr(6, 0, f"Response Time: {elapsed_time_ms:.2f} ms")
                stdscr.addstr(7, 0, f"Mode: UDP",curses.color_pair(1))
                stdscr.addstr(9, 0, f"Press Enter to stop pinging and M to change mode",curses.color_pair(3))
                if(elapsed_time_ms < FASTEST_RESPONSE and elapsed_time_ms!=0):
                    FASTEST_RESPONSE = elapsed_time_ms

                stdscr.addstr(0, 50, f"Fastest time: {FASTEST_RESPONSE}ms")
                if(elapsed_time_ms > SLOWEST_RESPONSE):
                    SLOWEST_RESPONSE = elapsed_time_ms

                stdscr.addstr(1, 50, f"Slowest time: {SLOWEST_RESPONSE}ms")
                stdscr.refresh()
               

                sock.close()  # For UDP
                time.sleep(DELAY_SECONDS)

        elif mode == '2':  # TCP Mode
                elapsed_time_ms = 0
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                client_socket.settimeout(0.5)  # Set a timeout of 3 seconds
               
                try:
                    client_socket.connect((TCP_IP, TCP_PORT))
                    print("Connection successful!")
                except socket.error as e:
                    logging.debug("Connection has failed")
                    continue 
                message = "hhhh"
                message = generate_random_message()  # Generate random message
             
                try:
                    client_socket.send(message.encode())
                except ConnectionResetError as e:
                    SENT_PACKET_COUNT -= 1
                    message = "Error"
                start_time = time.time()
                SENT_PACKET_COUNT += 1

                try:
              
                    data = client_socket.recv(1024)  # Buffer size is 1024 bytes
              
                    if data:
                        RECEIVED_PACKET_COUNT += 1
                        last_message_received = data.decode()
                        end_time = time.time()
                        elapsed_time_ms = (end_time - start_time) * 1000
                    else:
                        logging.debug("Error No data")
                except UnicodeDecodeError:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Error decoding message"
                    logging.debug("Error decoding message")
                except ConnectionResetError as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Error"
                    logging.error(f"ConnectionResetError: {e}")
                except BlockingIOError as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Blocking operation"
                    logging.warning(f"BlockingIOError: {e}")
                except TimeoutError as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Timeout occurred"
                    logging.error(f"TimeoutError: {e}")
                except OSError as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "OS error"
                    logging.error(f"OSError: {e}")
                except socket.error as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Socket error"
                    logging.error(f"Socket error: {e}")
                except Exception as e:
                    RECEIVED_PACKET_COUNT -= 1
                    last_message_received = "Unexpected error"
                    logging.critical(f"Unexpected error: {e}")

                error_rate = (SENT_PACKET_COUNT - RECEIVED_PACKET_COUNT) / SENT_PACKET_COUNT * 100

                # Update the curses UI
                stdscr.clear()
                stdscr.addstr(0, 0, f"Mode: {current_mode}")
                stdscr.addstr(1, 0, f"Packets Sent: {SENT_PACKET_COUNT}")
                stdscr.addstr(2, 0, f"Packets Received: {RECEIVED_PACKET_COUNT}")
                stdscr.addstr(3, 0, f"Error Rate: {error_rate:.2f}%",curses.color_pair(2))
                stdscr.addstr(4, 0, f"Last Message Sent: {message}")
                stdscr.addstr(5, 0, f"Last Message Received: {last_message_received}")
                if elapsed_time_ms > 0:
                    stdscr.addstr(6, 0, f"Response Time: {elapsed_time_ms:.2f} ms")
                stdscr.addstr(7, 0, f"Mode: TCP",curses.color_pair(1))
                stdscr.addstr(9, 0, f"Press Enter to stop pinging and M to change mode",curses.color_pair(3))
                if(elapsed_time_ms < FASTEST_RESPONSE and elapsed_time_ms!=0):
                    FASTEST_RESPONSE = elapsed_time_ms
                stdscr.addstr(0, 50, f"Fastest time: {FASTEST_RESPONSE}ms")
                if(elapsed_time_ms > SLOWEST_RESPONSE):
                    SLOWEST_RESPONSE = elapsed_time_ms
                stdscr.addstr(1, 50, f"Slowest time: {SLOWEST_RESPONSE}ms")
                stdscr.refresh()
                try:
                    client_socket.close()  # For TCP
                except socket.error as e:
                    print(f"Connection failed: {e}")

                time.sleep(DELAY_SECONDS)
        

# Run the curses application
curses.wrapper(main)