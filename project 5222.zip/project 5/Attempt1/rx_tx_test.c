#include <8051.h>
#include "optimized_main.h"
#include <ctype.h>


// Test message array
static unsigned char returnData[22];

static unsigned char testMsg[] = "BUFFER TEST";
static unsigned char received[22]; // Buffer for received data
void WIZnet_SetIP(unsigned char *ip) {
    // Set IP address (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(SIPR + i,CR, ip[i]); // SIPR register starts at 0x000F
    }
}


//get the RX read pointer for socket n
unsigned short getRxReadPointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_RX_PTR+2, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_RX_PTR+3, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

//get the RX write pointer for socket n
unsigned short getRxWritePointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_RX_PTR+4, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_RX_PTR+5, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

unsigned short getTxReadPointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_TX_PTR, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_TX_PTR+1, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

unsigned short getTxWritePointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_TX_PTR+2, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_TX_PTR+3, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

//Set the Mac address of the wiznet chip Common Register from 0x0009 to 0x000E
void WIZnet_SetMAC(unsigned char *mac) {
    // Set MAC address (6 bytes)
    for (unsigned char i = 0; i < 6; i++) {
        WIZnet_Write(SHAR + i,CR, mac[i]); // SHAR register starts at 0x0009
    }
}

//Set the Subnet Mask of the wiznet chip Common Register from 0x0005 to 0x0008
void WIZnet_SetSubnetMask(unsigned char *subnet) {
    // Set Subnet Mask (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(SUBR + i,CR, subnet[i]); // SUBR register starts at 0x0005
    }
}

//Set the Gateway Address of the wiznet chip Common Register from 0x0001 to 0x0004
void WIZnet_SetGateway(unsigned char *gateway) {
    // Set Gateway Address (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(GAR + i,CR, gateway[i]); // GAR register starts at 0x0001
    }
}

//Set the socket mode for Socket 0 
void WIZnet_SetSocketMode(unsigned char mode, unsigned char sock) {
    // Set the mode for the socket (TCP or UDP)
    WIZnet_Write(Sn_MR,sock,mode); // Sn_MR register
}

// Set the socket port for Socket n
void WIZnet_SetSocketPort(unsigned char sock, int port) {
    // Set the source port for the socket

    unsigned char highByte = (port >> 8) & 0xFF; // Get the high byte
    unsigned char lowByte = port & 0xFF; 

    WIZnet_Write(Sn_PORT,sock, highByte); // Set port high byte (5000 = 0x1388)
    WIZnet_Write(Sn_PORT+1, sock, lowByte);  // Set port low byte
}

// Send the open socket command for socket n
void WIZnet_OpenSocket(unsigned char sock) {
    // Open the socket
    WIZnet_Write(Sn_CR,sock, 0x01); // Sn_CR register: OPEN command
}

// Send the close socket command for socket n
void WIZnet_CloseSocket(unsigned char sock) {
    // Close the socket
    WIZnet_Write(Sn_CR,sock, 0x10); // Sn_CR register: CLOSE command
}
void readFromRXBufferUDP(unsigned char sock, unsigned char sockrx) {
    TXD = 1;
    unsigned char data = '\0';

    returnData[0] = '\0'; // Initialize the return data array

    if(WIZnet_Read(Sn_RX_PTR, sock) != 0x00 || WIZnet_Read(Sn_RX_PTR+1, sock) != 0x00) // Read the socket Sn_RX_RD0 register to check if data is available
    {
        TXD = 0;
        // Set the tempBad flag to indicate that data is available
        
        //recieve the data
        unsigned short readPointer = getRxReadPointer(sock); // Get the RX read pointer
        unsigned short getSize = 0;
        unsigned char peer_ip[4]; // Buffer to store the peer IP address

        //Write the value of the value of the ip and port to the Socket n Destination IP and Port registers
        peer_ip[0] = WIZnet_Read(readPointer, sockrx);
        peer_ip[1] = WIZnet_Read(readPointer+1, sockrx); 
        peer_ip[2] = WIZnet_Read(readPointer+2, sockrx); 
        peer_ip[3] = WIZnet_Read(readPointer+3, sockrx); 

        WIZnet_SetDestinationIP(peer_ip,sock);

        //WIZnet_SetDestinationPort(sock, (WIZnet_Read(readPointer+4, sockrx)<< 8) | (WIZnet_Read(readPointer+5, sockrx)));
        WIZnet_SetDestinationPort(sock,5000); // Set the destination port
        
        getSize = ((WIZnet_Read(readPointer+6, sockrx)<< 8) | (WIZnet_Read(readPointer+7, sockrx)));

        readPointer +=8;
        for(int i = 0;i<getSize;i++)
        {
            
            returnData[i] = WIZnet_Read(readPointer+i, sockrx); // Read the data
            if(returnData[i] == '<')
            {
                returnData[i] = '[';
            }
            else if(returnData[i] == '>')
            {
                returnData[i] = ']';
            }


        }
        returnData[getSize] = '\0'; // Null-terminate the string
 

        readPointer+=getSize;

        //WIZnet_Write(Sn_RX_RD1, sock, readPointer);

        WIZnet_Write(Sn_RX_PTR+2, sock, (readPointer >> 8) & 0xFF); // Update the TX write pointer high byte
        WIZnet_Write(Sn_RX_PTR+3, sock, readPointer & 0xFF);        // Update the TX write pointer low byte

        WIZnet_Write(Sn_CR, sock, 0x40); //send the recv   
        TXD = 1;

    }

}

void WIZnet_Write(unsigned short address, unsigned char modeRegister, unsigned char data) {
    SS = 0;  // Select WIZnet
    SPI_WriteShort(address); //sending the address
    SPI_Write(modeRegister + 0x04); //where you put registers + 0x04 to indicate write operation
    SPI_Write(data); // Send data
    SS = 1;  // Deselect WIZnet
}

// Read from a WIZnet register
unsigned char WIZnet_Read(unsigned short address, unsigned char modeRegister) {
    unsigned char data;
    SS = 0;  // Select WIZnet
    SPI_WriteShort(address);
    SPI_Write(modeRegister); //where you put registers
    data = SPI_Read();                   // Read data
    SS = 1;  // Deselect WIZnet
    return data;
}

//Initialize the WIZnet chip
void WIZnet_Init(void) {
    // Reset WIZnet chip (if applicable)
    SS = 0; 
    SPI_WriteShort(Sn_MR);
    SPI_Write(0b10000000);// MR register: Reset command
    SS = 1;
    delay(10);                   // Wait for reset to complete
}

// Set the destination port for socket n
void WIZnet_SetDestinationPort(unsigned char sock, int destPort) {
    // Set the source port for the socket

    unsigned char highByte = (destPort >> 8) & 0xFF; // Get the high byte
    unsigned char lowByte = destPort & 0xFF; 

    WIZnet_Write(Sn_DPORT,sock, highByte); // Set port high byte (5000 = 0x1388)
    WIZnet_Write(Sn_DPORT+1, sock, lowByte);  // Set port low byte
}

//Set the destination IP of socket n
void WIZnet_SetDestinationIP(unsigned char *ip, unsigned char sock) {
    
    // Set IP address (4 bytes) memory efficient
    WIZnet_Write(0x000C,sock, ip[0]);
    WIZnet_Write(0x000D,sock, ip[1]);
    WIZnet_Write(0x000E,sock, ip[2]);
    WIZnet_Write(0x000F,sock, ip[3]);


}

//Helper function to set the packet ready to send for socket n
void Wiznet_SendPacket(unsigned char sock)
{
    WIZnet_Write(Sn_CR, sock, 0x20); // Send the data in the TX buffer
    while(WIZnet_Read(Sn_CR, sock) != 0x00) // Wait until the socket is ready to send data
    {
        // This loop will wait until the socket is ready to send data
    }
}

void writeToTXBufferUDP(unsigned char sock, unsigned char socktx) {
    RXD = 1;  // Start with LED off
    unsigned char interrupt;
    unsigned short sendPointer = getTxWritePointer(sock);

    // Only proceed if we have data to send
    if(returnData[0] != '\0') {
        delay(1000); // Change this later to smaller value or remove it
        RXD = 0;  // Turn ON TX LED before starting transmission
        
        // Convert to uppercase and send
        for(char i = 0; returnData[i] != '\0'; i++) {
            WIZnet_Write(sendPointer, socktx, toupper(returnData[i]));
            sendPointer += 1;
        }
        
        // Update pointer and send packet
        WIZnet_Write(Sn_TX_PTR+2, sock, (sendPointer >> 8) & 0xFF);
        WIZnet_Write(Sn_TX_PTR+3, sock, sendPointer & 0xFF);
        
        Wiznet_SendPacket(sock); // Actually transmit the data
        
        RXD = 1;  // Turn OFF TX LED after transmission complete
        returnData[0] = '\0'; // Clear the buffer
    }

    // Clear interrupt flags
    interrupt = WIZnet_Read(Sn_IR, sock);
    if(interrupt & 0x10) { // SEND_OK
        WIZnet_Write(Sn_IR, sock, 0x10);
    }
    if(interrupt & 0x08) { // TIMEOUT
        WIZnet_Write(Sn_IR, sock, 0x08);
    }
}

void delay(unsigned int milliseconds)
{
    unsigned int count;
    while (milliseconds > 0) {
        count = 1000; // Adjust this value based on your clock speed
        while (count > 0) {
            count--;
        }
        milliseconds--;
    }
}
void testBuffers(void) {
    unsigned char i;
    unsigned short rxRead, rxWrite, txRead, txWrite;
    
    // // Print initial status
    // UART_PrintString("\r\n=== Buffer Test Started ===\r\n");
    // UART_PrintString("Date: 2025-05-07 18:18:24\r\n");
    // UART_PrintString("User: MohamedAkash\r\n");
    
    // 1. Check initial buffer pointers
    // UART_PrintString("\r\nInitial Buffer Status:\r\n");
    rxRead = getRxReadPointer(S0_R);
    rxWrite = getRxWritePointer(S0_R);
    txRead = getTxReadPointer(S0_R);
    txWrite = getTxWritePointer(S0_R);
    
    // UART_PrintString("RX Read Pointer: ");
    // UART_PrintNumber(rxRead);
    // UART_PrintString("\r\nRX Write Pointer: ");
    // UART_PrintNumber(rxWrite);
    // UART_PrintString("\r\nTX Read Pointer: ");
    // UART_PrintNumber(txRead);
    // UART_PrintString("\r\nTX Write Pointer: ");
    // UART_PrintNumber(txWrite);
    
    // 2. Test TX Buffer Write
    // UART_PrintString("\r\n\nTesting TX Buffer Write...\r\n");
    unsigned short sendPointer = getTxWritePointer(S0_R);
    
    for(i = 0; testMsg[i] != '\0'; i++) {
        WIZnet_Write(sendPointer, S0_TX, testMsg[i]);
        sendPointer++;
        // UART_PrintString("Wrote: ");
        // UART_TxChar(testMsg[i]);
        // UART_PrintString("\r\n");
    }
    
    // Update TX write pointer
    WIZnet_Write(Sn_TX_PTR+2, S0_R, (sendPointer >> 8) & 0xFF);
    WIZnet_Write(Sn_TX_PTR+3, S0_R, sendPointer & 0xFF);
    
    // 3. Test RX Buffer Read
    // UART_PrintString("\r\nWaiting for incoming data...\r\n");
    delay(1000); // Wait for potential incoming data
    
    if(WIZnet_Read(Sn_RX_PTR, S0_R) != 0x00 || WIZnet_Read(Sn_RX_PTR+1, S0_R) != 0x00) {
        // UART_PrintString("Data received!\r\n");
        
        unsigned short readPointer = getRxReadPointer(S0_R);
        unsigned short getSize = ((WIZnet_Read(readPointer+6, S0_RX) << 8) | 
                                 WIZnet_Read(readPointer+7, S0_RX));
        
        // UART_PrintString("Received size: ");
        // UART_PrintNumber(getSize);
        // UART_PrintString("\r\nReceived data: ");
        
        readPointer += 8; // Skip header
        for(i = 0; i < getSize && i < sizeof(received)-1; i++) {
            received[i] = WIZnet_Read(readPointer+i, S0_RX);
            // UART_TxChar(received[i]);
        }
        received[i] = '\0';
        
        // Update RX read pointer
        readPointer += getSize;
        WIZnet_Write(Sn_RX_PTR+2, S0_R, (readPointer >> 8) & 0xFF);
        WIZnet_Write(Sn_RX_PTR+3, S0_R, readPointer & 0xFF);
        WIZnet_Write(Sn_CR, S0_R, 0x40); // Send RECV command
    } else {
        // UART_PrintString("No data received\r\n");
    }
    
    // 4. Final buffer status
    // UART_PrintString("\r\nFinal Buffer Status:\r\n");
    rxRead = getRxReadPointer(S0_R);
    rxWrite = getRxWritePointer(S0_R);
    txRead = getTxReadPointer(S0_R);
    txWrite = getTxWritePointer(S0_R);
    
    // UART_PrintString("RX Read Pointer: ");
    // UART_PrintNumber(rxRead);
    // UART_PrintString("\r\nRX Write Pointer: ");
    // UART_PrintNumber(rxWrite);
    // UART_PrintString("\r\nTX Read Pointer: ");
    // UART_PrintNumber(txRead);
    // UART_PrintString("\r\nTX Write Pointer: ");
    // UART_PrintNumber(txWrite);
    
    // UART_PrintString("\r\n=== Buffer Test Complete ===\r\n");
}

void main(void) {
    // Initialize hardware
    SPI_Init();
    WIZnet_Init();
    //UART_Init();
    
    RXD = 1; // Initialize RXD LED
    TXD = 1; // Initialize TXD LED

    // Configure network parameters
    unsigned char ip[4] = {192, 168, 32, 27};
    unsigned char mac[6] = {0x00, 0x08, 0xDC, 0x01, 0x02, 0x03};
    unsigned char subnet[4] = {255, 255, 255, 0};
    unsigned char gateway[4] = {192, 168, 32, 1};
    
    WIZnet_SetMAC(mac);
    WIZnet_SetIP(ip);
    WIZnet_SetSubnetMask(subnet);
    WIZnet_SetGateway(gateway);
    
    // Configure UDP socket
    WIZnet_SetSocketMode(Sn_PUDP, S0_R);
    WIZnet_SetSocketPort(S0_R, 5000);
    WIZnet_OpenSocket(S0_R);
    
    // Run buffer tests
    testBuffers();
    
    while(1) {
        // Main program loop
        if(WIZnet_Read(Sn_IR, S0_R) == 0b00000100) {
            // UART_PrintString("\r\nNew packet received during main loop\r\n");
            readFromRXBufferUDP(S0_R, S0_RX);
            writeToTXBufferUDP(S0_R, S0_TX);
            WIZnet_Write(Sn_IR, S0_R, 0b00000100);
        }
        
    }
}