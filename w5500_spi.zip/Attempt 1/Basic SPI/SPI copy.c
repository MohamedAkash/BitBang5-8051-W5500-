#include <stdint.h>
#include <8051.h>
#include "../include/periphs.h"
#include "../include/typedefs.h"
#include "../include/pinmap.h"
#include "../include/wiznet_defs.h"

#define	_nop_()	__asm__("nop")

void SPI_Init(void) {
    MOSI = 0;   // Output
    MISO = 1;   // Input
    SCK = 0;    // Mode 0: Clock idle low
    SS = 1;     // Deselect
}

void SPI_Write(unsigned char data) {
    unsigned char i;
    for (i = 0; i < 8; i++) {
        MOSI = (data & 0x80) ? 1 : 0;
        data <<= 1;
        SCK = 1;      // Rising edge
        _nop_();      // Delay for SCK pulse width
        SCK = 0;      // Falling edge
    }
}

void SPI_WriteShort(unsigned short data) {
    unsigned short i;
    for (i = 0; i < 16; i++) {
        MOSI = (data & 0x8000) ? 1 : 0;  // Send MSB first
        data <<= 1;                    // Shift data left
        SCK = 1;                       // Generate clock pulse
        SCK = 0;
    }
}

unsigned char SPI_Read(void) {
    unsigned char i, data = 0;
    for (i = 0; i < 8; i++) {
        data <<= 1;
        SCK = 1;      // Rising edge
        _nop_();      // Wait for slave to update MISO
        if (MISO) data |= 0x01;
        SCK = 0;      // Falling edge
    }
    return data;
}

