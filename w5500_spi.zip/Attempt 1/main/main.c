#include <8051.h>
#include <stdio.h>
#include <ctype.h>
#include "../include/project5Header.h"

//for testing
#define SERIAL
#define PYTHONN

//Array to hold data from packet
static unsigned char returnData[22];
//placeholder for rtu
static unsigned char rtu = 0;
//helper function to make hex values for MAC addr
unsigned char combineHexChars(char high, char low) {

    unsigned char highValue, lowValue;

    // Convert high character to its integer value
    if (high >= '0' && high <= '9') {
        highValue = high - '0'; // Convert '0'-'9' to 0-9
    } else if (high >= 'A' && high <= 'F') {
        highValue = high - 'A' + 10; // Convert 'A'-'F' to 10-15
    } else {
        // Handle invalid input
        return 0; // or some error value
    }

    // Convert low character to its integer value
    if (low >= '0' && low <= '9') {
        lowValue = low - '0'; // Convert '0'-'9' to 0-9
    } else if (low >= 'A' && low <= 'F') {
        lowValue = low - 'A' + 10; // Convert 'A'-'F' to 10-15
    } else {
        // Handle invalid input
        return 0; // or some error value
    }

    // Combine the two values into a single byte
    return (highValue << 4) | lowValue; // Shift high value and combine
}

// Write to a WIZnet register uses the Address, Mode Register and data to write to the register
void WIZnet_Write(unsigned short address, unsigned char modeRegister, unsigned char data) {
    SS = 0;  // Select WIZnet
    SPI_WriteShort(address); //sending the address
    SPI_Write(modeRegister + 0x04); //where you put registers + 0x04 to indicate write operation
    SPI_Write(data); // Send data
    SS = 1;  // Deselect WIZnet
}

// Read from a WIZnet register
unsigned char WIZnet_Read(unsigned short address, unsigned char modeRegister) {
    unsigned char data;
    SS = 0;  // Select WIZnet
    SPI_WriteShort(address);
    SPI_Write(modeRegister); //where you put registers
    data = SPI_Read();                   // Read data
    SS = 1;  // Deselect WIZnet
    return data;
}

//Initialize the WIZnet chip
void WIZnet_Init(void) {
    // Reset WIZnet chip (if applicable)
    SS = 0; 
    SPI_WriteShort(MR);
    SPI_Write(0b10000000);// MR register: Reset command
    SS = 1;
    delay(10);                   // Wait for reset to complete
}

//Set the IP of the wiznet chip Common Register from 0x000F to 0x0012
void WIZnet_SetIP(unsigned char *ip) {
    // Set IP address (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(SIPR + i,CR, ip[i]); // SIPR register starts at 0x000F
    }
}

//Set the Mac address of the wiznet chip Common Register from 0x0009 to 0x000E
void WIZnet_SetMAC(unsigned char *mac) {
    // Set MAC address (6 bytes)
    for (unsigned char i = 0; i < 6; i++) {
        WIZnet_Write(SHAR + i,CR, mac[i]); // SHAR register starts at 0x0009
    }
}

//Set the Subnet Mask of the wiznet chip Common Register from 0x0005 to 0x0008
void WIZnet_SetSubnetMask(unsigned char *subnet) {
    // Set Subnet Mask (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(SUBR + i,CR, subnet[i]); // SUBR register starts at 0x0005
    }
}

//Set the Gateway Address of the wiznet chip Common Register from 0x0001 to 0x0004
void WIZnet_SetGateway(unsigned char *gateway) {
    // Set Gateway Address (4 bytes)
    for (unsigned char i = 0; i < 4; i++) {
        WIZnet_Write(GAR + i,CR, gateway[i]); // GAR register starts at 0x0001
    }
}

//Set the socket mode for Socket 0 
void WIZnet_SetSocketMode(unsigned char mode, unsigned char sock) {
    // Set the mode for the socket (TCP or UDP)
    WIZnet_Write(MR,sock,mode); // Sn_MR register
}

// Set the socket port for Socket n
void WIZnet_SetSocketPort(unsigned char sock, int port) {
    // Set the source port for the socket

    unsigned char highByte = (port >> 8) & 0xFF; // Get the high byte
    unsigned char lowByte = port & 0xFF; 

    WIZnet_Write(Sn_PORT0,sock, highByte); // Set port high byte (5000 = 0x1388)
    WIZnet_Write(Sn_PORT1, sock, lowByte);  // Set port low byte
}

// Send the open socket command for socket n
void WIZnet_OpenSocket(unsigned char sock) {
    // Open the socket
    WIZnet_Write(Sn_CR,sock, 0x01); // Sn_CR register: OPEN command
}

// Send the close socket command for socket n
void WIZnet_CloseSocket(unsigned char sock) {
    // Close the socket
    WIZnet_Write(Sn_CR,sock, 0x10); // Sn_CR register: CLOSE command
}

// Set the destination port for socket n
void WIZnet_SetDestinationPort(unsigned char sock, int destPort) {
    // Set the source port for the socket

    unsigned char highByte = (destPort >> 8) & 0xFF; // Get the high byte
    unsigned char lowByte = destPort & 0xFF; 

    WIZnet_Write(Sn_DPORT0,sock, highByte); // Set port high byte (5000 = 0x1388)
    WIZnet_Write(Sn_DPORT1, sock, lowByte);  // Set port low byte
}

//Set the destination IP of socket n
void WIZnet_SetDestinationIP(unsigned char *ip, unsigned char sock) {
    
    // Set IP address (4 bytes) memory efficient
    WIZnet_Write(0x000C,sock, ip[0]);
    WIZnet_Write(0x000D,sock, ip[1]);
    WIZnet_Write(0x000E,sock, ip[2]);
    WIZnet_Write(0x000F,sock, ip[3]);


}

//Helper function to set the packet ready to send for socket n
void Wiznet_SendPacket(unsigned char sock)
{
    WIZnet_Write(Sn_CR, sock, 0x20); // Send the data in the TX buffer
    while(WIZnet_Read(Sn_CR, sock) != 0x00) // Wait until the socket is ready to send data
    {
        // This loop will wait until the socket is ready to send data
    }
}

//Set the RX buffer size for socket n
void setRxBufferSize(unsigned char sock) //of socket n
{
    WIZnet_Write(Sn_RXBUF_SIZE, sock,0x10); // write 0x10 to the RX buffer size register
}

//get the RX read pointer for socket n
unsigned short getRxReadPointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_RX_RD0, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_RX_RD1, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

//get the RX write pointer for socket n
unsigned short getRxWritePointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_RX_WR0, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_RX_WR1, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

unsigned short getTxReadPointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_TX_RD0, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_TX_RD1, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

unsigned short getTxWritePointer(unsigned char sock) // of socket n
{
    unsigned char highByte = WIZnet_Read(Sn_TX_WR0, sock); // Read the high byte of the RX read pointer.
    unsigned char lowByte = WIZnet_Read(Sn_TX_WR1, sock); // Read the low byte of the RX read pointer

    return (unsigned short)((highByte << 8) | lowByte); // Combine high and low bytes to form the full pointer
}

//Write to the TX buffer of socket n
void writeToTXBufferUDP(unsigned char sock, unsigned char socktx) {


    unsigned char interrupt;

    unsigned short sendPointer = getTxWritePointer(sock); // Get the TX read pointer

     // Write the data to the TX buffer of socket 0

    for(char i = 0; returnData[i] != '\0';i++)
    {
                
        WIZnet_Write(sendPointer, socktx, toupper(returnData[i])); //send the data bac
        sendPointer+=1;
        //delay(100);
             
    }
    
    if(returnData[0] != '\0')
    {

        WIZnet_Write(Sn_TX_WR0, sock, (sendPointer >> 8) & 0xFF); // Update the TX write pointer high byte
        WIZnet_Write(Sn_TX_WR1, sock, sendPointer & 0xFF);        // Update the TX write pointer low byte

        Wiznet_SendPacket(sock); // Send the data in the TX buffer
        OUT = 0;

    }

    
    returnData[0] = '\0'; 

    interrupt = WIZnet_Read(Sn_IR, sock);

    if(interrupt & 0x10) // Check if the SEND_OK interrupt flag is set
    {
        WIZnet_Write(Sn_IR, sock, 0x10); // Clear SEND_OK flag
    }
    if(interrupt & 0x08) // Check if the interrupt flag is set
    {
        WIZnet_Write(Sn_IR, sock, 0x08); // Clear TIMEOUT flag
    }
   
    

}

//Read from the rx read pointer of socket n
void readFromRXBufferUDP(unsigned char sock, unsigned char sockrx) {

    unsigned char data = '\0';

    returnData[0] = '\0'; // Initialize the return data array

    if(WIZnet_Read(Sn_RX_RSR0, sock) != 0x00 || WIZnet_Read(Sn_RX_RSR1, sock) != 0x00) // Read the socket Sn_RX_RD0 register to check if data is available
    {
         // Set the tempBad flag to indicate that data is available
        
        //recieve the data
        unsigned short readPointer = getRxReadPointer(sock); // Get the RX read pointer
        unsigned short getSize = 0;
        unsigned char peer_ip[4]; // Buffer to store the peer IP address

        //Write the value of the value of the ip and port to the Socket n Destination IP and Port registers
        peer_ip[0] = WIZnet_Read(readPointer, sockrx);
        peer_ip[1] = WIZnet_Read(readPointer+1, sockrx); 
        peer_ip[2] = WIZnet_Read(readPointer+2, sockrx); 
        peer_ip[3] = WIZnet_Read(readPointer+3, sockrx); 

        WIZnet_SetDestinationIP(peer_ip,sock);

        //WIZnet_SetDestinationPort(sock, (WIZnet_Read(readPointer+4, sockrx)<< 8) | (WIZnet_Read(readPointer+5, sockrx)));
        WIZnet_SetDestinationPort(sock,5000); // Set the destination port
        
        getSize = ((WIZnet_Read(readPointer+6, sockrx)<< 8) | (WIZnet_Read(readPointer+7, sockrx)));

        readPointer +=8;
        for(int i = 0;i<getSize;i++)
        {
            
            returnData[i] = WIZnet_Read(readPointer+i, sockrx); // Read the data
            if(returnData[i] == '<')
            {
                returnData[i] = '[';
            }
            else if(returnData[i] == '>')
            {
                returnData[i] = ']';
            }


        }
        returnData[getSize] = '\0'; // Null-terminate the string
 

        readPointer+=getSize;

        //WIZnet_Write(Sn_RX_RD1, sock, readPointer);

        WIZnet_Write(Sn_RX_RD0, sock, (readPointer >> 8) & 0xFF); // Update the TX write pointer high byte
        WIZnet_Write(Sn_RX_RD1, sock, readPointer & 0xFF);        // Update the TX write pointer low byte

        WIZnet_Write(Sn_CR, sock, 0x40); //send the recv   
        OUT = 1;

    }

}

//listen for incoming connections on socket n
void tcpListen(unsigned char sock) {

    WIZnet_Write(Sn_CR, sock, 0x02); // Send the LISTEN command to the socket Sn_CR register

}

void tcpConnect(unsigned char sock,unsigned char ip[],int destPort) {

    WIZnet_SetDestinationIP(ip,sock);
    WIZnet_SetDestinationPort(sock, destPort);

    WIZnet_Write(Sn_CR, sock, 0x04); // Send the CONNECT command to the socket Sn_CR register

}

void readFromRXBufferTCP(unsigned char sock, unsigned char sockrx) {

    unsigned char data = 0;

    returnData[0] = '\0';

                unsigned short getSize = ((WIZnet_Read(Sn_RX_RSR0, sock)<< 8) | (WIZnet_Read(Sn_RX_RSR1, sock)));

                unsigned short readPointer = getRxReadPointer(sock); //get the read pointer

                for(int i = 0;i<getSize;i++)
                {
                    returnData[i] = WIZnet_Read(readPointer+i, sockrx); // Read the data
                    if(returnData[i] == '<')
                    {
                        returnData[i] = '[';
                    }
                    if(returnData[i] == '>')
                    {
                        returnData[i] = ']';
                    }
                }

                returnData[getSize] = '\0';

                //data = WIZnet_Read(readPointer, sockrx); //read the data being received
        
                readPointer+=getSize; //increment the read pointer
        
                WIZnet_Write(Sn_RX_RD0, sock, (readPointer >> 8) & 0xFF); // Update the RX Read Pointer
                WIZnet_Write(Sn_RX_RD1, sock, readPointer & 0xFF);    
        
                WIZnet_Write(Sn_CR, sock, 0x40); //send the recv   
                OUT = 1;
                   
}

//write to the tx buffer and send through tcp
void writeToTxBufferTCP(unsigned char sock, unsigned char socktx) {

    //Need to check that the data is not too long for the buffer

        unsigned char interrupt;

        //get the write pointer of socket n
        unsigned short sendPointer = getTxWritePointer(sock);

        //write the data to the tx buffer of socket n
        for(char i = 0; returnData[i] != '\0';i++)
        {
        WIZnet_Write(sendPointer, socktx, toupper(returnData[i])); 
        sendPointer+=1;
        }
        //increment the send pointer
        

        WIZnet_Write(Sn_TX_WR0, sock, (sendPointer >> 8) & 0xFF); // Update the TX write pointer high byte
        WIZnet_Write(Sn_TX_WR1, sock, sendPointer & 0xFF);        // Update the TX write pointer low byte

        Wiznet_SendPacket(sock); // Send the data in the TX buffer
        OUT = 0;

        interrupt = WIZnet_Read(Sn_IR, sock);

        if(interrupt & 0x10) // Check if the SEND_OK interrupt flag is set
        {
            WIZnet_Write(Sn_IMR, sock, 0x10); // Clear SEND_OK flag
        }
        if(interrupt & 0x08) // Check if the interrupt flag is set
        {
            WIZnet_Write(Sn_IMR, sock, 0x08); // Clear TIMEOUT flag
        }

        unsigned short tx_read_pointer = WIZnet_Read(Sn_TX_RD0, sock) << 8 | WIZnet_Read(Sn_TX_RD1, sock);
        WIZnet_Write(Sn_TX_WR0, sock, (tx_read_pointer >> 8) & 0xFF); // Reset TX write pointer high byte
        WIZnet_Write(Sn_TX_WR1, sock, tx_read_pointer & 0xFF);        // Reset TX write pointer low byte

}

// Main function for serial communication
void main(void) {

    //setting common register 
    unsigned char ip[4] = {192, 168, 32, 27};   //test ip
    unsigned char mac[6] = {0x00, 0x08, 0xDC, 0x01, 0x02, 0x03}; //test mac address
    unsigned char subnet[4] = {255, 255, 255, 0};               // Example Subnet Mask
    unsigned char gateway[4] = {192, 168, 32, 1};                // Example Gateway

    unsigned char mode = 0; //0 is udp 1 is tcp
   
    //init spi
    //ini wiznet chip
    //init uart
    SPI_Init();
    WIZnet_Init();
    UART_Init();
    OUT = 0;

    // Set mac address
    // Set IP address
    // Set Subnet Mask
    // Set Gateway Address
    WIZnet_SetMAC(mac);
    WIZnet_SetIP(ip);
    WIZnet_SetSubnetMask(subnet);
    WIZnet_SetGateway(gateway);  

    //Socket 0 UDP configuration
    // Set wiznet socket mode to selected protocol (UDP)
    // Set socket port  hardcoded at port 5000
    // Send open socket command
    WIZnet_SetSocketMode(Sn_PUDP,S0_R);
    WIZnet_SetSocketPort(S0_R,5000);
    WIZnet_OpenSocket(S0_R);

    //Socket 1 UDP configuration
    // Set wiznet socket mode to selected protocol (TCP)
    // Set socket port  hardcoded at port 5000
    // Send open socket command
    WIZnet_SetSocketMode(Sn_PTCP,S1_R);
    WIZnet_SetSocketPort(S1_R,5001);
    WIZnet_OpenSocket(S1_R);

    //reset the rx buffer
    WIZnet_CloseSocket(S0_R);
    WIZnet_OpenSocket(S0_R); 
    WIZnet_CloseSocket(S1_R);
    WIZnet_OpenSocket(S1_R); 

    tcpListen(S1_R); //listen for incoming connections
    //tcpConnect(S1_R,ip,61464); //connect to the server

    //block ping
    WIZnet_Write(MR,CR,0b00010000);

    WIZnet_Write(Sn_IMR, S0_R, 0b00000100);   
    //WIZnet_Write(Sn_IMR, S1_R, 0b00000001);   

    char buffer[22];
    char bufferIndex = 0;
    char serialInputMode = 0;
    char recievedInput = 0;
    int tempCounter= 0;
    
    while(1)
    {
      
        #ifdef PYTHONN
        
        if(bufferIndex == 0)
        {
        if(WIZnet_Read(Sn_IR, S0_R) == 0b00000100)
        {
            readFromRXBufferUDP(S0_R,S0_RX);
            writeToTXBufferUDP(S0_R,S0_TX); //send the data back

           WIZnet_Write(Sn_IR, S0_R, 0b00000100);   // clear Sn_IR
        }
        if(WIZnet_Read(Sn_SR, S1_R) == 0x17) //check if the connection is ready to be established Sn_SR register
        {

            if(WIZnet_Read(Sn_RX_RSR0, S1_R) != 0x00 || WIZnet_Read(Sn_RX_RSR1, S1_R) != 0x00) //there is data ready to be read
            {
            readFromRXBufferTCP(S1_R,S1_RX);
            writeToTxBufferTCP(S1_R,S1_TX); //send the data back
            }
           
        }
        if(WIZnet_Read(Sn_SR, S1_R) == 0x1C)
        {
            WIZnet_CloseSocket(S1_R); //when connection is closed reset the socket for a new connection
            WIZnet_OpenSocket(S1_R);
            tcpListen(S1_R);
        }

        }
        #endif

        #ifdef SERIAL

        if(bufferIndex > 21) // Check if the buffer is full
        {
            bufferIndex = 0; // Reset the buffer index
    
        }

        recievedInput = UART_RxChar();

        if(recievedInput!='\0')
        {
            buffer[bufferIndex] = recievedInput;  
            bufferIndex++;
        }
        
        if(buffer[bufferIndex-1] == '?')
        {
                UART_PrintString("CURRENT CONFIG: ");
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("RTU Addr (0-9): ");
                UART_PrintString("0"); // what the is an rtu value dont know :) smile
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("IP Addr: ");
                UART_PrintIP(ip); // Print the IP address
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("Subnet Mask: ");
                UART_PrintIP(subnet);
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("Gateway: ");
                UART_PrintIP(gateway);
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("MAC Addr: ");
                UART_PrintMAC(mac);
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("Mode: ");
                if(mode == 0)
                {
                    UART_PrintString("UDP");
                }
                else
                {
                    UART_PrintString("TCP");
                }
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("CHANGE CMD:");
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("RTU=");
                UART_PrintString("#"); // what the is an rtu value dont know :) smile
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("IP=");
                UART_PrintString("###.###.###.###");
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("SUB=");
                UART_PrintString("###.###.###.###");
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("GATE=");
                UART_PrintString("###.###.###.###");
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("MAC=");
                UART_PrintString("FF FF FF FF FF FF");
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_PrintString("MODE=");
                UART_PrintString("UDP/TCP");
                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                UART_TxChar('\r'); 
                UART_TxChar('\n'); 

                bufferIndex = 0; // Reset the buffer index
                continue;
            }
            
        if(buffer[bufferIndex-1] == '}') //Print buffer
        {
            UART_PrintCharArr(buffer); 
            UART_TxChar('\r'); 
            UART_TxChar('\n'); 

            bufferIndex = 0; // Reset the buffer index
            continue;


        }
            
        if(serialInputMode == 1) //IP address input mode
            {

                if(isdigit(buffer[3]) && isdigit(buffer[4]) && isdigit(buffer[5]) && bufferIndex >= 5)
                {

                    ip[0] =  ((buffer[3] - '0') * 100) + ((buffer[4] - '0') * 10) + ((buffer[5] - '0'));

                }
                if(isdigit(buffer[7]) && isdigit(buffer[8]) && isdigit(buffer[9]) && bufferIndex >= 9)
                {

                    ip[1] =  ((buffer[7] - '0') * 100) + ((buffer[8] - '0') * 10) + ((buffer[9] - '0'));

                }
                if(isdigit(buffer[11]) && isdigit(buffer[12]) && isdigit(buffer[13]) && bufferIndex >= 13)
                {

                    ip[2] =  ((buffer[11] - '0') * 100) + ((buffer[12] - '0') * 10) + ((buffer[13] - '0'));

                }
                if(isdigit(buffer[15]) && isdigit(buffer[16]) && isdigit(buffer[17]) && bufferIndex >= 17)
                {

                    ip[3] =  ((buffer[15] - '0') * 100) + ((buffer[16] - '0') * 10) + ((buffer[17] - '0'));
                    WIZnet_SetIP(ip);
                }
                if(bufferIndex>17)
                {
                    bufferIndex=0;
                }
                
            }
        else if(serialInputMode == 2) //SUB address input mode
            {

                if(isdigit(buffer[4]) && isdigit(buffer[5]) && isdigit(buffer[6]) && bufferIndex >= 6)
                {

                    subnet[0] =  ((buffer[4] - '0') * 100) + ((buffer[5] - '0') * 10) + ((buffer[6] - '0'));

                }
                if(isdigit(buffer[8]) && isdigit(buffer[9]) && isdigit(buffer[10]) && bufferIndex >= 10)
                {

                    subnet[1] =  ((buffer[8] - '0') * 100) + ((buffer[9] - '0') * 10) + ((buffer[10] - '0'));

                }
                if(isdigit(buffer[12]) && isdigit(buffer[13]) && isdigit(buffer[14]) && bufferIndex >= 14)
                {

                    subnet[2] =  ((buffer[12] - '0') * 100) + ((buffer[13] - '0') * 10) + ((buffer[14] - '0'));

                }
                if(isdigit(buffer[16]) && isdigit(buffer[17]) && isdigit(buffer[18]) && bufferIndex >= 18)
                {

                    subnet[3] =  ((buffer[16] - '0') * 100) + ((buffer[17] - '0') * 10) + ((buffer[18] - '0'));
                    WIZnet_SetSubnetMask(subnet);    

                }
                if(bufferIndex>18)
                {
                    bufferIndex=0;
                }
            }
        else if(serialInputMode == 3) //GATE address input mode
            {

                if(isdigit(buffer[5]) && isdigit(buffer[6]) && isdigit(buffer[7]) && bufferIndex >= 7)
                {

                    gateway[0] =  ((buffer[5] - '0') * 100) + ((buffer[6] - '0') * 10) + ((buffer[7] - '0'));

                }
                if(isdigit(buffer[9]) && isdigit(buffer[10]) && isdigit(buffer[11]) && bufferIndex >= 11)
                {

                    gateway[1] =  ((buffer[9] - '0') * 100) + ((buffer[10] - '0') * 10) + ((buffer[11] - '0'));

                }
                if(isdigit(buffer[13]) && isdigit(buffer[14]) && isdigit(buffer[15]) && bufferIndex >= 15)
                {

                    gateway[2] =  ((buffer[13] - '0') * 100) + ((buffer[14] - '0') * 10) + ((buffer[15] - '0'));

                }
                if(isdigit(buffer[17]) && isdigit(buffer[18]) && isdigit(buffer[19]) && bufferIndex >= 19)
                {

                    gateway[3] =  ((buffer[17] - '0') * 100) + ((buffer[18] - '0') * 10) + ((buffer[19] - '0'));
                    WIZnet_SetGateway(gateway); 

                }
                if(bufferIndex>19)
                {
                    bufferIndex=0;
                }
            }
        else if(serialInputMode == 4) //MAC address input mode
            {

                if(buffer[4] != NULL && buffer[5] != NULL && bufferIndex >= 5) 
                {

    
                    mac[0] = combineHexChars(buffer[4],buffer[5]); 
        
                }
                if(buffer[6] != NULL && buffer[7] != NULL && bufferIndex >= 7) 
                {


                    mac[1] = combineHexChars(buffer[6],buffer[7]); 
    

                }
                if(buffer[8] != NULL && buffer[9] != NULL && bufferIndex >= 9) 
                {

        
                    mac[2] = combineHexChars(buffer[8],buffer[9]); 
    

                }
                if(buffer[10] != NULL && buffer[11] != NULL && bufferIndex >= 11) 
                {

    
                    mac[3] = combineHexChars(buffer[10],buffer[11]); 
        

                }
                if(buffer[12] != NULL && buffer[13] != NULL && bufferIndex >= 13) 
                {

                    mac[4] = combineHexChars(buffer[12],buffer[13]); 


                }
                if(buffer[14] != NULL && buffer[15] != NULL && bufferIndex >= 15) 
                {

                    mac[5] = combineHexChars(buffer[14],buffer[15]); 
                    WIZnet_SetMAC(mac);


                }
                if(bufferIndex>15)
                {
                    bufferIndex=0;
                }
                
                }
        else if(serialInputMode == 5) //MODE address input mode
        {
                
            if(buffer[5] == 'U' && buffer[6] == 'D' && buffer[7] == 'P' && bufferIndex >= 7)
            {
                //mode is UDP
                mode = 0;
                bufferIndex = 0; // Reset the buffer index

            }

            if(buffer[5] == 'T' && buffer[6] == 'C' && buffer[7] == 'P' && bufferIndex >= 7) 
            {
                //mode is TCP
                mode = 1;
                bufferIndex = 0; // Reset the buffer index

            }
                

        }
       
        if(buffer[0] == 'R' && buffer[1] == 'T' && buffer[2] == 'U' && buffer[3] == '=' && buffer[4] != NULL) 
            {
        
                rtu = buffer[4];
            
            }
        else if(buffer[0] == 'I' && buffer[1] == 'P' && buffer[2] == '=') 
            {

                serialInputMode = 1; // Set the mode to IP address input

            }
        else if(buffer[0] == 'S' && buffer[1] == 'U' && buffer[2] == 'B' && buffer[3] == '=') 
            {

                serialInputMode = 2; // Set the mode to subnet mask input

            }
        else if(buffer[0] == 'G' && buffer[1] == 'A' && buffer[2] == 'T' && buffer[3] == 'E' && buffer[4] == '=') 
            {

                serialInputMode = 3; // Set the mode to subnet mask input

            }
        else if(buffer[0] == 'M' && buffer[1] == 'A' && buffer[2] == 'C' && buffer[3] == '=') 
            {

                serialInputMode = 4; // Set the mode to subnet mask input

            }
        else if(buffer[0] == 'M' && buffer[1] == 'O' && buffer[2] == 'D' && buffer[3] == 'E' && buffer[4] == '=') 
        {

            serialInputMode = 5; // Set the mode to subnet mask input

        }
                
        #endif

    }

}

void delay(unsigned int milliseconds)
{
    unsigned int count;
    while (milliseconds > 0) {
        count = 1000; // Adjust this value based on your clock speed
        while (count > 0) {
            count--;
        }
        milliseconds--;
    }
}
