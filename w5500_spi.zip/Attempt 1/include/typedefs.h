typedef unsigned char uchar;
typedef unsigned int uint;