#ifndef UART_CONFIG_H
#define UART_CONFIG_H

#define UART_BAUD 9600 // or 19200

#endif
